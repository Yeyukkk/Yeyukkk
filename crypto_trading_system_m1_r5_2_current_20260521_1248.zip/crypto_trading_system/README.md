# Crypto Trading System

A modular crypto perpetual trading system targeting OKX, designed to share the
same strategy code between **backtest**, **paper**, and **live** execution.

---

## Architecture

```
bots/                  Entry points (run_backtest / run_paper / run_live)
  │
  ▼
core/
  config.py            Single source of truth for YAML config loading
  data/                Exchange + OHLCV layer (CCXT)
  strategy/            Strategy abstractions (signal generation only)
  risk/                Position sizing, daily limits, kill switch
  execution/           Paper / Live / Backtest executors (same interface)
  portfolio/           Account state + reconciliation with exchange
  backtest/            Event-driven backtest engine + metrics
  monitoring/          Telegram, structured logging, healthcheck
config/                YAML configuration files
tests/                 pytest unit + smoke tests
data/                  Historical OHLCV cache (gitignored)
logs/                  Run logs (gitignored)
state/                 Persisted state files (gitignored)
```

### Design rules

1. **One strategy class powers backtest + paper + live.** No code duplication.
2. **Executor is an interface.** `PaperExecutor`, `LiveExecutor`, `BacktestExecutor`
   all implement `open_position`, `close_position`, `get_open_positions`. The bot
   entry only switches which executor it instantiates.
3. **Exchange is the source of truth.** Local state files are caches. On startup
   every bot reconciles from `fetch_positions()` and `fetch_open_orders()`.
4. **Config-driven.** Strategy params, risk params, symbol lists live in YAML.
5. **Fail closed.** Any uncaught exception in the live executor must flatten
   positions or pause new entries, never silently continue.

---

## Roadmap (Sprints)

| # | Sprint | Status | Deliverable |
|---|--------|--------|-------------|
| 0 | Project skeleton | ✅ this commit | Folder structure, base classes, config loader, exchange wrapper, logger, smoke test |
| 1 | Backtest engine | TODO | Historical OHLCV downloader + event-driven backtest + metrics (Sharpe, MDD, win rate, expectancy, profit factor) |
| 2 | SMC strategy port | TODO | Port the existing FVG/BOS/CHOCH signal engine into `core/strategy/smc_ict.py`, validated on ≥6 months of BTC/ETH data |
| 3 | Strategy upgrades | TODO | Killzone filter, structure-invalidation exit, news calendar filter — each feature backtested against baseline |
| 4 | Risk module | TODO | Position sizing (vol-based), daily loss kill switch, max correlated exposure |
| 5 | Paper executor | TODO | Realistic paper exec with slippage + funding + fee model |
| 6 | Live executor | TODO | OKX live with native algo SL/TP, OCO, state reconciliation |
| 7 | Monitoring | TODO | Healthcheck, Telegram alerts, daily report |
| 8 | Paper forward test | TODO | 2-4 week paper run, compare vs backtest |
| 9 | Live small capital | TODO | 100-500 USDT live, monitor paper-live divergence |

### Go/No-Go criteria for live (from Sprint 1 backtest)

- Sharpe ratio > 1.5
- Max drawdown < 15%
- Win rate × avg_win > (1 - win_rate) × avg_loss (positive expectancy)
- Sample size ≥ 100 trades

If any of these fail, the strategy does not graduate to paper/live. Period.

---

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# edit .env with your OKX keys and Telegram tokens

# Sanity check the OKX connection
python -m tests.test_exchange
```

## Running

```bash
# After Sprint 1
python -m bots.run_backtest --config config/strategies/smc_v1.yaml --symbol BTC/USDT:USDT --htf 1h --ltf 15m --start 2024-01-01 --end 2024-12-31

# After Sprint 5
python -m bots.run_paper --config config/paper.yaml

# After Sprint 6 — DO NOT RUN until backtest + paper criteria are met
python -m bots.run_live --config config/live.yaml
```

## Safety

- The `.env` file is gitignored. Never commit API keys.
- The OKX API key used by `run_live` should have **trade only** permissions —
  withdraw must be disabled and IP whitelist enabled.
- A separate read-only key may be used for `run_backtest` and `run_paper`.
