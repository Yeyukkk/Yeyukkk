"""Analyze SMC feature context around completed EMA trades."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

import pandas as pd


FEATURE_RULES: dict[str, tuple[list[str], Callable[[pd.Series], pd.Series]]] = {
    "bullish_fvg_confirmed": (["smc_fvg_fvg_confirmed", "smc_f_v_g_f_v_g_confirmed"], lambda s: s == 1),
    "bearish_fvg_confirmed": (["smc_fvg_fvg_confirmed", "smc_f_v_g_f_v_g_confirmed"], lambda s: s == -1),
    "bullish_bos_confirmed": (["smc_bos_choch_bos_confirmed"], lambda s: s == 1),
    "bearish_bos_confirmed": (["smc_bos_choch_bos_confirmed"], lambda s: s == -1),
    "bullish_choch_confirmed": (["smc_bos_choch_choch_confirmed"], lambda s: s == 1),
    "bearish_choch_confirmed": (["smc_bos_choch_choch_confirmed"], lambda s: s == -1),
    "bullish_ob_confirmed": (["smc_ob_ob_confirmed", "smc_o_b_o_b_confirmed"], lambda s: s == 1),
    "bearish_ob_confirmed": (["smc_ob_ob_confirmed", "smc_o_b_o_b_confirmed"], lambda s: s == -1),
    "bullish_liquidity_confirmed": (["smc_liquidity_liquidity_confirmed"], lambda s: s == 1),
    "bearish_liquidity_confirmed": (["smc_liquidity_liquidity_confirmed"], lambda s: s == -1),
    "previous_high_broken": (["smc_previous_high_low_broken_high_confirmed"], lambda s: s == 1),
    "previous_low_broken": (["smc_previous_high_low_broken_low_confirmed"], lambda s: s == 1),
    "session_active": (["smc_sessions_active_confirmed", "smc_sessions_active_raw"], lambda s: s == 1),
}


def _first_existing_column(df: pd.DataFrame, candidates: list[str]) -> str | None:
    return next((column for column in candidates if column in df.columns), None)


def _feature_present(window: pd.DataFrame, feature_name: str) -> bool:
    candidates, predicate = FEATURE_RULES[feature_name]
    column = _first_existing_column(window, candidates)
    if column is None or window.empty:
        return False
    values = pd.to_numeric(window[column], errors="coerce")
    return bool(predicate(values).fillna(False).any())


def diagnose_trades(features: pd.DataFrame, trades: pd.DataFrame, lookback_bars: int = 20) -> pd.DataFrame:
    if lookback_bars < 1:
        raise ValueError("lookback_bars must be positive")
    if "timestamp" not in features.columns:
        raise ValueError("features CSV must contain timestamp")
    if "entry_time" not in trades.columns or "net_pnl" not in trades.columns:
        raise ValueError("trades CSV must contain entry_time and net_pnl")

    features = features.copy()
    trades = trades.copy()
    features["timestamp"] = pd.to_datetime(features["timestamp"], utc=True)
    trades["entry_time"] = pd.to_datetime(trades["entry_time"], utc=True)
    features = features.sort_values("timestamp").reset_index(drop=True)
    feature_times = features["timestamp"]

    rows = []
    for _, trade in trades.iterrows():
        entry_time = pd.Timestamp(trade["entry_time"])
        nearest_index = int((feature_times - entry_time).abs().argmin())
        lookback = features[features["timestamp"] < entry_time].tail(lookback_bars)

        row = trade.to_dict()
        row["entry_time"] = entry_time.isoformat()
        if "exit_time" in row:
            row["exit_time"] = pd.Timestamp(row["exit_time"]).isoformat()
        row["matched_feature_timestamp"] = feature_times.iloc[nearest_index].isoformat()
        row["matched_feature_index"] = nearest_index
        row["lookback_bars_used"] = len(lookback)
        for feature_name in FEATURE_RULES:
            row[feature_name] = _feature_present(lookback, feature_name)
        row["trade_is_win"] = float(trade["net_pnl"]) > 0
        rows.append(row)

    return pd.DataFrame(rows)


def summarize_feature_lift(diagnostics: pd.DataFrame) -> dict[str, dict[str, float]]:
    winners = diagnostics[diagnostics["trade_is_win"]]
    losers = diagnostics[~diagnostics["trade_is_win"]]
    summary: dict[str, dict[str, float]] = {}

    for feature_name in FEATURE_RULES:
        winner_frequency = float(winners[feature_name].mean()) if len(winners) else 0.0
        loser_frequency = float(losers[feature_name].mean()) if len(losers) else 0.0
        summary[feature_name] = {
            "winner_frequency": winner_frequency,
            "loser_frequency": loser_frequency,
            "lift": winner_frequency - loser_frequency,
        }
    return summary


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Diagnose SMC features around EMA backtest trades.")
    parser.add_argument("--features", default="logs/smc_features.csv")
    parser.add_argument("--trades", default="logs/backtest_trades.csv")
    parser.add_argument("--lookback-bars", type=int, default=20)
    parser.add_argument("--output-trades", default="logs/smc_trade_diagnostics.csv")
    parser.add_argument("--output-summary", default="logs/smc_feature_summary.json")
    return parser


def _print_lift(title: str, items: list[tuple[str, dict[str, float]]]) -> None:
    print(title)
    for name, stats in items:
        print(
            f"{name}: lift={stats['lift']:.4f}, "
            f"winner={stats['winner_frequency']:.4f}, loser={stats['loser_frequency']:.4f}"
        )


def main() -> None:
    args = _build_parser().parse_args()
    features = pd.read_csv(args.features)
    trades = pd.read_csv(args.trades)

    diagnostics = diagnose_trades(features, trades, lookback_bars=args.lookback_bars)
    summary = summarize_feature_lift(diagnostics)

    output_trades = Path(args.output_trades)
    output_summary = Path(args.output_summary)
    output_trades.parent.mkdir(parents=True, exist_ok=True)
    output_summary.parent.mkdir(parents=True, exist_ok=True)
    diagnostics.to_csv(output_trades, index=False)
    output_summary.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")

    ranked = sorted(summary.items(), key=lambda item: item[1]["lift"], reverse=True)
    print("\nSMC diagnostics complete")
    print(f"Trades: {len(diagnostics)}")
    print(f"Trade diagnostics: {output_trades}")
    print(f"Feature summary: {output_summary}")
    _print_lift("\nTop positive lift features", ranked[:5])
    _print_lift("\nTop negative lift features", list(reversed(ranked[-5:])))


if __name__ == "__main__":
    main()

