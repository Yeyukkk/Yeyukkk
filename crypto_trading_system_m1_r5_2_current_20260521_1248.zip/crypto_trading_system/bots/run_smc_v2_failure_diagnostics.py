"""Failure diagnostics for SMC v2 long_only_block_15.

Runs the long_only_block_15 SMC v2 experiment (long_only=True,
blocked_entry_hours_utc=[15]) across user-supplied walk-forward windows,
then breaks down trade outcomes by window, hour, killzone, exit reason,
risk bucket, reward-to-fee bucket, and loss streaks. Output is written
to ``--output-dir`` as a set of CSVs plus a plain-text report.

Public OKX market data only — no live trading, no private endpoints,
no API keys. Research/diagnostics only; this script never claims
profitability.
"""

from __future__ import annotations

import argparse
import time
from dataclasses import asdict, replace
from pathlib import Path
from statistics import median
from typing import Any, Iterable

import pandas as pd

from bots.run_backtest import (
    DEFAULT_HTF_TIMEFRAME,
    _build_backtest_config,
    _coalesce,
    _load_or_fetch_ohlcv,
    _load_strategy_yaml,
    _load_yaml,
)
from bots.run_smc_v2_walk_forward import (
    PREDEFINED_EXPERIMENTS,
    Experiment,
    build_experiment_strategy,
    parse_windows,
)
from core.backtest import BacktestConfig, BacktestEngine
from core.data import OKXClient


TARGET_EXPERIMENT: Experiment = next(
    exp for exp in PREDEFINED_EXPERIMENTS if exp.name == "long_only_block_15"
)


TRADE_COLUMNS: list[str] = [
    "window",
    "start",
    "end",
    "symbol",
    "timeframe",
    "htf_timeframe",
    "trade_id",
    "side",
    "entry_time",
    "exit_time",
    "entry_price",
    "exit_price",
    "net_pnl",
    "pnl_pct",
    "pnl_pct_on_margin",
    "exit_reason",
    "bars_held",
    "stop_loss_price",
    "take_profit_price",
    "strategy_version",
    "killzone_name",
    "passed_killzone",
    "passed_liquidity_sweep",
    "passed_choch",
    "sweep_level",
    "choch_level",
    "risk_pct",
    "target_pct",
    "rr",
    "reward_to_fee_ratio",
    "entry_hour_utc",
    "entry_weekday_utc",
    "entry_month",
]


WINDOW_SUMMARY_COLUMNS: list[str] = [
    "window",
    "start",
    "end",
    "total_trades",
    "net_pnl",
    "net_pnl_pct",
    "win_rate",
    "profit_factor",
    "max_drawdown_pct",
    "avg_trade_pnl",
    "median_trade_pnl",
    "avg_bars_held",
    "stop_loss_trades",
    "take_profit_trades",
    "worst_trade",
    "best_trade",
    "max_consecutive_losses",
]


HOUR_SUMMARY_COLUMNS: list[str] = [
    "entry_hour_utc",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "profit_factor",
    "stop_loss_rate",
    "avg_bars_held",
]


KILLZONE_SUMMARY_COLUMNS: list[str] = [
    "killzone_name",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "profit_factor",
    "stop_loss_rate",
    "avg_bars_held",
]


EXIT_REASON_SUMMARY_COLUMNS: list[str] = [
    "exit_reason",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "avg_bars_held",
]


RISK_BUCKET_SUMMARY_COLUMNS: list[str] = [
    "risk_bucket",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "profit_factor",
    "stop_loss_rate",
]


REWARD_FEE_SUMMARY_COLUMNS: list[str] = [
    "reward_fee_bucket",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "profit_factor",
]


STREAK_SUMMARY_COLUMNS: list[str] = [
    "scope",
    "max_consecutive_losses",
    "streaks_2_losses",
    "streaks_3_losses",
    "streaks_4plus_losses",
]


RISK_BUCKET_ORDER: list[str] = [
    "<=0.25%",
    "0.25%-0.50%",
    "0.50%-0.75%",
    "0.75%-1.00%",
    ">1.00%",
    "unknown",
]


REWARD_FEE_BUCKET_ORDER: list[str] = ["<5", "5-10", "10-20", ">20", "unknown"]


TOP_N: int = 10


def _is_nan(value: Any) -> bool:
    try:
        return bool(pd.isna(value))
    except (TypeError, ValueError):
        return False


def assign_risk_bucket(value: Any) -> str:
    if value is None or _is_nan(value):
        return "unknown"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "unknown"
    if v <= 0:
        return "unknown"
    if v <= 0.0025:
        return "<=0.25%"
    if v <= 0.005:
        return "0.25%-0.50%"
    if v <= 0.0075:
        return "0.50%-0.75%"
    if v <= 0.01:
        return "0.75%-1.00%"
    return ">1.00%"


def assign_reward_fee_bucket(value: Any) -> str:
    if value is None or _is_nan(value):
        return "unknown"
    try:
        v = float(value)
    except (TypeError, ValueError):
        return "unknown"
    if v < 5:
        return "<5"
    if v < 10:
        return "5-10"
    if v < 20:
        return "10-20"
    return ">20"


def compute_profit_factor(net_pnls: Iterable[float]) -> float | None:
    gross_profit = 0.0
    gross_loss = 0.0
    for pnl in net_pnls:
        if _is_nan(pnl):
            continue
        value = float(pnl)
        if value > 0:
            gross_profit += value
        elif value < 0:
            gross_loss += value
    if gross_loss < 0:
        return gross_profit / abs(gross_loss)
    return None


def max_consecutive_losses(net_pnls: Iterable[float]) -> int:
    streak = 0
    longest = 0
    for pnl in net_pnls:
        if _is_nan(pnl):
            continue
        if float(pnl) < 0:
            streak += 1
            if streak > longest:
                longest = streak
        else:
            streak = 0
    return longest


def losing_streak_counts(net_pnls: Iterable[float]) -> dict[str, int]:
    counts = {"streaks_2_losses": 0, "streaks_3_losses": 0, "streaks_4plus_losses": 0}
    streak = 0
    for pnl in net_pnls:
        if _is_nan(pnl):
            continue
        if float(pnl) < 0:
            streak += 1
            continue
        _record_streak(counts, streak)
        streak = 0
    _record_streak(counts, streak)
    return counts


def _record_streak(counts: dict[str, int], streak: int) -> None:
    if streak >= 4:
        counts["streaks_4plus_losses"] += 1
    elif streak == 3:
        counts["streaks_3_losses"] += 1
    elif streak == 2:
        counts["streaks_2_losses"] += 1


def derive_time_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Add entry_hour_utc, entry_weekday_utc, entry_month derived from entry_time."""

    df = df.copy()
    if "entry_time" not in df.columns or df.empty:
        df["entry_hour_utc"] = pd.NA
        df["entry_weekday_utc"] = pd.NA
        df["entry_month"] = pd.NA
        return df

    timestamps = pd.to_datetime(df["entry_time"], utc=True, errors="coerce")
    df["entry_hour_utc"] = timestamps.dt.hour.astype("Int64")
    df["entry_weekday_utc"] = timestamps.dt.weekday.astype("Int64")
    df["entry_month"] = timestamps.dt.month.astype("Int64")
    return df


def _ensure_columns(df: pd.DataFrame, columns: Iterable[str], default: Any = pd.NA) -> pd.DataFrame:
    df = df.copy()
    for column in columns:
        if column not in df.columns:
            df[column] = default
    return df


def _numeric_series(df: pd.DataFrame, column: str) -> pd.Series:
    if column not in df.columns:
        return pd.Series([], dtype=float)
    return pd.to_numeric(df[column], errors="coerce")


def _group_stats(group: pd.DataFrame) -> dict[str, Any]:
    trades = len(group)
    if trades == 0:
        return {
            "trades": 0,
            "net_pnl": 0.0,
            "avg_net_pnl": 0.0,
            "win_rate": 0.0,
            "profit_factor": None,
            "stop_loss_rate": 0.0,
            "avg_bars_held": 0.0,
        }
    net_pnls = _numeric_series(group, "net_pnl")
    net_pnl = float(net_pnls.sum())
    avg_net_pnl = float(net_pnls.mean()) if not net_pnls.empty else 0.0
    win_rate = float((net_pnls > 0).sum()) / trades
    profit_factor = compute_profit_factor(net_pnls.tolist())
    stop_loss_rate = (
        float((group["exit_reason"] == "stop_loss").sum()) / trades
        if "exit_reason" in group.columns
        else 0.0
    )
    bars_held = _numeric_series(group, "bars_held").dropna()
    avg_bars_held = float(bars_held.mean()) if not bars_held.empty else 0.0
    return {
        "trades": trades,
        "net_pnl": net_pnl,
        "avg_net_pnl": avg_net_pnl,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "stop_loss_rate": stop_loss_rate,
        "avg_bars_held": avg_bars_held,
    }


def aggregate_window_summary(
    trades: pd.DataFrame,
    window_metadata: dict[str, dict[str, Any]],
    window_order: list[str],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for label in window_order:
        meta = window_metadata.get(label, {})
        start = meta.get("start", "")
        end = meta.get("end", "")
        net_pnl_pct = meta.get("net_pnl_pct")
        max_drawdown_pct = meta.get("max_drawdown_pct")

        if "window" in trades.columns:
            window_trades = trades[trades["window"] == label]
        else:
            window_trades = trades.iloc[0:0]

        total_trades = len(window_trades)
        if total_trades:
            net_pnls = _numeric_series(window_trades, "net_pnl").dropna().tolist()
            if "entry_time" in window_trades.columns:
                ordered = window_trades.sort_values("entry_time")
                ordered_pnls = _numeric_series(ordered, "net_pnl").dropna().tolist()
            else:
                ordered_pnls = net_pnls
            net_pnl = sum(net_pnls)
            wins = sum(1 for p in net_pnls if p > 0)
            win_rate = wins / total_trades
            profit_factor = compute_profit_factor(net_pnls)
            avg_trade_pnl = net_pnl / total_trades
            median_trade_pnl = float(median(net_pnls)) if net_pnls else 0.0
            bars_held = _numeric_series(window_trades, "bars_held").dropna()
            avg_bars_held = float(bars_held.mean()) if not bars_held.empty else 0.0
            if "exit_reason" in window_trades.columns:
                stop_loss_trades = int((window_trades["exit_reason"] == "stop_loss").sum())
                take_profit_trades = int((window_trades["exit_reason"] == "take_profit").sum())
            else:
                stop_loss_trades = 0
                take_profit_trades = 0
            worst_trade = float(min(net_pnls)) if net_pnls else 0.0
            best_trade = float(max(net_pnls)) if net_pnls else 0.0
            mcl = max_consecutive_losses(ordered_pnls)
        else:
            net_pnl = 0.0
            win_rate = 0.0
            profit_factor = None
            avg_trade_pnl = 0.0
            median_trade_pnl = 0.0
            avg_bars_held = 0.0
            stop_loss_trades = 0
            take_profit_trades = 0
            worst_trade = 0.0
            best_trade = 0.0
            mcl = 0

        rows.append(
            {
                "window": label,
                "start": start,
                "end": end,
                "total_trades": total_trades,
                "net_pnl": net_pnl,
                "net_pnl_pct": net_pnl_pct,
                "win_rate": win_rate,
                "profit_factor": profit_factor,
                "max_drawdown_pct": max_drawdown_pct,
                "avg_trade_pnl": avg_trade_pnl,
                "median_trade_pnl": median_trade_pnl,
                "avg_bars_held": avg_bars_held,
                "stop_loss_trades": stop_loss_trades,
                "take_profit_trades": take_profit_trades,
                "worst_trade": worst_trade,
                "best_trade": best_trade,
                "max_consecutive_losses": mcl,
            }
        )
    return pd.DataFrame(rows, columns=WINDOW_SUMMARY_COLUMNS)


def aggregate_hour_summary(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=HOUR_SUMMARY_COLUMNS)
    df = _ensure_columns(trades, ["entry_hour_utc", "net_pnl", "exit_reason", "bars_held"])
    rows: list[dict[str, Any]] = []
    for hour, group in df.groupby("entry_hour_utc", dropna=False):
        stats = _group_stats(group)
        label = "unknown" if _is_nan(hour) else int(hour) if not _is_nan(hour) else "unknown"
        rows.append({"entry_hour_utc": label, **stats})
    summary = pd.DataFrame(rows, columns=HOUR_SUMMARY_COLUMNS)
    summary["__sort"] = pd.to_numeric(summary["entry_hour_utc"], errors="coerce")
    summary = summary.sort_values(by=["__sort", "entry_hour_utc"], na_position="last").drop(columns="__sort")
    return summary.reset_index(drop=True)


def aggregate_killzone_summary(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=KILLZONE_SUMMARY_COLUMNS)
    df = _ensure_columns(trades, ["killzone_name", "net_pnl", "exit_reason", "bars_held"])
    rows: list[dict[str, Any]] = []
    for name, group in df.groupby("killzone_name", dropna=False):
        stats = _group_stats(group)
        label = "unknown" if _is_nan(name) or name is None else str(name)
        rows.append({"killzone_name": label, **stats})
    summary = pd.DataFrame(rows, columns=KILLZONE_SUMMARY_COLUMNS)
    return summary.sort_values(by="killzone_name", na_position="last").reset_index(drop=True)


def aggregate_exit_reason_summary(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=EXIT_REASON_SUMMARY_COLUMNS)
    df = _ensure_columns(trades, ["exit_reason", "net_pnl", "bars_held"])
    rows: list[dict[str, Any]] = []
    for reason, group in df.groupby("exit_reason", dropna=False):
        net_pnls = _numeric_series(group, "net_pnl")
        trades_count = len(group)
        bars_held = _numeric_series(group, "bars_held").dropna()
        rows.append(
            {
                "exit_reason": "unknown" if _is_nan(reason) or reason is None else str(reason),
                "trades": trades_count,
                "net_pnl": float(net_pnls.sum()),
                "avg_net_pnl": float(net_pnls.mean()) if trades_count else 0.0,
                "win_rate": (
                    float((net_pnls > 0).sum()) / trades_count if trades_count else 0.0
                ),
                "avg_bars_held": float(bars_held.mean()) if not bars_held.empty else 0.0,
            }
        )
    summary = pd.DataFrame(rows, columns=EXIT_REASON_SUMMARY_COLUMNS)
    return summary.sort_values(by="exit_reason").reset_index(drop=True)


def aggregate_risk_bucket_summary(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=RISK_BUCKET_SUMMARY_COLUMNS)
    df = _ensure_columns(trades, ["risk_pct", "net_pnl", "exit_reason"])
    df = df.copy()
    df["risk_bucket"] = df["risk_pct"].apply(assign_risk_bucket)
    rows: list[dict[str, Any]] = []
    for bucket in RISK_BUCKET_ORDER:
        group = df[df["risk_bucket"] == bucket]
        if group.empty:
            continue
        stats = _group_stats(group)
        rows.append(
            {
                "risk_bucket": bucket,
                "trades": stats["trades"],
                "net_pnl": stats["net_pnl"],
                "avg_net_pnl": stats["avg_net_pnl"],
                "win_rate": stats["win_rate"],
                "profit_factor": stats["profit_factor"],
                "stop_loss_rate": stats["stop_loss_rate"],
            }
        )
    return pd.DataFrame(rows, columns=RISK_BUCKET_SUMMARY_COLUMNS)


def aggregate_reward_fee_summary(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=REWARD_FEE_SUMMARY_COLUMNS)
    df = _ensure_columns(trades, ["reward_to_fee_ratio", "net_pnl"])
    df = df.copy()
    df["reward_fee_bucket"] = df["reward_to_fee_ratio"].apply(assign_reward_fee_bucket)
    rows: list[dict[str, Any]] = []
    for bucket in REWARD_FEE_BUCKET_ORDER:
        group = df[df["reward_fee_bucket"] == bucket]
        if group.empty:
            continue
        net_pnls = _numeric_series(group, "net_pnl")
        trades_count = len(group)
        rows.append(
            {
                "reward_fee_bucket": bucket,
                "trades": trades_count,
                "net_pnl": float(net_pnls.sum()),
                "avg_net_pnl": float(net_pnls.mean()) if trades_count else 0.0,
                "win_rate": (
                    float((net_pnls > 0).sum()) / trades_count if trades_count else 0.0
                ),
                "profit_factor": compute_profit_factor(net_pnls.tolist()),
            }
        )
    return pd.DataFrame(rows, columns=REWARD_FEE_SUMMARY_COLUMNS)


def build_streak_summary(trades: pd.DataFrame, window_order: list[str]) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=STREAK_SUMMARY_COLUMNS)

    rows: list[dict[str, Any]] = []
    overall = trades
    if "entry_time" in overall.columns:
        overall = overall.sort_values("entry_time")
    overall_pnls = _numeric_series(overall, "net_pnl").dropna().tolist()
    counts = losing_streak_counts(overall_pnls)
    rows.append(
        {
            "scope": "overall",
            "max_consecutive_losses": max_consecutive_losses(overall_pnls),
            "streaks_2_losses": counts["streaks_2_losses"],
            "streaks_3_losses": counts["streaks_3_losses"],
            "streaks_4plus_losses": counts["streaks_4plus_losses"],
        }
    )
    for label in window_order:
        if "window" in trades.columns:
            window_trades = trades[trades["window"] == label]
        else:
            window_trades = trades.iloc[0:0]
        if "entry_time" in window_trades.columns:
            window_trades = window_trades.sort_values("entry_time")
        pnls = _numeric_series(window_trades, "net_pnl").dropna().tolist()
        counts = losing_streak_counts(pnls)
        rows.append(
            {
                "scope": label,
                "max_consecutive_losses": max_consecutive_losses(pnls),
                "streaks_2_losses": counts["streaks_2_losses"],
                "streaks_3_losses": counts["streaks_3_losses"],
                "streaks_4plus_losses": counts["streaks_4plus_losses"],
            }
        )
    return pd.DataFrame(rows, columns=STREAK_SUMMARY_COLUMNS)


def build_top_n(trades: pd.DataFrame, n: int = TOP_N, ascending: bool = False) -> pd.DataFrame:
    if trades.empty or "net_pnl" not in trades.columns:
        return trades.iloc[0:0].copy()
    return trades.sort_values("net_pnl", ascending=ascending).head(n).reset_index(drop=True)


def _fmt_pct(value: Any) -> str:
    if value is None or _is_nan(value):
        return "-"
    try:
        return f"{float(value):.2f}%"
    except (TypeError, ValueError):
        return "-"


def _concentration_lines(
    *,
    trades: pd.DataFrame,
    window_summary: pd.DataFrame,
    hour_summary: pd.DataFrame,
    killzone_summary: pd.DataFrame,
    risk_bucket_summary: pd.DataFrame,
) -> list[str]:
    net_pnls = _numeric_series(trades, "net_pnl").dropna().tolist()
    gross_loss = sum(p for p in net_pnls if p < 0)
    lines: list[str] = []
    if gross_loss >= 0:
        lines.append("- No losing trades; concentration analysis skipped.")
        return lines

    def share(losing_pnl: float) -> str:
        return f"{abs(losing_pnl) / abs(gross_loss) * 100:.1f}% of gross loss"

    if not window_summary.empty:
        wl = window_summary.copy()
        wl["net_pnl"] = pd.to_numeric(wl["net_pnl"], errors="coerce")
        losers = wl[wl["net_pnl"] < 0].sort_values("net_pnl")
        for _, row in losers.iterrows():
            lines.append(
                f"- Window {row['window']} ({row['start']}->{row['end']}): "
                f"net_pnl={float(row['net_pnl']):.2f} ({share(float(row['net_pnl']))})"
            )
    if not hour_summary.empty:
        hl = hour_summary.copy()
        hl["net_pnl"] = pd.to_numeric(hl["net_pnl"], errors="coerce")
        losers = hl[hl["net_pnl"] < 0].sort_values("net_pnl").head(3)
        if not losers.empty:
            sum_pnl = float(losers["net_pnl"].sum())
            hours_list = ", ".join(str(value) for value in losers["entry_hour_utc"].tolist())
            lines.append(
                f"- Top {len(losers)} losing hours sum to net_pnl={sum_pnl:.2f} "
                f"({share(sum_pnl)}); hours={hours_list}"
            )
    if not killzone_summary.empty:
        kl = killzone_summary.copy()
        kl["net_pnl"] = pd.to_numeric(kl["net_pnl"], errors="coerce")
        for _, row in kl[kl["net_pnl"] < 0].iterrows():
            lines.append(
                f"- Killzone '{row['killzone_name']}': "
                f"net_pnl={float(row['net_pnl']):.2f} ({share(float(row['net_pnl']))})"
            )
    if not risk_bucket_summary.empty:
        rb = risk_bucket_summary.copy()
        rb["net_pnl"] = pd.to_numeric(rb["net_pnl"], errors="coerce")
        for _, row in rb[rb["net_pnl"] < 0].iterrows():
            lines.append(
                f"- Risk bucket '{row['risk_bucket']}': "
                f"net_pnl={float(row['net_pnl']):.2f} ({share(float(row['net_pnl']))})"
            )
    if not lines:
        lines.append("- Losses not concentrated by window/hour/killzone/risk bucket.")
    return lines


def build_report_text(
    *,
    trades: pd.DataFrame,
    window_summary: pd.DataFrame,
    hour_summary: pd.DataFrame,
    killzone_summary: pd.DataFrame,
    exit_reason_summary: pd.DataFrame,
    risk_bucket_summary: pd.DataFrame,
    reward_fee_summary: pd.DataFrame,
    streak_summary: pd.DataFrame,
    symbol: str,
    timeframe: str,
    htf_timeframe: str,
    period_start: str,
    period_end: str,
) -> str:
    lines: list[str] = []
    lines.append("SMC v2 long_only_block_15 — failure diagnostics")
    lines.append("=" * 60)
    lines.append(f"Symbol:    {symbol}")
    lines.append(f"LTF:       {timeframe}")
    lines.append(f"HTF:       {htf_timeframe}")
    lines.append(f"Period:    {period_start} -> {period_end}")
    lines.append("")

    total_trades = len(trades)
    net_pnls = _numeric_series(trades, "net_pnl").dropna()
    overall_net_pnl = float(net_pnls.sum())
    overall_wins = int((net_pnls > 0).sum())
    overall_win_rate = (overall_wins / total_trades) if total_trades else 0.0
    overall_pf = compute_profit_factor(net_pnls.tolist())

    lines.append("Overall")
    lines.append("-------")
    lines.append(f"Total trades:        {total_trades}")
    lines.append(f"Net PnL:             {overall_net_pnl:.2f}")
    lines.append(f"Win rate:            {overall_win_rate * 100:.2f}%")
    if overall_pf is None:
        lines.append("Profit factor:       (no losses)")
    else:
        lines.append(f"Profit factor:       {overall_pf:.3f}")

    overall_streak_row = streak_summary[streak_summary["scope"] == "overall"] if not streak_summary.empty else streak_summary
    if not overall_streak_row.empty:
        row = overall_streak_row.iloc[0]
        lines.append(f"Max consec. losses:  {int(row['max_consecutive_losses'])}")
        lines.append(
            "Losing streak counts: "
            f"2={int(row['streaks_2_losses'])}, "
            f"3={int(row['streaks_3_losses'])}, "
            f"4+={int(row['streaks_4plus_losses'])}"
        )
    lines.append("")

    if not window_summary.empty:
        wl = window_summary.copy()
        wl["net_pnl"] = pd.to_numeric(wl["net_pnl"], errors="coerce")
        best = wl.sort_values("net_pnl", ascending=False).iloc[0]
        worst = wl.sort_values("net_pnl", ascending=True).iloc[0]
        lines.append(
            f"Best window:  {best['window']} {best['start']} -> {best['end']} "
            f"(net_pnl={float(best['net_pnl']):.2f}, net_pnl_pct={_fmt_pct(best['net_pnl_pct'])}, "
            f"trades={int(best['total_trades'])})"
        )
        lines.append(
            f"Worst window: {worst['window']} {worst['start']} -> {worst['end']} "
            f"(net_pnl={float(worst['net_pnl']):.2f}, net_pnl_pct={_fmt_pct(worst['net_pnl_pct'])}, "
            f"trades={int(worst['total_trades'])})"
        )
        lines.append("")

    if not hour_summary.empty:
        hl = hour_summary.copy()
        hl["net_pnl"] = pd.to_numeric(hl["net_pnl"], errors="coerce")
        best = hl.sort_values("net_pnl", ascending=False).iloc[0]
        worst = hl.sort_values("net_pnl", ascending=True).iloc[0]
        lines.append(
            f"Best hour:   {best['entry_hour_utc']} UTC  "
            f"(net_pnl={float(best['net_pnl']):.2f}, trades={int(best['trades'])}, "
            f"win_rate={float(best['win_rate']) * 100:.1f}%)"
        )
        lines.append(
            f"Worst hour:  {worst['entry_hour_utc']} UTC  "
            f"(net_pnl={float(worst['net_pnl']):.2f}, trades={int(worst['trades'])}, "
            f"win_rate={float(worst['win_rate']) * 100:.1f}%)"
        )
        lines.append("")

    if not killzone_summary.empty:
        kl = killzone_summary.copy()
        kl["net_pnl"] = pd.to_numeric(kl["net_pnl"], errors="coerce")
        best = kl.sort_values("net_pnl", ascending=False).iloc[0]
        worst = kl.sort_values("net_pnl", ascending=True).iloc[0]
        lines.append(
            f"Best killzone:  {best['killzone_name']}  "
            f"(net_pnl={float(best['net_pnl']):.2f}, trades={int(best['trades'])}, "
            f"win_rate={float(best['win_rate']) * 100:.1f}%)"
        )
        lines.append(
            f"Worst killzone: {worst['killzone_name']}  "
            f"(net_pnl={float(worst['net_pnl']):.2f}, trades={int(worst['trades'])}, "
            f"win_rate={float(worst['win_rate']) * 100:.1f}%)"
        )
        lines.append("")

    losing_risk = risk_bucket_summary[
        pd.to_numeric(risk_bucket_summary["net_pnl"], errors="coerce") < 0
    ] if not risk_bucket_summary.empty else risk_bucket_summary
    lines.append("Risk buckets losing money:")
    if losing_risk.empty:
        lines.append("  (none)")
    else:
        for _, row in losing_risk.iterrows():
            lines.append(
                f"  - {row['risk_bucket']}: net_pnl={float(row['net_pnl']):.2f}, "
                f"trades={int(row['trades'])}, win_rate={float(row['win_rate']) * 100:.1f}%"
            )
    lines.append("")

    losing_rf = reward_fee_summary[
        pd.to_numeric(reward_fee_summary["net_pnl"], errors="coerce") < 0
    ] if not reward_fee_summary.empty else reward_fee_summary
    lines.append("Reward-to-fee buckets losing money:")
    if losing_rf.empty:
        lines.append("  (none)")
    else:
        for _, row in losing_rf.iterrows():
            lines.append(
                f"  - {row['reward_fee_bucket']}: net_pnl={float(row['net_pnl']):.2f}, "
                f"trades={int(row['trades'])}, win_rate={float(row['win_rate']) * 100:.1f}%"
            )
    lines.append("")

    lines.append("Concentration check")
    lines.append("-------------------")
    lines.extend(
        _concentration_lines(
            trades=trades,
            window_summary=window_summary,
            hour_summary=hour_summary,
            killzone_summary=killzone_summary,
            risk_bucket_summary=risk_bucket_summary,
        )
    )
    lines.append("")

    lines.append("Notes")
    lines.append("-----")
    lines.append("- Experiment analyzed: long_only=True, blocked_entry_hours_utc=[15] (smc_v2).")
    lines.append("- Stops/take-profits come from the strategy's structured signal geometry.")
    lines.append("- This is diagnostics only, not a profitability claim.")
    return "\n".join(lines)


def _format_table(df: pd.DataFrame, columns: list[str]) -> str:
    cols = [col for col in columns if col in df.columns]
    if not cols:
        return "(no columns to display)"
    header = list(cols)
    body: list[list[str]] = [header]
    for _, row in df.iterrows():
        rendered: list[str] = []
        for col in cols:
            value = row[col]
            if value is None or _is_nan(value):
                rendered.append("-")
            elif isinstance(value, float):
                rendered.append(f"{value:.3f}" if abs(value) < 1000 else f"{value:.2f}")
            else:
                rendered.append(str(value))
        body.append(rendered)
    widths = [max(len(line[idx]) for line in body) for idx in range(len(cols))]
    formatted: list[str] = []
    for index, line in enumerate(body):
        formatted.append("  ".join(value.ljust(widths[idx]) for idx, value in enumerate(line)))
        if index == 0:
            formatted.append("  ".join("-" * width for width in widths))
    return "\n".join(formatted)


def _run_one_window(
    *,
    base_config: BacktestConfig,
    window_label: str,
    window: tuple[str, str],
    htf_timeframe: str,
    strategy_yaml: dict[str, Any],
    ltf_ohlcv: pd.DataFrame,
    htf_ohlcv: pd.DataFrame,
    engine_runs_root: Path,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    start, end = window
    config = replace(
        base_config,
        start=start,
        end=end,
        output_dir=str(engine_runs_root / window_label),
    )
    strategy = build_experiment_strategy(
        experiment=TARGET_EXPERIMENT,
        symbol=config.symbol,
        ltf_timeframe=config.timeframe,
        htf_timeframe=htf_timeframe,
        strategy_yaml=strategy_yaml,
    )
    result = BacktestEngine(config).run(
        ltf_ohlcv,
        strategy,
        htf_ohlcv=htf_ohlcv,
        htf_timeframe=htf_timeframe,
    )
    trade_rows: list[dict[str, Any]] = []
    for trade in result.trades:
        row = asdict(trade)
        row.update(
            {
                "window": window_label,
                "start": start,
                "end": end,
                "symbol": base_config.symbol,
                "timeframe": base_config.timeframe,
                "htf_timeframe": htf_timeframe,
            }
        )
        trade_rows.append(row)
    return trade_rows, result.summary


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="SMC v2 long_only_block_15 walk-forward failure diagnostics.",
    )
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--htf-timeframe", default=None)
    parser.add_argument(
        "--windows",
        required=True,
        help='Comma-separated windows "YYYY-MM-DD:YYYY-MM-DD,YYYY-MM-DD:YYYY-MM-DD".',
    )
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--allow-short", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--output-dir", default="logs/r4_8_failure_diagnostics")
    return parser


def _inject_config_defaults(args: argparse.Namespace, first_window: tuple[str, str]) -> None:
    args.start = first_window[0]
    args.end = first_window[1]
    args.use_smc_filter = False
    args.smc_features_path = None
    args.smc_lookback_bars = None
    args.require_bullish_bos = False


def main() -> None:
    overall_start = time.perf_counter()

    args = _build_parser().parse_args()
    output_dir = Path(args.output_dir)
    engine_runs_root = output_dir / "_engine_runs"
    output_dir.mkdir(parents=True, exist_ok=True)
    engine_runs_root.mkdir(parents=True, exist_ok=True)

    raw_config = _load_yaml(args.config)
    windows = parse_windows(args.windows)
    _inject_config_defaults(args, windows[0])
    args.output_dir = str(engine_runs_root)
    base_config = _build_backtest_config(args, raw_config)

    data_config = raw_config.get("data", {})
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    client = OKXClient(config=raw_config.get("exchange", {}))

    strategy_yaml = _load_strategy_yaml("smc_v2")
    htf_timeframe = str(
        _coalesce(args.htf_timeframe, strategy_yaml.get("htf_timeframe"), DEFAULT_HTF_TIMEFRAME)
    )

    print(
        f"SMC v2 long_only_block_15 diagnostics: symbol={base_config.symbol} "
        f"timeframe={base_config.timeframe} htf={htf_timeframe} windows={len(windows)}"
    )

    trade_rows: list[dict[str, Any]] = []
    window_metadata: dict[str, dict[str, Any]] = {}
    window_order: list[str] = []

    for window_index, window in enumerate(windows, start=1):
        start, end = window
        label = f"W{window_index}"
        window_order.append(label)
        print(f"\n=== Window {window_index}/{len(windows)} ({label}): {start} -> {end} ===")

        ltf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="LTF",
            symbol=base_config.symbol,
            timeframe=base_config.timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if ltf_ohlcv.empty:
            raise SystemExit(f"No LTF data for window {start} -> {end}")
        htf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="HTF",
            symbol=base_config.symbol,
            timeframe=htf_timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if htf_ohlcv.empty:
            raise SystemExit(f"No HTF data for window {start} -> {end}")

        t0 = time.perf_counter()
        rows, summary = _run_one_window(
            base_config=base_config,
            window_label=label,
            window=window,
            htf_timeframe=htf_timeframe,
            strategy_yaml=strategy_yaml,
            ltf_ohlcv=ltf_ohlcv,
            htf_ohlcv=htf_ohlcv,
            engine_runs_root=engine_runs_root,
        )
        elapsed = time.perf_counter() - t0
        trade_rows.extend(rows)
        window_metadata[label] = {
            "start": start,
            "end": end,
            "net_pnl_pct": float(summary["net_pnl_pct"]) * 100.0,
            "max_drawdown_pct": float(summary["max_drawdown_pct"]) * 100.0,
            "initial_equity": float(summary["initial_equity"]),
            "final_equity": float(summary["final_equity"]),
        }
        print(
            f"  {label}: trades={len(rows)}, "
            f"net_pnl_pct={window_metadata[label]['net_pnl_pct']:.2f}%, "
            f"max_dd={window_metadata[label]['max_drawdown_pct']:.2f}%, engine={elapsed:.1f}s"
        )

    if trade_rows:
        trades_df = pd.DataFrame(trade_rows)
    else:
        trades_df = pd.DataFrame(columns=TRADE_COLUMNS)
    trades_df = derive_time_columns(trades_df)
    trades_df = _ensure_columns(trades_df, TRADE_COLUMNS)
    trades_df = trades_df[TRADE_COLUMNS]

    (output_dir / "trades_by_window.csv")
    trades_df.to_csv(output_dir / "trades_by_window.csv", index=False)

    window_summary = aggregate_window_summary(trades_df, window_metadata, window_order)
    window_summary.to_csv(output_dir / "window_summary.csv", index=False)

    hour_summary = aggregate_hour_summary(trades_df)
    hour_summary.to_csv(output_dir / "hour_summary.csv", index=False)

    killzone_summary = aggregate_killzone_summary(trades_df)
    killzone_summary.to_csv(output_dir / "killzone_summary.csv", index=False)

    exit_reason_summary = aggregate_exit_reason_summary(trades_df)
    exit_reason_summary.to_csv(output_dir / "exit_reason_summary.csv", index=False)

    risk_bucket_summary = aggregate_risk_bucket_summary(trades_df)
    risk_bucket_summary.to_csv(output_dir / "risk_bucket_summary.csv", index=False)

    reward_fee_summary = aggregate_reward_fee_summary(trades_df)
    reward_fee_summary.to_csv(output_dir / "reward_fee_summary.csv", index=False)

    streak_summary = build_streak_summary(trades_df, window_order)
    streak_summary.to_csv(output_dir / "streak_summary.csv", index=False)

    top_winners = build_top_n(trades_df, n=TOP_N, ascending=False)
    top_winners.to_csv(output_dir / "top_winners.csv", index=False)

    top_losers = build_top_n(trades_df, n=TOP_N, ascending=True)
    top_losers.to_csv(output_dir / "top_losers.csv", index=False)

    period_start = windows[0][0]
    period_end = windows[-1][1]
    report_text = build_report_text(
        trades=trades_df,
        window_summary=window_summary,
        hour_summary=hour_summary,
        killzone_summary=killzone_summary,
        exit_reason_summary=exit_reason_summary,
        risk_bucket_summary=risk_bucket_summary,
        reward_fee_summary=reward_fee_summary,
        streak_summary=streak_summary,
        symbol=base_config.symbol,
        timeframe=base_config.timeframe,
        htf_timeframe=htf_timeframe,
        period_start=period_start,
        period_end=period_end,
    )
    (output_dir / "diagnostics_report.txt").write_text(report_text, encoding="utf-8")

    print("\n=== Window summary ===")
    print(
        _format_table(
            window_summary,
            [
                "window",
                "start",
                "end",
                "total_trades",
                "net_pnl",
                "net_pnl_pct",
                "win_rate",
                "profit_factor",
                "max_drawdown_pct",
                "max_consecutive_losses",
            ],
        )
    )
    print("\n=== Hour summary ===")
    print(_format_table(hour_summary, HOUR_SUMMARY_COLUMNS))
    print("\n=== Killzone summary ===")
    print(_format_table(killzone_summary, KILLZONE_SUMMARY_COLUMNS))
    print("\n=== Risk bucket summary ===")
    print(_format_table(risk_bucket_summary, RISK_BUCKET_SUMMARY_COLUMNS))

    print("\n=== Diagnostics report ===")
    print(report_text)

    total_elapsed = time.perf_counter() - overall_start
    print(f"\nOutputs: {output_dir}")
    print(f"Total runtime: {total_elapsed:.1f}s")


if __name__ == "__main__":
    main()
