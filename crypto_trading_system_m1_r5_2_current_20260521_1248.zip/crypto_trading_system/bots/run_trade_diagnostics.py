"""Grouped diagnostics for offline backtest trade logs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd


OPTIONAL_AVERAGE_COLUMNS = {
    "rr": "avg_rr",
    "risk_pct": "avg_risk_pct",
    "target_pct": "avg_target_pct",
}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Analyze grouped performance from backtest_trades.csv.")
    parser.add_argument("--trades", default="logs/backtest_trades.csv")
    parser.add_argument("--summary", default="logs/backtest_summary.json")
    parser.add_argument("--output", default="logs/trade_diagnostics_summary.csv")
    parser.add_argument("--json-output", default="logs/trade_diagnostics_summary.json")
    return parser


def load_summary(path: str | Path) -> dict[str, Any]:
    summary_path = Path(path)
    if not summary_path.exists():
        return {}
    return json.loads(summary_path.read_text(encoding="utf-8"))


def load_trades(path: str | Path) -> pd.DataFrame:
    trades = pd.read_csv(path)
    if trades.empty:
        return trades

    trades = trades.copy()
    for column in [
        "net_pnl",
        "bars_held",
        "rr",
        "risk_pct",
        "target_pct",
        "reward_to_fee_ratio",
    ]:
        if column in trades.columns:
            trades[column] = pd.to_numeric(trades[column], errors="coerce")

    if "entry_time" in trades.columns:
        entry_time = pd.to_datetime(trades["entry_time"], utc=True, errors="coerce")
        trades["entry_hour_utc"] = entry_time.dt.hour
        trades["entry_weekday_utc"] = entry_time.dt.day_name()
    return trades


def profit_factor(net_pnls: pd.Series) -> float | None:
    gross_profit = float(net_pnls[net_pnls > 0].sum())
    gross_loss = float(net_pnls[net_pnls < 0].sum())
    if gross_loss < 0:
        return gross_profit / abs(gross_loss)
    return None


def _group_value(keys: Any) -> str:
    if not isinstance(keys, tuple):
        keys = (keys,)
    return " | ".join("unknown" if pd.isna(key) else str(key) for key in keys)


def _metrics(group: pd.DataFrame) -> dict[str, Any]:
    net_pnls = pd.to_numeric(group["net_pnl"], errors="coerce").fillna(0.0)
    wins = int((net_pnls > 0).sum())
    losses = int((net_pnls < 0).sum())
    row: dict[str, Any] = {
        "trades": int(len(group)),
        "wins": wins,
        "losses": losses,
        "win_rate": wins / len(group) if len(group) else 0.0,
        "total_net_pnl": float(net_pnls.sum()),
        "avg_net_pnl": float(net_pnls.mean()) if len(group) else 0.0,
        "median_net_pnl": float(net_pnls.median()) if len(group) else 0.0,
        "max_win": float(net_pnls.max()) if len(group) else 0.0,
        "max_loss": float(net_pnls.min()) if len(group) else 0.0,
        "profit_factor": profit_factor(net_pnls),
        "avg_bars_held": float(group["bars_held"].mean()) if "bars_held" in group.columns else None,
    }
    for source_column, output_column in OPTIONAL_AVERAGE_COLUMNS.items():
        row[output_column] = float(group[source_column].mean()) if source_column in group.columns else None
    return row


def grouped_performance(trades: pd.DataFrame) -> pd.DataFrame:
    group_specs = [
        ("side", ["side"]),
        ("exit_reason", ["exit_reason"]),
        ("killzone_name", ["killzone_name"]),
        ("side_killzone", ["side", "killzone_name"]),
        ("entry_hour_utc", ["entry_hour_utc"]),
        ("entry_weekday_utc", ["entry_weekday_utc"]),
        ("entry_reason", ["entry_reason"]),
        ("strategy_version", ["strategy_version"]),
    ]
    rows: list[dict[str, Any]] = []
    if trades.empty or "net_pnl" not in trades.columns:
        return pd.DataFrame(rows)

    for group_type, columns in group_specs:
        missing = [column for column in columns if column not in trades.columns]
        if missing:
            continue
        frame = trades.copy()
        for column in columns:
            frame[column] = frame[column].fillna("unknown")
        grouped = frame.groupby(columns, dropna=False, sort=True)
        for keys, group in grouped:
            rows.append(
                {
                    "group_type": group_type,
                    "group_columns": ",".join(columns),
                    "group_value": _group_value(keys),
                    **_metrics(group),
                }
            )
    return pd.DataFrame(rows)


def top_level_summary(trades: pd.DataFrame, summary: dict[str, Any]) -> dict[str, Any]:
    net_pnls = pd.to_numeric(trades.get("net_pnl", pd.Series(dtype=float)), errors="coerce").fillna(0.0)
    wins = int((net_pnls > 0).sum())
    total_trades = int(len(trades))
    return {
        "total_trades": int(summary.get("total_trades", total_trades)),
        "net_pnl": float(summary.get("net_pnl", net_pnls.sum())),
        "win_rate": float(summary.get("win_rate", wins / total_trades if total_trades else 0.0)),
        "profit_factor": summary.get("profit_factor", profit_factor(net_pnls)),
        "max_drawdown_pct": float(summary.get("max_drawdown_pct", 0.0)),
    }


def save_diagnostics(
    grouped: pd.DataFrame,
    top_level: dict[str, Any],
    output: str | Path,
    json_output: str | Path,
) -> None:
    output_path = Path(output)
    json_path = Path(json_output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.parent.mkdir(parents=True, exist_ok=True)

    grouped.to_csv(output_path, index=False)
    records = grouped.where(pd.notna(grouped), None).to_dict(orient="records")
    json_path.write_text(
        json.dumps({"top_level": top_level, "groups": records}, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _format_pct(value: Any) -> str:
    if value is None or pd.isna(value):
        return "n/a"
    return f"{float(value) * 100:.2f}%"


def _format_number(value: Any) -> str:
    if value is None or pd.isna(value):
        return "n/a"
    return f"{float(value):.4f}"


def _print_group(grouped: pd.DataFrame, group_type: str, title: str) -> None:
    table = grouped[grouped["group_type"] == group_type].copy()
    if table.empty:
        return

    table = table.sort_values(["total_net_pnl", "trades"], ascending=[False, False])
    display_columns = ["group_value", "trades", "win_rate", "total_net_pnl", "profit_factor", "avg_bars_held"]
    display = table[display_columns].copy()
    display["win_rate"] = display["win_rate"].map(_format_pct)
    for column in ["total_net_pnl", "profit_factor", "avg_bars_held"]:
        display[column] = display[column].map(_format_number)
    print(f"\n{title}")
    print(display.to_string(index=False))


def print_diagnostics(top_level: dict[str, Any], grouped: pd.DataFrame) -> None:
    print("Trade Diagnostics")
    print(f"Total trades: {top_level['total_trades']}")
    print(f"Net PnL: {_format_number(top_level['net_pnl'])}")
    print(f"Win rate: {_format_pct(top_level['win_rate'])}")
    print(f"Profit factor: {_format_number(top_level['profit_factor'])}")
    print(f"Max drawdown: {_format_pct(top_level['max_drawdown_pct'])}")

    _print_group(grouped, "side", "By Side")
    _print_group(grouped, "killzone_name", "By Killzone")
    _print_group(grouped, "side_killzone", "By Side + Killzone")
    _print_group(grouped, "exit_reason", "By Exit Reason")
    _print_group(grouped, "entry_hour_utc", "By Entry Hour UTC")


def main() -> None:
    args = _build_parser().parse_args()
    trades = load_trades(args.trades)
    summary = load_summary(args.summary)
    grouped = grouped_performance(trades)
    top_level = top_level_summary(trades, summary)
    save_diagnostics(grouped, top_level, args.output, args.json_output)
    print_diagnostics(top_level, grouped)
    print("\nOutputs")
    print(f"CSV: {args.output}")
    print(f"JSON: {args.json_output}")


if __name__ == "__main__":
    main()
