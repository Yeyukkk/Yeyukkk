"""R5.2 spot-only diagnostics for failed SMC v2 validation windows.

This script analyzes existing R5.1 aggregate CSVs and any available local
trade/OHLCV CSVs. It never runs a backtest, never contacts private endpoints,
and refuses contract-style symbols. Research only.
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

from bots.run_smc_v2_failure_diagnostics import (
    assign_reward_fee_bucket,
    assign_risk_bucket,
    compute_profit_factor,
    derive_time_columns,
    max_consecutive_losses,
)
from core.data.ohlcv_cache import load_ohlcv_cache, ohlcv_cache_path


DEFAULT_FAILED_WINDOWS = "2023-07-01:2023-09-01,2023-11-01:2024-01-01"
DEFAULT_EXPERIMENT = "block_hours_7_8_13_15"
DEFAULT_REFERENCE = "reference_long_only_block_15"

SUMMARY_COLUMNS = [
    "start",
    "end",
    "experiment",
    "reference_net_pnl_pct",
    "experiment_net_pnl_pct",
    "damage_reduction_pct",
    "reference_max_drawdown_pct",
    "experiment_max_drawdown_pct",
    "reference_total_trades",
    "experiment_total_trades",
    "reference_win_rate",
    "experiment_win_rate",
    "reference_profit_factor",
    "experiment_profit_factor",
    "window_return_pct",
    "volatility_close_to_close_pct",
    "avg_range_pct",
    "btc_max_drawdown_pct",
    "trend_chop_proxy",
    "ohlcv_cache_path",
]

TRADE_BREAKDOWN_COLUMNS = [
    "window",
    "group_type",
    "group",
    "trades",
    "net_pnl",
    "avg_net_pnl",
    "win_rate",
    "profit_factor",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Analyze R5.2 BTC/USDT spot failed validation windows.")
    parser.add_argument("--details", default="logs/r5_1_spot_extended_validation_details.csv")
    parser.add_argument("--results", default="logs/r5_1_spot_extended_validation_results.csv")
    parser.add_argument("--symbol", default="BTC/USDT")
    parser.add_argument("--timeframe", default="15m")
    parser.add_argument("--htf-timeframe", default="1h")
    parser.add_argument("--experiment", default=DEFAULT_EXPERIMENT)
    parser.add_argument("--reference-experiment", default=DEFAULT_REFERENCE)
    parser.add_argument("--failed-windows", default=DEFAULT_FAILED_WINDOWS)
    parser.add_argument("--trade-files", default=None, help="Optional comma-separated backtest_trades.csv paths.")
    parser.add_argument("--ohlcv-cache-dir", default="data/ohlcv")
    parser.add_argument("--output-summary", default="logs/r5_2_spot_failure_window_diagnostics_summary.csv")
    parser.add_argument("--output-report", default="logs/r5_2_spot_failure_window_diagnostics_report.txt")
    parser.add_argument("--output-trade-breakdown", default="logs/r5_2_spot_failure_window_trade_breakdown.csv")
    parser.add_argument("--output-top-losers", default="logs/r5_2_spot_failure_window_top_losers.csv")
    return parser


def validate_spot_symbol(symbol: str) -> None:
    if ":" in symbol:
        raise SystemExit("R5.2 is spot-only. Use BTC/USDT, not BTC/USDT:USDT.")


def parse_windows(raw: str) -> list[tuple[str, str]]:
    windows: list[tuple[str, str]] = []
    for item in raw.split(","):
        token = item.strip()
        if not token:
            continue
        if ":" not in token:
            raise ValueError(f"Invalid window: {token}")
        start, end = token.split(":", 1)
        windows.append((start.strip(), end.strip()))
    if not windows:
        raise ValueError("At least one failed window is required")
    return windows


def _numeric(value: Any, default: float = 0.0) -> float:
    if value is None or pd.isna(value):
        return default
    return float(value)


def _window_label(start: str, end: str) -> str:
    return f"{start}->{end}"


def _find_detail_row(details: pd.DataFrame, experiment: str, start: str, end: str) -> pd.Series:
    rows = details[
        (details["experiment"] == experiment)
        & (details["start"].astype(str) == start)
        & (details["end"].astype(str) == end)
    ]
    if rows.empty:
        raise ValueError(f"Missing detail row for {experiment} {start}:{end}")
    return rows.iloc[0]


def market_regime_summary(
    *,
    symbol: str,
    timeframe: str,
    start: str,
    end: str,
    cache_dir: str | Path,
) -> dict[str, Any]:
    path = ohlcv_cache_path("okx", symbol, timeframe, start, end, cache_dir=cache_dir)
    if not path.exists():
        return {
            "window_return_pct": pd.NA,
            "volatility_close_to_close_pct": pd.NA,
            "avg_range_pct": pd.NA,
            "btc_max_drawdown_pct": pd.NA,
            "trend_chop_proxy": pd.NA,
            "ohlcv_cache_path": str(path),
        }

    ohlcv = load_ohlcv_cache(path)
    if len(ohlcv) < 2:
        return {
            "window_return_pct": pd.NA,
            "volatility_close_to_close_pct": pd.NA,
            "avg_range_pct": pd.NA,
            "btc_max_drawdown_pct": pd.NA,
            "trend_chop_proxy": pd.NA,
            "ohlcv_cache_path": str(path),
        }

    close = pd.to_numeric(ohlcv["close"], errors="coerce").dropna()
    high = pd.to_numeric(ohlcv["high"], errors="coerce")
    low = pd.to_numeric(ohlcv["low"], errors="coerce")
    returns = close.pct_change().dropna()
    window_return_pct = ((close.iloc[-1] / close.iloc[0]) - 1.0) * 100.0
    volatility_pct = returns.std(ddof=0) * 100.0 if not returns.empty else 0.0
    avg_range_pct = (((high - low) / close) * 100.0).dropna().mean()
    drawdown = (close / close.cummax()) - 1.0
    btc_max_drawdown_pct = abs(drawdown.min()) * 100.0
    path_length = returns.abs().sum()
    trend_chop_proxy = abs((close.iloc[-1] / close.iloc[0]) - 1.0) / path_length if path_length else pd.NA

    return {
        "window_return_pct": float(window_return_pct),
        "volatility_close_to_close_pct": float(volatility_pct),
        "avg_range_pct": float(avg_range_pct),
        "btc_max_drawdown_pct": float(btc_max_drawdown_pct),
        "trend_chop_proxy": float(trend_chop_proxy) if not pd.isna(trend_chop_proxy) else pd.NA,
        "ohlcv_cache_path": str(path),
    }


def build_failed_window_summary(
    *,
    details: pd.DataFrame,
    failed_windows: list[tuple[str, str]],
    experiment: str,
    reference_experiment: str,
    symbol: str,
    timeframe: str,
    cache_dir: str | Path,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for start, end in failed_windows:
        reference = _find_detail_row(details, reference_experiment, start, end)
        current = _find_detail_row(details, experiment, start, end)
        regime = market_regime_summary(
            symbol=symbol,
            timeframe=timeframe,
            start=start,
            end=end,
            cache_dir=cache_dir,
        )
        reference_pnl = _numeric(reference["net_pnl_pct"])
        current_pnl = _numeric(current["net_pnl_pct"])
        rows.append(
            {
                "start": start,
                "end": end,
                "experiment": experiment,
                "reference_net_pnl_pct": reference_pnl,
                "experiment_net_pnl_pct": current_pnl,
                "damage_reduction_pct": current_pnl - reference_pnl,
                "reference_max_drawdown_pct": _numeric(reference["max_drawdown_pct"]),
                "experiment_max_drawdown_pct": _numeric(current["max_drawdown_pct"]),
                "reference_total_trades": int(reference["total_trades"]),
                "experiment_total_trades": int(current["total_trades"]),
                "reference_win_rate": _numeric(reference["win_rate"]),
                "experiment_win_rate": _numeric(current["win_rate"]),
                "reference_profit_factor": _numeric(reference["profit_factor"]),
                "experiment_profit_factor": _numeric(current["profit_factor"]),
                **regime,
            }
        )
    return pd.DataFrame(rows, columns=SUMMARY_COLUMNS)


def failure_rankings(details: pd.DataFrame, experiment: str) -> dict[str, pd.DataFrame]:
    scoped = details[details["experiment"] == experiment].copy()
    return {
        "worst_net_pnl_pct": scoped.sort_values("net_pnl_pct", ascending=True).head(5),
        "worst_profit_factor": scoped.sort_values("profit_factor", ascending=True).head(5),
        "worst_max_drawdown_pct": scoped.sort_values("max_drawdown_pct", ascending=False).head(5),
    }


def _trade_files_from_arg(raw: str | None) -> list[Path]:
    if not raw:
        return []
    return [Path(item.strip()) for item in raw.split(",") if item.strip()]


def load_trade_files(paths: Iterable[Path]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for path in paths:
        if path.exists():
            frame = pd.read_csv(path)
            frame["source_file"] = str(path)
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    trades = pd.concat(frames, ignore_index=True)
    return derive_time_columns(trades)


def filter_failed_window_trades(
    trades: pd.DataFrame,
    failed_windows: list[tuple[str, str]],
) -> pd.DataFrame:
    if trades.empty or "entry_time" not in trades.columns:
        return trades.iloc[0:0].copy()

    df = trades.copy()
    entry_time = pd.to_datetime(df["entry_time"], utc=True, errors="coerce")
    masks = []
    for start, end in failed_windows:
        start_ts = pd.Timestamp(start, tz="UTC")
        end_ts = pd.Timestamp(end, tz="UTC")
        mask = (entry_time >= start_ts) & (entry_time < end_ts)
        df.loc[mask, "window"] = _window_label(start, end)
        masks.append(mask)
    if not masks:
        return df.iloc[0:0].copy()
    combined = masks[0]
    for mask in masks[1:]:
        combined = combined | mask
    return df[combined].copy()


def _group_trade_stats(group: pd.DataFrame) -> dict[str, Any]:
    net_pnl = pd.to_numeric(group.get("net_pnl", pd.Series(dtype=float)), errors="coerce").dropna()
    trades = len(group)
    return {
        "trades": trades,
        "net_pnl": float(net_pnl.sum()) if not net_pnl.empty else 0.0,
        "avg_net_pnl": float(net_pnl.mean()) if not net_pnl.empty else 0.0,
        "win_rate": float((net_pnl > 0).sum()) / trades if trades else 0.0,
        "profit_factor": compute_profit_factor(net_pnl.tolist()) if trades else None,
    }


def trade_breakdown(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=TRADE_BREAKDOWN_COLUMNS)

    df = trades.copy()
    if "risk_pct" in df.columns:
        df["risk_bucket"] = df["risk_pct"].apply(assign_risk_bucket)
    if "reward_to_fee_ratio" in df.columns:
        df["reward_fee_bucket"] = df["reward_to_fee_ratio"].apply(assign_reward_fee_bucket)

    groups = [
        ("entry_hour_utc", "entry_hour_utc"),
        ("killzone", "killzone_name"),
        ("exit_reason", "exit_reason"),
        ("risk_bucket", "risk_bucket"),
        ("reward_to_fee_bucket", "reward_fee_bucket"),
    ]
    rows: list[dict[str, Any]] = []
    for window, window_group in df.groupby("window", dropna=False):
        for group_type, column in groups:
            if column not in window_group.columns:
                continue
            for value, group in window_group.groupby(column, dropna=False):
                label = "unknown" if pd.isna(value) else str(value)
                rows.append(
                    {
                        "window": "unknown" if pd.isna(window) else str(window),
                        "group_type": group_type,
                        "group": label,
                        **_group_trade_stats(group),
                    }
                )
    return pd.DataFrame(rows, columns=TRADE_BREAKDOWN_COLUMNS)


def top_losing_trades(trades: pd.DataFrame, limit: int = 10) -> pd.DataFrame:
    if trades.empty or "net_pnl" not in trades.columns:
        return pd.DataFrame()
    df = trades.copy()
    df["net_pnl"] = pd.to_numeric(df["net_pnl"], errors="coerce")
    columns = [
        column
        for column in [
            "window",
            "trade_id",
            "side",
            "entry_time",
            "exit_time",
            "net_pnl",
            "exit_reason",
            "entry_hour_utc",
            "killzone_name",
            "risk_pct",
            "reward_to_fee_ratio",
            "source_file",
        ]
        if column in df.columns
    ]
    return df.sort_values("net_pnl", ascending=True).head(limit)[columns]


def _format_frame(frame: pd.DataFrame, columns: list[str] | None = None) -> str:
    if frame.empty:
        return "(no rows)"
    display = frame[columns] if columns else frame
    return display.to_string(index=False)


def local_trade_regeneration_commands(
    *,
    symbol: str,
    timeframe: str,
    htf_timeframe: str,
    failed_windows: list[tuple[str, str]],
) -> str:
    commands = [
        "cd ~/Downloads/crypto_trading_system",
        "conda activate crypto_system",
    ]
    for start, end in failed_windows:
        out_dir = f"logs/r5_2_failed_window_trades/{DEFAULT_EXPERIMENT}_{start}_{end}"
        commands.append(
            "python -m bots.run_backtest "
            "--config config/paper.yaml "
            "--strategy smc_v2 "
            f"--symbol {symbol} "
            f"--timeframe {timeframe} "
            f"--htf-timeframe {htf_timeframe} "
            f"--start {start} "
            f"--end {end} "
            "--initial-equity 1000 "
            "--leverage 10 "
            "--max-margin-pct 0.20 "
            "--fee-rate 0.0005 "
            "--slippage-bps 2 "
            "--allow-short "
            "--smc-long-only "
            "--smc-block-entry-hours-utc 7,8,13,15 "
            f"--output-dir {out_dir}"
        )
    trade_files = ",".join(
        f"logs/r5_2_failed_window_trades/{DEFAULT_EXPERIMENT}_{start}_{end}/backtest_trades.csv"
        for start, end in failed_windows
    )
    commands.append(
        "python -u -m bots.run_r5_2_spot_failure_window_diagnostics "
        "--details logs/r5_1_spot_extended_validation_details.csv "
        "--results logs/r5_1_spot_extended_validation_results.csv "
        f"--symbol {symbol} "
        f"--timeframe {timeframe} "
        f"--htf-timeframe {htf_timeframe} "
        f"--failed-windows \"{','.join(f'{s}:{e}' for s, e in failed_windows)}\" "
        f"--trade-files \"{trade_files}\""
    )
    return "\n".join(commands)


def build_report(
    *,
    results: pd.DataFrame,
    details: pd.DataFrame,
    failed_summary: pd.DataFrame,
    failed_windows: list[tuple[str, str]],
    experiment: str,
    reference_experiment: str,
    trade_breakdown_df: pd.DataFrame,
    failed_trades: pd.DataFrame,
    symbol: str,
    timeframe: str,
    htf_timeframe: str,
) -> str:
    rankings = failure_rankings(details, experiment)
    reference = results[results["experiment"] == reference_experiment]
    current = results[results["experiment"] == experiment]

    lines = [
        "R5.2 Spot Failure-Window Diagnostics",
        "Research only. This is not a profitability claim.",
        f"Symbol: {symbol} spot only. Timeframe: {timeframe}. HTF: {htf_timeframe}.",
        "",
        "Failed-window comparison:",
        _format_frame(
            failed_summary,
            [
                "start",
                "end",
                "reference_net_pnl_pct",
                "experiment_net_pnl_pct",
                "damage_reduction_pct",
                "reference_total_trades",
                "experiment_total_trades",
                "reference_profit_factor",
                "experiment_profit_factor",
            ],
        ),
        "",
        "R5.1 aggregate reference:",
        _format_frame(
            pd.concat([reference, current], ignore_index=True),
            [
                "experiment",
                "positive_windows",
                "windows",
                "avg_net_pnl_pct",
                "worst_net_pnl_pct",
                "avg_max_drawdown_pct",
                "total_trades",
                "avg_profit_factor",
            ],
        ),
        "",
        "Failure ranking by net_pnl_pct:",
        _format_frame(rankings["worst_net_pnl_pct"], ["start", "end", "net_pnl_pct", "total_trades", "profit_factor"]),
        "",
        "Failure ranking by profit_factor:",
        _format_frame(rankings["worst_profit_factor"], ["start", "end", "net_pnl_pct", "total_trades", "profit_factor"]),
        "",
        "Failure ranking by max_drawdown_pct:",
        _format_frame(rankings["worst_max_drawdown_pct"], ["start", "end", "max_drawdown_pct", "net_pnl_pct", "total_trades"]),
        "",
        "Market regime summary for failed windows:",
        _format_frame(
            failed_summary,
            [
                "start",
                "end",
                "window_return_pct",
                "volatility_close_to_close_pct",
                "avg_range_pct",
                "btc_max_drawdown_pct",
                "trend_chop_proxy",
            ],
        ),
        "",
    ]

    damage_reduced_all = bool((failed_summary["damage_reduction_pct"] > 0).all()) if not failed_summary.empty else False
    few_trades = bool((failed_summary["experiment_total_trades"] <= 10).all()) if not failed_summary.empty else False
    lines.extend(
        [
            "Answers:",
            f"- Did block_hours reduce damage versus reference? {'Yes' if damage_reduced_all else 'No/mixed'}; see damage_reduction_pct.",
            f"- Did failure come from too few trades? {'Partly yes: failed windows have small trade counts.' if few_trades else 'Not primarily from trade count alone.'}",
        ]
    )

    if trade_breakdown_df.empty:
        lines.extend(
            [
                "- Did failure cluster by hour? Trade-level data is unavailable in the supplied files.",
                "- Did failure cluster by killzone? Trade-level data is unavailable in the supplied files.",
                "- Did failure cluster by risk/reward bucket? Trade-level data is unavailable in the supplied files.",
                "- Is this more likely a regime issue than an hour-filter issue? Current aggregate + OHLCV data suggests this needs trade-level confirmation.",
                "- What should be tested next? Regenerate only the failed-window trade files, then rerun this diagnostics script with --trade-files.",
                "",
                "Trade-level diagnostics require these local Terminal commands; do not run them inside Codex if they exceed your time budget:",
                local_trade_regeneration_commands(
                    symbol=symbol,
                    timeframe=timeframe,
                    htf_timeframe=htf_timeframe,
                    failed_windows=failed_windows,
                ),
            ]
        )
    else:
        pnl_by_hour = trade_breakdown_df[trade_breakdown_df["group_type"] == "entry_hour_utc"].sort_values("net_pnl")
        pnl_by_killzone = trade_breakdown_df[trade_breakdown_df["group_type"] == "killzone"].sort_values("net_pnl")
        pnl_by_risk = trade_breakdown_df[trade_breakdown_df["group_type"] == "risk_bucket"].sort_values("net_pnl")
        pnl_by_reward = trade_breakdown_df[trade_breakdown_df["group_type"] == "reward_to_fee_bucket"].sort_values("net_pnl")
        ordered_trades = failed_trades.sort_values("entry_time") if "entry_time" in failed_trades.columns else failed_trades
        longest_streak = max_consecutive_losses(pd.to_numeric(ordered_trades["net_pnl"], errors="coerce").tolist())
        lines.extend(
            [
                "- Did failure cluster by hour? See lowest entry_hour_utc groups below.",
                _format_frame(pnl_by_hour.head(10)),
                "- Did failure cluster by killzone? See killzone groups below.",
                _format_frame(pnl_by_killzone),
                "- Did failure cluster by risk/reward bucket? See risk and reward-to-fee groups below.",
                _format_frame(pnl_by_risk),
                _format_frame(pnl_by_reward),
                f"- Longest losing streak in supplied trade files: {longest_streak}.",
                "- Is this more likely a regime issue than an hour-filter issue? Compare the OHLCV regime table with clustered trade groups before adding filters.",
                "- What should be tested next? Only investigate the worst clusters shown here; do not add broad filters blindly.",
            ]
        )

    lines.append("")
    lines.append("Explicit statement: this is research only, not a profitability claim.")
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> dict[str, Path | pd.DataFrame | str]:
    validate_spot_symbol(args.symbol)
    details_path = Path(args.details)
    results_path = Path(args.results)
    if not details_path.exists():
        raise FileNotFoundError(f"Missing details CSV: {details_path}")
    if not results_path.exists():
        raise FileNotFoundError(f"Missing results CSV: {results_path}")

    details = pd.read_csv(details_path)
    results = pd.read_csv(results_path)
    failed_windows = parse_windows(args.failed_windows)

    summary = build_failed_window_summary(
        details=details,
        failed_windows=failed_windows,
        experiment=args.experiment,
        reference_experiment=args.reference_experiment,
        symbol=args.symbol,
        timeframe=args.timeframe,
        cache_dir=args.ohlcv_cache_dir,
    )

    trades = load_trade_files(_trade_files_from_arg(args.trade_files))
    failed_trades = filter_failed_window_trades(trades, failed_windows)
    breakdown = trade_breakdown(failed_trades)
    top_losers = top_losing_trades(failed_trades)

    summary_path = Path(args.output_summary)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary.to_csv(summary_path, index=False)

    if not breakdown.empty:
        breakdown_path = Path(args.output_trade_breakdown)
        breakdown_path.parent.mkdir(parents=True, exist_ok=True)
        breakdown.to_csv(breakdown_path, index=False)
    else:
        breakdown_path = Path(args.output_trade_breakdown)

    if not top_losers.empty:
        top_losers_path = Path(args.output_top_losers)
        top_losers_path.parent.mkdir(parents=True, exist_ok=True)
        top_losers.to_csv(top_losers_path, index=False)
    else:
        top_losers_path = Path(args.output_top_losers)

    report = build_report(
        results=results,
        details=details,
        failed_summary=summary,
        failed_windows=failed_windows,
        experiment=args.experiment,
        reference_experiment=args.reference_experiment,
        trade_breakdown_df=breakdown,
        failed_trades=failed_trades,
        symbol=args.symbol,
        timeframe=args.timeframe,
        htf_timeframe=args.htf_timeframe,
    )
    report_path = Path(args.output_report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")

    return {
        "summary_path": summary_path,
        "report_path": report_path,
        "breakdown_path": breakdown_path,
        "top_losers_path": top_losers_path,
        "summary": summary,
        "report": report,
    }


def main() -> None:
    args = build_parser().parse_args()
    outputs = run(args)
    print("R5.2 spot failure-window diagnostics complete.")
    print(f"Summary: {outputs['summary_path']}")
    print(f"Report: {outputs['report_path']}")
    print("")
    print(str(outputs["report"]))


if __name__ == "__main__":
    main()
