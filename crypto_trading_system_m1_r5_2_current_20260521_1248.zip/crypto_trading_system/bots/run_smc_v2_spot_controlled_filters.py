"""R5 spot-only controlled SMC v2 filter experiments.

This runner is research/backtesting only. It uses public OKX OHLCV data,
refuses contract-style symbols, and never places orders or touches private
endpoints.
"""

from __future__ import annotations

import argparse
import time
from dataclasses import dataclass, replace
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd

from bots.run_backtest import (
    DEFAULT_HTF_TIMEFRAME,
    _build_backtest_config,
    _build_smc_v2,
    _coalesce,
    _load_or_fetch_ohlcv,
    _load_strategy_yaml,
    _load_yaml,
)
from bots.run_smc_v2_walk_forward import parse_windows
from core.backtest import BacktestConfig, BacktestEngine
from core.data import OKXClient
from core.strategy import SMCStrategyV2


ENGINE_RUN_OUTPUT_DIR = "logs/_r5_spot_filters_tmp"
DEFAULT_REPORT_OUTPUT = "logs/r5_spot_controlled_filters_report.txt"


@dataclass(frozen=True)
class SpotFilterExperiment:
    name: str
    long_only: bool = True
    blocked_entry_hours_utc: tuple[int, ...] = ()
    allowed_killzones: tuple[str, ...] | None = None
    blocked_killzones: tuple[str, ...] | None = None
    min_reward_to_fee_ratio: float | None = None
    min_risk_pct: float | None = None
    max_risk_pct: float | None = None


SPOT_FILTER_EXPERIMENTS: list[SpotFilterExperiment] = [
    SpotFilterExperiment(
        name="reference_long_only_block_15",
        blocked_entry_hours_utc=(15,),
    ),
    SpotFilterExperiment(
        name="new_york_only",
        allowed_killzones=("new_york",),
    ),
    SpotFilterExperiment(
        name="block_london",
        blocked_killzones=("london",),
    ),
    SpotFilterExperiment(
        name="block_hours_7_8_13_15",
        blocked_entry_hours_utc=(7, 8, 13, 15),
    ),
    SpotFilterExperiment(
        name="min_reward_to_fee_5",
        blocked_entry_hours_utc=(15,),
        min_reward_to_fee_ratio=5.0,
    ),
    SpotFilterExperiment(
        name="risk_between_025_075",
        blocked_entry_hours_utc=(15,),
        min_risk_pct=0.0025,
        max_risk_pct=0.0075,
    ),
    SpotFilterExperiment(
        name="new_york_only_reward_to_fee_5",
        allowed_killzones=("new_york",),
        min_reward_to_fee_ratio=5.0,
    ),
    SpotFilterExperiment(
        name="new_york_only_risk_025_075",
        allowed_killzones=("new_york",),
        min_risk_pct=0.0025,
        max_risk_pct=0.0075,
    ),
    SpotFilterExperiment(
        name="new_york_only_reward5_risk_025_075",
        allowed_killzones=("new_york",),
        min_reward_to_fee_ratio=5.0,
        min_risk_pct=0.0025,
        max_risk_pct=0.0075,
    ),
]


DETAILS_COLUMNS: list[str] = [
    "experiment",
    "symbol",
    "timeframe",
    "htf_timeframe",
    "start",
    "end",
    "final_equity",
    "net_pnl",
    "net_pnl_pct",
    "max_drawdown_pct",
    "total_trades",
    "win_rate",
    "profit_factor",
    "long_trades",
    "short_trades",
]


RESULTS_COLUMNS: list[str] = [
    "experiment",
    "windows",
    "positive_windows",
    "avg_net_pnl_pct",
    "median_net_pnl_pct",
    "worst_net_pnl_pct",
    "best_net_pnl_pct",
    "avg_max_drawdown_pct",
    "worst_max_drawdown_pct",
    "total_trades",
    "avg_win_rate",
    "avg_profit_factor",
    "total_long_trades",
    "total_short_trades",
    "score",
]


ROBUSTNESS_CRITERIA = {
    "positive_windows": 3,
    "avg_net_pnl_pct": 0.0,
    "avg_profit_factor": 1.2,
    "worst_net_pnl_pct": -5.0,
    "total_trades": 40,
}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run R5 spot-only SMC v2 controlled filter experiments.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--htf-timeframe", default=None)
    parser.add_argument("--windows", required=True)
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--allow-short", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--output", default="logs/r5_spot_controlled_filters_results.csv")
    parser.add_argument("--details-output", default="logs/r5_spot_controlled_filters_details.csv")
    parser.add_argument("--report-output", default=DEFAULT_REPORT_OUTPUT)
    return parser


def _inject_config_defaults(args: argparse.Namespace, first_window: tuple[str, str]) -> None:
    args.start = first_window[0]
    args.end = first_window[1]
    args.output_dir = ENGINE_RUN_OUTPUT_DIR
    args.use_smc_filter = False
    args.smc_features_path = None
    args.smc_lookback_bars = None
    args.require_bullish_bos = False


def validate_spot_symbol(symbol: str) -> None:
    if ":" in symbol:
        raise SystemExit("R5 spot-only runner refuses contract symbols. Use spot BTC/USDT, not BTC/USDT:USDT.")


def build_spot_filter_strategy(
    *,
    experiment: SpotFilterExperiment,
    symbol: str,
    ltf_timeframe: str,
    htf_timeframe: str,
    strategy_yaml: dict[str, Any] | None = None,
) -> SMCStrategyV2:
    yaml_config = dict(strategy_yaml or {})
    experiment_config = dict(yaml_config.get("experiment") or {})
    experiment_config.update(
        {
            "long_only": experiment.long_only,
            "short_only": False,
            "blocked_entry_hours_utc": list(experiment.blocked_entry_hours_utc),
            "block_new_york_shorts": False,
            "allowed_killzones": list(experiment.allowed_killzones) if experiment.allowed_killzones is not None else None,
            "blocked_killzones": list(experiment.blocked_killzones) if experiment.blocked_killzones is not None else None,
            "min_reward_to_fee_ratio": experiment.min_reward_to_fee_ratio,
            "min_risk_pct": experiment.min_risk_pct,
            "max_risk_pct": experiment.max_risk_pct,
        }
    )
    yaml_config["experiment"] = experiment_config
    return _build_smc_v2(
        yaml_config,
        symbol=symbol,
        ltf_timeframe=ltf_timeframe,
        htf_timeframe=htf_timeframe,
        cli_long_only=False,
        cli_short_only=False,
        cli_blocked_hours=None,
        cli_block_new_york_shorts=False,
    )


def compute_score(row: dict[str, Any]) -> float:
    base = (
        float(row["avg_net_pnl_pct"])
        - 0.7 * float(row["avg_max_drawdown_pct"])
        - abs(float(row["worst_net_pnl_pct"]))
    )
    positive_penalty = max(0, int(row["windows"]) - int(row["positive_windows"])) * 2.0
    low_trade_penalty = max(0, ROBUSTNESS_CRITERIA["total_trades"] - int(row["total_trades"])) * 0.25
    return base - positive_penalty - low_trade_penalty


def passes_robustness(row: dict[str, Any]) -> bool:
    return (
        int(row["positive_windows"]) >= ROBUSTNESS_CRITERIA["positive_windows"]
        and float(row["avg_net_pnl_pct"]) > ROBUSTNESS_CRITERIA["avg_net_pnl_pct"]
        and float(row["avg_profit_factor"]) > ROBUSTNESS_CRITERIA["avg_profit_factor"]
        and float(row["worst_net_pnl_pct"]) > ROBUSTNESS_CRITERIA["worst_net_pnl_pct"]
        and int(row["total_trades"]) >= ROBUSTNESS_CRITERIA["total_trades"]
    )


def aggregate_experiment_rows(experiment_name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        raise ValueError("At least one detail row is required to aggregate")

    net_pnls = [float(row["net_pnl_pct"]) for row in rows]
    drawdowns = [float(row["max_drawdown_pct"]) for row in rows]
    win_rates = [float(row["win_rate"]) for row in rows]
    profit_factors = [
        float(row["profit_factor"])
        for row in rows
        if row.get("profit_factor") is not None and not pd.isna(row["profit_factor"])
    ]
    aggregate = {
        "experiment": experiment_name,
        "windows": len(rows),
        "positive_windows": sum(1 for value in net_pnls if value > 0),
        "avg_net_pnl_pct": sum(net_pnls) / len(net_pnls),
        "median_net_pnl_pct": float(median(net_pnls)),
        "worst_net_pnl_pct": min(net_pnls),
        "best_net_pnl_pct": max(net_pnls),
        "avg_max_drawdown_pct": sum(drawdowns) / len(drawdowns),
        "worst_max_drawdown_pct": max(drawdowns),
        "total_trades": sum(int(row["total_trades"]) for row in rows),
        "avg_win_rate": sum(win_rates) / len(win_rates),
        "avg_profit_factor": (sum(profit_factors) / len(profit_factors)) if profit_factors else 0.0,
        "total_long_trades": sum(int(row["long_trades"]) for row in rows),
        "total_short_trades": sum(int(row["short_trades"]) for row in rows),
    }
    aggregate["score"] = compute_score(aggregate)
    return aggregate


def _detail_row_from_summary(
    *,
    experiment: SpotFilterExperiment,
    summary: dict[str, Any],
    window: tuple[str, str],
    htf_timeframe: str,
) -> dict[str, Any]:
    start, end = window
    return {
        "experiment": experiment.name,
        "symbol": summary["symbol"],
        "timeframe": summary["timeframe"],
        "htf_timeframe": htf_timeframe,
        "start": start,
        "end": end,
        "final_equity": float(summary["final_equity"]),
        "net_pnl": float(summary["net_pnl"]),
        "net_pnl_pct": float(summary["net_pnl_pct"]) * 100.0,
        "max_drawdown_pct": float(summary["max_drawdown_pct"]) * 100.0,
        "total_trades": int(summary["total_trades"]),
        "win_rate": float(summary["win_rate"]),
        "profit_factor": summary["profit_factor"],
        "long_trades": int(summary["long_trades"]),
        "short_trades": int(summary["short_trades"]),
    }


def run_one_window(
    *,
    experiment: SpotFilterExperiment,
    base_config: BacktestConfig,
    window: tuple[str, str],
    htf_timeframe: str,
    ltf_ohlcv: pd.DataFrame,
    htf_ohlcv: pd.DataFrame,
    strategy_yaml: dict[str, Any],
) -> dict[str, Any]:
    start, end = window
    config = replace(base_config, start=start, end=end, output_dir=ENGINE_RUN_OUTPUT_DIR)
    strategy = build_spot_filter_strategy(
        experiment=experiment,
        symbol=config.symbol,
        ltf_timeframe=config.timeframe,
        htf_timeframe=htf_timeframe,
        strategy_yaml=strategy_yaml,
    )
    result = BacktestEngine(config).run(
        ltf_ohlcv,
        strategy,
        htf_ohlcv=htf_ohlcv,
        htf_timeframe=htf_timeframe,
    )
    return _detail_row_from_summary(
        experiment=experiment,
        summary=result.summary,
        window=window,
        htf_timeframe=htf_timeframe,
    )


def format_ranked_table(rows: list[dict[str, Any]]) -> str:
    columns = [
        "experiment",
        "score",
        "positive_windows",
        "avg_net_pnl_pct",
        "worst_net_pnl_pct",
        "avg_max_drawdown_pct",
        "total_trades",
        "avg_profit_factor",
    ]
    frame = pd.DataFrame(rows, columns=columns)
    if frame.empty:
        return ""
    return frame.to_string(
        index=False,
        formatters={
            "score": "{:.2f}".format,
            "avg_net_pnl_pct": "{:.2f}".format,
            "worst_net_pnl_pct": "{:.2f}".format,
            "avg_max_drawdown_pct": "{:.2f}".format,
            "avg_profit_factor": "{:.2f}".format,
        },
    )


def _experiment_row(results: pd.DataFrame, name: str) -> dict[str, Any] | None:
    match = results[results["experiment"] == name]
    if match.empty:
        return None
    return match.iloc[0].to_dict()


def build_report(results: pd.DataFrame, details: pd.DataFrame) -> str:
    ranked = results.sort_values("score", ascending=False).reset_index(drop=True)
    best = ranked.iloc[0].to_dict() if not ranked.empty else None
    robust = [row for row in ranked.to_dict(orient="records") if passes_robustness(row)]
    reference = _experiment_row(results, "reference_long_only_block_15")

    lines: list[str] = [
        "R5.0 Spot Controlled Filters Report",
        "Research only. This is not a profitability claim.",
        "",
        "Ranked experiment table:",
        format_ranked_table(ranked.to_dict(orient="records")),
        "",
    ]
    if best:
        lines.append(f"Best experiment by score: {best['experiment']}")
    if robust:
        lines.append("Robustness candidates: " + ", ".join(row["experiment"] for row in robust))
    else:
        lines.append("No R5.0 filter passed robustness criteria.")

    if best is not None:
        best_details = details[details["experiment"] == best["experiment"]]
        lines.extend(
            [
                "",
                f"Per-window performance for best experiment ({best['experiment']}):",
                best_details[
                    ["start", "end", "net_pnl_pct", "max_drawdown_pct", "total_trades", "profit_factor"]
                ].to_string(index=False),
            ]
        )

    if reference is not None and best is not None:
        lines.extend(
            [
                "",
                "Comparison against reference_long_only_block_15:",
                (
                    f"Reference avg_net_pnl_pct={reference['avg_net_pnl_pct']:.2f}, "
                    f"positive_windows={int(reference['positive_windows'])}/{int(reference['windows'])}, "
                    f"total_trades={int(reference['total_trades'])}, "
                    f"avg_profit_factor={reference['avg_profit_factor']:.2f}."
                ),
                (
                    f"Best avg_net_pnl_pct={best['avg_net_pnl_pct']:.2f}, "
                    f"positive_windows={int(best['positive_windows'])}/{int(best['windows'])}, "
                    f"total_trades={int(best['total_trades'])}, "
                    f"avg_profit_factor={best['avg_profit_factor']:.2f}."
                ),
            ]
        )

    checks = [
        ("Whether New York-only improved robustness", "new_york_only"),
        ("Whether blocking London helped", "block_london"),
        ("Whether blocking 7/8/13/15 helped", "block_hours_7_8_13_15"),
        ("Whether reward_to_fee >= 5 helped", "min_reward_to_fee_5"),
        ("Whether risk_pct 0.25%-0.75% helped", "risk_between_025_075"),
    ]
    if reference is not None:
        lines.append("")
        for label, name in checks:
            row = _experiment_row(results, name)
            if row is None:
                continue
            improved = row["score"] > reference["score"]
            lines.append(
                f"{label}: {'yes' if improved else 'no'} "
                f"(score {row['score']:.2f} vs reference {reference['score']:.2f})."
            )

    lines.extend(["", "Explicit statement: this is research only, not a profitability claim."])
    return "\n".join(lines) + "\n"


def main() -> None:
    overall_start = time.perf_counter()
    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    windows = parse_windows(args.windows)
    _inject_config_defaults(args, windows[0])
    base_config = _build_backtest_config(args, raw_config)
    validate_spot_symbol(base_config.symbol)

    data_config = raw_config.get("data", {})
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    client = OKXClient(config=raw_config.get("exchange", {}))
    strategy_yaml = _load_strategy_yaml("smc_v2")
    htf_timeframe = str(_coalesce(args.htf_timeframe, strategy_yaml.get("htf_timeframe"), DEFAULT_HTF_TIMEFRAME))

    print(
        f"R5 spot controlled filters: symbol={base_config.symbol} timeframe={base_config.timeframe} "
        f"htf={htf_timeframe} windows={len(windows)} experiments={len(SPOT_FILTER_EXPERIMENTS)}"
    )

    detail_rows: list[dict[str, Any]] = []
    for window_index, window in enumerate(windows, start=1):
        start, end = window
        print(f"\n=== Window {window_index}/{len(windows)}: {start} -> {end} ===")
        ltf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="LTF",
            symbol=base_config.symbol,
            timeframe=base_config.timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        htf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="HTF",
            symbol=base_config.symbol,
            timeframe=htf_timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if ltf_ohlcv.empty or htf_ohlcv.empty:
            raise SystemExit(f"No OHLCV data for window {start} -> {end}")

        for experiment in SPOT_FILTER_EXPERIMENTS:
            started = time.perf_counter()
            print(f"  - Running experiment: {experiment.name}")
            row = run_one_window(
                experiment=experiment,
                base_config=base_config,
                window=window,
                htf_timeframe=htf_timeframe,
                ltf_ohlcv=ltf_ohlcv,
                htf_ohlcv=htf_ohlcv,
                strategy_yaml=strategy_yaml,
            )
            print(
                f"    {experiment.name}: net_pnl_pct={row['net_pnl_pct']:.2f}%, "
                f"trades={row['total_trades']}, max_dd={row['max_drawdown_pct']:.2f}%, "
                f"elapsed={time.perf_counter() - started:.1f}s"
            )
            detail_rows.append(row)

    details_df = pd.DataFrame(detail_rows, columns=DETAILS_COLUMNS)
    details_path = Path(args.details_output)
    details_path.parent.mkdir(parents=True, exist_ok=True)
    details_df.to_csv(details_path, index=False)

    aggregate_rows = [
        aggregate_experiment_rows(
            experiment.name,
            [row for row in detail_rows if row["experiment"] == experiment.name],
        )
        for experiment in SPOT_FILTER_EXPERIMENTS
    ]
    aggregate_rows.sort(key=lambda row: row["score"], reverse=True)
    results_df = pd.DataFrame(aggregate_rows, columns=RESULTS_COLUMNS)
    results_path = Path(args.output)
    results_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(results_path, index=False)

    report = build_report(results_df, details_df)
    report_path = Path(args.report_output)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")

    print("\n=== Ranked R5 spot filter experiments ===")
    print(format_ranked_table(aggregate_rows))
    print(f"\nDetails: {details_path}")
    print(f"Results: {results_path}")
    print(f"Report: {report_path}")
    print(f"Total runtime: {time.perf_counter() - overall_start:.1f}s")


if __name__ == "__main__":
    main()
