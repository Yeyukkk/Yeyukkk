"""
LIVE trading entry point — IMPLEMENTED IN SPRINT 6.

!!! DO NOT REMOVE the guard below until ALL of these are true:
!!!   - Sprint 1-5 are complete
!!!   - Backtest results meet criteria: Sharpe>1.5, MDD<15%, +EV, n>=100
!!!   - 2-4 weeks of paper forward test align with backtest
!!!   - You have read live executor unit tests
!!!   - OKX API key has withdraw DISABLED and IP whitelist ENABLED
"""
from core.monitoring.logger import get_logger

log = get_logger(__name__)

LIVE_GUARD_OVERRIDE = False  # set True only after the above checklist


def main():
    if not LIVE_GUARD_OVERRIDE:
        log.error(
            "live.guard_active",
            message="Live bot is intentionally locked. "
            "Set LIVE_GUARD_OVERRIDE=True in this file to unlock.",
        )
        raise SystemExit(
            "Live trading is locked by a hard guard. Refusing to start.\n"
            "This guard exists to prevent accidentally running live code "
            "before the strategy is validated."
        )
    log.error("live.not_implemented", sprint="will be built in Sprint 6")
    raise SystemExit("run_live is not implemented yet.")


if __name__ == "__main__":
    main()
