"""CLI for offline Smart Money Concepts feature extraction."""

from __future__ import annotations

import argparse
from typing import Any

from bots.run_backtest import _coalesce, _load_yaml
from core.data import OKXClient
from core.strategy import build_smc_features, save_smc_features


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Generate public-data-only SMC feature CSV.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--start", default=None)
    parser.add_argument("--end", default=None)
    parser.add_argument("--output", default="logs/smc_features.csv")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--swing-length", type=int, default=50)
    parser.add_argument("--previous-time-frame", default="1D")
    parser.add_argument("--session", default="London")
    parser.add_argument("--session-time-zone", default="UTC")
    return parser


def _required(value: Any, name: str) -> str:
    if value is None:
        raise SystemExit(f"{name} is required unless provided in config.")
    return str(value)


def main() -> None:
    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    backtest_config = raw_config.get("backtest", {})
    data_config = raw_config.get("data", {})

    symbol = _required(_coalesce(args.symbol, backtest_config.get("symbol")), "--symbol")
    timeframe = _required(_coalesce(args.timeframe, backtest_config.get("timeframe")), "--timeframe")
    start = _required(_coalesce(args.start, backtest_config.get("start")), "--start")
    end = _required(_coalesce(args.end, backtest_config.get("end")), "--end")
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))

    client = OKXClient(config=raw_config.get("exchange", {}))
    ohlcv = client.fetch_ohlcv_history(symbol=symbol, timeframe=timeframe, start=start, end=end, limit=limit)
    if ohlcv.empty:
        raise SystemExit("No OHLCV candles returned for the requested range.")

    features = build_smc_features(
        ohlcv,
        swing_length=args.swing_length,
        previous_time_frame=args.previous_time_frame,
        session=args.session,
        session_time_zone=args.session_time_zone,
    )
    output_path = save_smc_features(features, args.output)

    print("\nSMC features complete")
    print(f"Symbol: {symbol}  Timeframe: {timeframe}")
    print(f"Period: {start} -> {end}")
    print(f"Rows: {len(features)}")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    main()

