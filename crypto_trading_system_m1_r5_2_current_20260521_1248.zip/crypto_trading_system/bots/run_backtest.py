"""CLI for public-data-only offline backtests.

Supports three strategies via ``--strategy``:

* ``ema``    — legacy EMA crossover baseline (LTF only).
* ``smc_v1`` — SMC/ICT FVG-mitigation strategy with HTF bias (LTF + HTF).
* ``smc_v2`` — Stricter SMC variant with killzone, liquidity sweep, CHOCH,
                and CLI-overridable experiment switches (LTF + HTF).

The script is research-only: it uses public OKX OHLCV data, no API keys,
and never places real orders.
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.data import OKXClient, load_ohlcv_cache, ohlcv_cache_path, save_ohlcv_cache
from core.strategy import SMCStrategyV1, SMCStrategyV2


STRATEGY_CHOICES = ("ema", "smc_v1", "smc_v2")
DEFAULT_HTF_TIMEFRAME = "1h"

_SMC_V1_FIELDS = (
    "symbol",
    "htf_timeframe",
    "ltf_timeframe",
    "atr_period",
    "atr_buffer_multiplier",
    "risk_reward",
    "min_score",
    "structure_lookback",
    "fvg_lookback",
    "ltf_lookback_bars",
    "htf_lookback_bars",
    "min_risk_pct",
    "min_target_pct",
    "min_reward_to_fee_ratio",
    "estimated_round_trip_cost_pct",
    "min_rr",
    "setup_cooldown_bars",
)

_SMC_V2_EXTRA_FIELDS = (
    "use_killzone_filter",
    "killzones_utc",
    "require_liquidity_sweep",
    "sweep_lookback_bars",
    "require_ltf_choch",
    "choch_lookback_bars",
    "avoid_weekends",
    "allowed_killzones",
    "blocked_killzones",
    "max_risk_pct",
)


def _load_yaml(path: str | None) -> dict[str, Any]:
    if not path:
        return {}

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _coalesce(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _parse_blocked_hours(raw: str | None) -> list[int] | None:
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None

    hours: list[int] = []
    for token in text.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            hour = int(token)
        except ValueError as exc:
            raise SystemExit(f"Invalid --smc-block-entry-hours-utc value: {token!r}") from exc
        if not 0 <= hour <= 23:
            raise SystemExit(f"--smc-block-entry-hours-utc value out of range 0-23: {hour}")
        hours.append(hour)
    return hours


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a public-data-only OKX backtest (EMA or SMC v1/v2)."
    )
    parser.add_argument("--config", default=None, help="Optional YAML config path.")
    parser.add_argument(
        "--strategy",
        choices=STRATEGY_CHOICES,
        default="ema",
        help="Strategy to backtest. Defaults to ema.",
    )
    parser.add_argument("--symbol", default=None, help="Market symbol, e.g. BTC/USDT.")
    parser.add_argument("--timeframe", default=None, help="LTF OHLCV timeframe, e.g. 15m.")
    parser.add_argument(
        "--htf-timeframe",
        default=None,
        help="HTF OHLCV timeframe for SMC strategies (default 1h).",
    )
    parser.add_argument("--start", default=None, help="UTC start date/time, e.g. 2024-01-01.")
    parser.add_argument("--end", default=None, help="UTC end date/time, e.g. 2024-03-01.")
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument(
        "--use-smc-filter",
        action="store_true",
        help="Legacy EMA SMC-feature filter; not used by smc_v1/smc_v2 strategies.",
    )
    parser.add_argument("--smc-features-path", default=None)
    parser.add_argument("--smc-lookback-bars", type=int, default=None)
    parser.add_argument("--require-bullish-bos", action="store_true")
    parser.add_argument("--allow-short", action="store_true")
    parser.add_argument("--fast-ema", type=int, default=None)
    parser.add_argument("--slow-ema", type=int, default=None)
    parser.add_argument(
        "--smc-long-only",
        action="store_true",
        help="SMC v2 experiment: only allow long entries.",
    )
    parser.add_argument(
        "--smc-short-only",
        action="store_true",
        help="SMC v2 experiment: only allow short entries.",
    )
    parser.add_argument(
        "--smc-block-entry-hours-utc",
        default=None,
        help='SMC v2: comma-separated UTC hours to block entries (e.g. "15" or "15,16").',
    )
    parser.add_argument(
        "--smc-block-new-york-shorts",
        action="store_true",
        help="SMC v2: suppress short entries during the New York killzone.",
    )
    parser.add_argument("--no-cache", action="store_true", help="Disable OHLCV cache read/write.")
    parser.add_argument(
        "--refresh-cache",
        action="store_true",
        help="Re-download OHLCV and overwrite cache.",
    )
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--limit", type=int, default=None, help="ccxt OHLCV page size.")
    return parser


def _build_backtest_config(args: argparse.Namespace, raw_config: dict[str, Any]) -> BacktestConfig:
    backtest_config = raw_config.get("backtest", {})
    symbol = _coalesce(args.symbol, backtest_config.get("symbol"))
    timeframe = _coalesce(args.timeframe, backtest_config.get("timeframe"))
    start = _coalesce(args.start, backtest_config.get("start"))
    end = _coalesce(args.end, backtest_config.get("end"))

    if not all([symbol, timeframe, start, end]):
        raise SystemExit("--symbol, --timeframe, --start, and --end are required unless provided in config.")

    return BacktestConfig(
        symbol=str(symbol),
        timeframe=str(timeframe),
        start=str(start),
        end=str(end),
        initial_equity=float(_coalesce(args.initial_equity, backtest_config.get("initial_equity"), 10_000.0)),
        fee_rate=float(_coalesce(args.fee_rate, backtest_config.get("fee_rate"), 0.0005)),
        slippage_bps=float(_coalesce(args.slippage_bps, backtest_config.get("slippage_bps"), 2.0)),
        position_size_pct=float(
            _coalesce(args.position_size_pct, backtest_config.get("position_size_pct"), 1.0)
        ),
        leverage=float(_coalesce(args.leverage, backtest_config.get("leverage"), 10.0)),
        max_margin_pct=float(_coalesce(args.max_margin_pct, backtest_config.get("max_margin_pct"), 0.20)),
        stop_loss_pct_on_margin=_coalesce(
            args.stop_loss_pct_on_margin,
            backtest_config.get("stop_loss_pct_on_margin"),
            0.30,
        ),
        take_profit_pct_on_margin=_coalesce(
            args.take_profit_pct_on_margin,
            backtest_config.get("take_profit_pct_on_margin"),
        ),
        max_account_drawdown_pct=float(
            _coalesce(args.max_account_drawdown_pct, backtest_config.get("max_account_drawdown_pct"), 0.30)
        ),
        max_daily_loss_pct=float(_coalesce(args.max_daily_loss_pct, backtest_config.get("max_daily_loss_pct"), 0.05)),
        max_consecutive_losses=int(
            _coalesce(args.max_consecutive_losses, backtest_config.get("max_consecutive_losses"), 5)
        ),
        cooldown_bars_after_loss_streak=int(
            _coalesce(
                args.cooldown_bars_after_loss_streak,
                backtest_config.get("cooldown_bars_after_loss_streak"),
                20,
            )
        ),
        liquidation_check_enabled=not args.disable_liquidation_check
        if args.disable_liquidation_check
        else bool(backtest_config.get("liquidation_check_enabled", True)),
        maintenance_margin_pct=float(
            _coalesce(args.maintenance_margin_pct, backtest_config.get("maintenance_margin_pct"), 0.005)
        ),
        use_smc_filter=bool(args.use_smc_filter or backtest_config.get("use_smc_filter", False)),
        smc_features_path=_coalesce(args.smc_features_path, backtest_config.get("smc_features_path")),
        smc_lookback_bars=int(_coalesce(args.smc_lookback_bars, backtest_config.get("smc_lookback_bars"), 20)),
        require_bullish_bos=bool(args.require_bullish_bos or backtest_config.get("require_bullish_bos", False)),
        allow_short=bool(args.allow_short or backtest_config.get("allow_short", False)),
        output_dir=str(_coalesce(args.output_dir, backtest_config.get("output_dir"), "logs")),
    )


def _load_strategy_yaml(strategy_name: str) -> dict[str, Any]:
    path = Path("config/strategies") / f"{strategy_name}.yaml"
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _smc_v1_params(yaml_config: dict[str, Any]) -> dict[str, Any]:
    return {key: yaml_config[key] for key in _SMC_V1_FIELDS if key in yaml_config}


def _build_smc_v1(
    yaml_config: dict[str, Any],
    *,
    symbol: str,
    ltf_timeframe: str,
    htf_timeframe: str,
) -> SMCStrategyV1:
    params = _smc_v1_params(yaml_config)
    params["symbol"] = symbol
    params["ltf_timeframe"] = ltf_timeframe
    params["htf_timeframe"] = htf_timeframe
    return SMCStrategyV1(**params)


def _build_smc_v2(
    yaml_config: dict[str, Any],
    *,
    symbol: str,
    ltf_timeframe: str,
    htf_timeframe: str,
    cli_long_only: bool,
    cli_short_only: bool,
    cli_blocked_hours: list[int] | None,
    cli_block_new_york_shorts: bool,
) -> SMCStrategyV2:
    if cli_long_only and cli_short_only:
        raise SystemExit("--smc-long-only and --smc-short-only cannot both be set.")

    params = _smc_v1_params(yaml_config)
    params["symbol"] = symbol
    params["ltf_timeframe"] = ltf_timeframe
    params["htf_timeframe"] = htf_timeframe
    for key in _SMC_V2_EXTRA_FIELDS:
        if key in yaml_config:
            params[key] = yaml_config[key]

    experiment = dict(yaml_config.get("experiment") or {})
    if cli_long_only:
        experiment["long_only"] = True
    if cli_short_only:
        experiment["short_only"] = True
    if cli_blocked_hours is not None:
        experiment["blocked_entry_hours_utc"] = cli_blocked_hours
    if cli_block_new_york_shorts:
        experiment["block_new_york_shorts"] = True

    if "long_only" in experiment:
        params["long_only"] = bool(experiment["long_only"])
    if "short_only" in experiment:
        params["short_only"] = bool(experiment["short_only"])
    if "blocked_entry_hours_utc" in experiment:
        params["blocked_entry_hours_utc"] = [int(hour) for hour in experiment["blocked_entry_hours_utc"]]
    if "block_new_york_shorts" in experiment:
        params["block_new_york_shorts"] = bool(experiment["block_new_york_shorts"])
    if "allowed_killzones" in experiment:
        value = experiment["allowed_killzones"]
        params["allowed_killzones"] = None if value is None else [str(name) for name in value]
    if "blocked_killzones" in experiment:
        value = experiment["blocked_killzones"]
        params["blocked_killzones"] = None if value is None else [str(name) for name in value]
    if "min_reward_to_fee_ratio" in experiment and experiment["min_reward_to_fee_ratio"] is not None:
        params["min_reward_to_fee_ratio"] = float(experiment["min_reward_to_fee_ratio"])
    if "min_risk_pct" in experiment and experiment["min_risk_pct"] is not None:
        params["min_risk_pct"] = float(experiment["min_risk_pct"])
    if "max_risk_pct" in experiment and experiment["max_risk_pct"] is not None:
        params["max_risk_pct"] = float(experiment["max_risk_pct"])

    return SMCStrategyV2(**params)


def _load_or_fetch_ohlcv(
    client: OKXClient,
    *,
    label: str,
    symbol: str,
    timeframe: str,
    start: str,
    end: str,
    limit: int,
    no_cache: bool,
    refresh_cache: bool,
) -> pd.DataFrame:
    cache_path = ohlcv_cache_path("okx", symbol, timeframe, start, end)
    if not no_cache and cache_path.exists() and not refresh_cache:
        print(f"Loading {label} from cache: {cache_path}")
        ohlcv = load_ohlcv_cache(cache_path)
    else:
        print(f"Downloading {label} {symbol} {timeframe} {start} -> {end}...")
        ohlcv = client.fetch_ohlcv_history(
            symbol=symbol,
            timeframe=timeframe,
            start=start,
            end=end,
            limit=limit,
        )
        if not no_cache and not ohlcv.empty:
            save_ohlcv_cache(ohlcv, cache_path)
    print(f"{label} candles: {len(ohlcv)}")
    return ohlcv


def main() -> None:
    overall_start = time.perf_counter()

    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    strategy_config_section = raw_config.get("strategy", {})
    data_config = raw_config.get("data", {})
    config = _build_backtest_config(args, raw_config)

    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    client = OKXClient(config=raw_config.get("exchange", {}))

    strategy_name = args.strategy
    strategy_yaml: dict[str, Any] = {}
    htf_timeframe: str | None = None
    if strategy_name in ("smc_v1", "smc_v2"):
        strategy_yaml = _load_strategy_yaml(strategy_name)
        htf_timeframe = str(
            _coalesce(args.htf_timeframe, strategy_yaml.get("htf_timeframe"), DEFAULT_HTF_TIMEFRAME)
        )

    ohlcv = _load_or_fetch_ohlcv(
        client,
        label="LTF",
        symbol=config.symbol,
        timeframe=config.timeframe,
        start=config.start,
        end=config.end,
        limit=limit,
        no_cache=args.no_cache,
        refresh_cache=args.refresh_cache,
    )
    if ohlcv.empty:
        raise SystemExit("No LTF OHLCV candles returned for the requested range.")

    htf_ohlcv: pd.DataFrame | None = None
    if strategy_name in ("smc_v1", "smc_v2"):
        assert htf_timeframe is not None
        htf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="HTF",
            symbol=config.symbol,
            timeframe=htf_timeframe,
            start=config.start,
            end=config.end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if htf_ohlcv.empty:
            raise SystemExit("No HTF OHLCV candles returned for the requested range.")

    if strategy_name == "ema":
        fast_ema = int(_coalesce(args.fast_ema, strategy_config_section.get("fast_ema"), 20))
        slow_ema = int(_coalesce(args.slow_ema, strategy_config_section.get("slow_ema"), 50))
        strategy: Any = EMACrossoverStrategy(fast_ema=fast_ema, slow_ema=slow_ema)
    elif strategy_name == "smc_v1":
        strategy = _build_smc_v1(
            strategy_yaml,
            symbol=config.symbol,
            ltf_timeframe=config.timeframe,
            htf_timeframe=htf_timeframe or DEFAULT_HTF_TIMEFRAME,
        )
    elif strategy_name == "smc_v2":
        blocked_hours = _parse_blocked_hours(args.smc_block_entry_hours_utc)
        strategy = _build_smc_v2(
            strategy_yaml,
            symbol=config.symbol,
            ltf_timeframe=config.timeframe,
            htf_timeframe=htf_timeframe or DEFAULT_HTF_TIMEFRAME,
            cli_long_only=args.smc_long_only,
            cli_short_only=args.smc_short_only,
            cli_blocked_hours=blocked_hours,
            cli_block_new_york_shorts=args.smc_block_new_york_shorts,
        )
    else:
        raise SystemExit(f"Unsupported strategy: {strategy_name}")

    print("Running backtest...")
    engine_start = time.perf_counter()
    if strategy_name == "ema":
        result = BacktestEngine(config).run(ohlcv, strategy)
    else:
        result = BacktestEngine(config).run(
            ohlcv,
            strategy,
            htf_ohlcv=htf_ohlcv,
            htf_timeframe=htf_timeframe,
        )
    engine_elapsed = time.perf_counter() - engine_start
    print(f"Engine run: {engine_elapsed:.2f}s")

    summary = result.summary
    print("\nBacktest complete")
    print(f"Symbol: {summary['symbol']}  Timeframe: {summary['timeframe']}")
    print(f"Period: {summary['start']} -> {summary['end']}")
    print(f"Initial equity: {summary['initial_equity']:.2f}")
    print(f"Final equity: {summary['final_equity']:.2f}")
    print(f"Net PnL: {summary['net_pnl']:.2f} ({summary['net_pnl_pct'] * 100:.2f}%)")
    print(f"Leverage: {summary['leverage']:.2f}x  Max margin: {summary['max_margin_pct'] * 100:.2f}%")
    print(f"Trades: {summary['total_trades']}  Win rate: {summary['win_rate'] * 100:.2f}%")
    print(f"Max drawdown: {summary['max_drawdown']:.2f} ({summary['max_drawdown_pct'] * 100:.2f}%)")
    print("\nOutputs")
    print(f"Summary: {result.summary_path}")
    print(f"Trades: {result.trades_path}")
    print(f"Equity curve: {result.equity_curve_path}")

    total_elapsed = time.perf_counter() - overall_start
    print(f"\nTotal runtime: {total_elapsed:.2f}s")


if __name__ == "__main__":
    main()
