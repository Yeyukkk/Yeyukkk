"""Run public-data-only backtest parameter sweeps."""

from __future__ import annotations

import argparse
from itertools import product
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd

from bots.run_backtest import _coalesce, _load_yaml
from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.data import OKXClient


DEFAULT_GRID = {
    "stop_loss_pct_on_margin": [0.20, 0.30, 0.40, 0.50],
    "max_account_drawdown_pct": [0.20, 0.30, 0.35, 0.45],
    "max_daily_loss_pct": [0.03, 0.05, 0.08, 0.10],
    "max_consecutive_losses": [3, 5, 6, 8],
    "cooldown_bars_after_loss_streak": [10, 15, 20, 30],
}

QUICK_GRID = [
    {
        "stop_loss_pct_on_margin": stop_loss,
        "max_account_drawdown_pct": account_dd,
        "max_daily_loss_pct": daily_loss,
        "max_consecutive_losses": losses,
        "cooldown_bars_after_loss_streak": cooldown,
    }
    for stop_loss, account_dd, daily_loss, losses, cooldown in [
        (0.20, 0.20, 0.03, 3, 10),
        (0.20, 0.30, 0.05, 5, 15),
        (0.30, 0.20, 0.05, 3, 20),
        (0.30, 0.30, 0.05, 5, 20),
        (0.30, 0.35, 0.08, 6, 20),
        (0.40, 0.30, 0.05, 5, 30),
        (0.40, 0.35, 0.08, 6, 15),
        (0.40, 0.45, 0.10, 8, 30),
        (0.50, 0.30, 0.08, 5, 20),
        (0.50, 0.45, 0.10, 8, 30),
    ]
]


def score_result(summary: dict[str, Any]) -> float:
    return float(summary["net_pnl_pct"]) - float(summary["max_drawdown_pct"]) * 0.7


def walk_forward_score(row: dict[str, Any]) -> float:
    return (
        float(row["avg_net_pnl_pct"])
        - 0.7 * float(row["avg_max_drawdown_pct"])
        - abs(float(row["worst_net_pnl_pct"]))
    )


def parse_windows(raw_windows: str) -> list[tuple[str, str]]:
    windows: list[tuple[str, str]] = []
    for raw_window in raw_windows.split(","):
        value = raw_window.strip()
        if not value:
            continue
        if ":" not in value:
            raise ValueError(f"Invalid window {value!r}; expected START:END")
        start, end = [part.strip() for part in value.split(":", 1)]
        if not start or not end:
            raise ValueError(f"Invalid window {value!r}; expected START:END")
        windows.append((start, end))
    if not windows:
        raise ValueError("At least one walk-forward window is required")
    return windows


def build_parameter_grid(max_runs: int | None = 20, quick: bool = False) -> list[dict[str, float | int]]:
    combinations: list[dict[str, float | int]]
    if quick:
        combinations = QUICK_GRID.copy()
    else:
        keys = list(DEFAULT_GRID)
        combinations = [dict(zip(keys, values, strict=True)) for values in product(*(DEFAULT_GRID[key] for key in keys))]

    if max_runs is not None and max_runs > 0:
        return combinations[:max_runs]
    return combinations


def aggregate_walk_forward(params: dict[str, float | int], rows: list[dict[str, Any]]) -> dict[str, Any]:
    net_pnls = [float(row["net_pnl_pct"]) for row in rows]
    drawdowns = [float(row["max_drawdown_pct"]) for row in rows]
    final_equities = [float(row["final_equity"]) for row in rows]
    trades = [float(row["total_trades"]) for row in rows]
    profit_factors = [
        float(row["profit_factor"])
        for row in rows
        if row.get("profit_factor") is not None and pd.notna(row.get("profit_factor"))
    ]

    aggregate: dict[str, Any] = {
        **params,
        "avg_net_pnl_pct": sum(net_pnls) / len(net_pnls),
        "median_net_pnl_pct": median(net_pnls),
        "worst_net_pnl_pct": min(net_pnls),
        "avg_max_drawdown_pct": sum(drawdowns) / len(drawdowns),
        "worst_max_drawdown_pct": max(drawdowns),
        "positive_windows": sum(1 for value in net_pnls if value > 0),
        "total_windows": len(rows),
        "avg_final_equity": sum(final_equities) / len(final_equities),
        "avg_trades": sum(trades) / len(trades),
        "avg_profit_factor": (sum(profit_factors) / len(profit_factors)) if profit_factors else None,
    }
    aggregate["score"] = walk_forward_score(aggregate)
    return aggregate


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a public-data-only backtest parameter sweep.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--start", default=None)
    parser.add_argument("--end", default=None)
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--fast-ema", type=int, default=None)
    parser.add_argument("--slow-ema", type=int, default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--max-runs", type=int, default=20, help="Maximum combinations to run. Use 0 for full grid.")
    parser.add_argument("--quick", action="store_true", help="Use a curated 10-combination sweep.")
    parser.add_argument("--walk-forward", action="store_true", help="Run every parameter set across multiple windows.")
    parser.add_argument(
        "--windows",
        default=None,
        help="Comma-separated START:END windows, e.g. 2024-01-01:2024-03-01,2024-03-01:2024-05-01.",
    )
    return parser


def _base_config(
    args: argparse.Namespace,
    raw_config: dict[str, Any],
    params: dict[str, float | int],
    start_override: str | None = None,
    end_override: str | None = None,
) -> BacktestConfig:
    backtest_config = raw_config.get("backtest", {})
    symbol = _coalesce(args.symbol, backtest_config.get("symbol"))
    timeframe = _coalesce(args.timeframe, backtest_config.get("timeframe"))
    start = _coalesce(start_override, args.start, backtest_config.get("start"))
    end = _coalesce(end_override, args.end, backtest_config.get("end"))
    if not all([symbol, timeframe, start, end]):
        raise SystemExit("--symbol, --timeframe, --start, and --end are required unless provided in config.")

    liquidation_enabled = False if args.disable_liquidation_check else bool(
        backtest_config.get("liquidation_check_enabled", True)
    )

    return BacktestConfig(
        symbol=str(symbol),
        timeframe=str(timeframe),
        start=str(start),
        end=str(end),
        initial_equity=float(_coalesce(args.initial_equity, backtest_config.get("initial_equity"), 10_000.0)),
        fee_rate=float(_coalesce(args.fee_rate, backtest_config.get("fee_rate"), 0.0005)),
        slippage_bps=float(_coalesce(args.slippage_bps, backtest_config.get("slippage_bps"), 2.0)),
        position_size_pct=float(_coalesce(args.position_size_pct, backtest_config.get("position_size_pct"), 1.0)),
        leverage=float(_coalesce(args.leverage, backtest_config.get("leverage"), 10.0)),
        max_margin_pct=float(_coalesce(args.max_margin_pct, backtest_config.get("max_margin_pct"), 0.20)),
        stop_loss_pct_on_margin=float(params["stop_loss_pct_on_margin"]),
        take_profit_pct_on_margin=_coalesce(
            args.take_profit_pct_on_margin,
            backtest_config.get("take_profit_pct_on_margin"),
        ),
        max_account_drawdown_pct=float(params["max_account_drawdown_pct"]),
        max_daily_loss_pct=float(params["max_daily_loss_pct"]),
        max_consecutive_losses=int(params["max_consecutive_losses"]),
        cooldown_bars_after_loss_streak=int(params["cooldown_bars_after_loss_streak"]),
        liquidation_check_enabled=liquidation_enabled,
        maintenance_margin_pct=float(
            _coalesce(args.maintenance_margin_pct, backtest_config.get("maintenance_margin_pct"), 0.005)
        ),
        allow_short=False,
        output_dir=str(_coalesce(args.output_dir, backtest_config.get("output_dir"), "logs")),
    )


def _summary_row(params: dict[str, float | int], summary: dict[str, Any]) -> dict[str, Any]:
    row: dict[str, Any] = {
        **params,
        "final_equity": summary["final_equity"],
        "net_pnl_pct": summary["net_pnl_pct"],
        "max_drawdown_pct": summary["max_drawdown_pct"],
        "total_trades": summary["total_trades"],
        "win_rate": summary["win_rate"],
        "profit_factor": summary["profit_factor"],
        "stop_loss_exits": summary.get("stop_loss_exits", 0),
        "liquidation_exits": summary.get("liquidation_exits", 0),
        "skipped_signals": summary.get("skipped_signals", 0),
    }
    row["score"] = score_result(summary)
    return row


def _window_ohlcv(ohlcv: pd.DataFrame, start: str, end: str) -> pd.DataFrame:
    timestamps = pd.to_datetime(ohlcv["timestamp"], utc=True)
    start_ts = pd.to_datetime(start, utc=True)
    end_ts = pd.to_datetime(end, utc=True)
    return ohlcv[(timestamps >= start_ts) & (timestamps < end_ts)].copy()


def _run_walk_forward(
    args: argparse.Namespace,
    raw_config: dict[str, Any],
    ohlcv: pd.DataFrame,
    strategy: EMACrossoverStrategy,
    params_grid: list[dict[str, float | int]],
    windows: list[tuple[str, str]],
    output_dir: Path,
) -> None:
    detail_rows: list[dict[str, Any]] = []
    aggregate_rows: list[dict[str, Any]] = []

    for run_number, params in enumerate(params_grid, start=1):
        run_window_rows = []
        for window_number, (window_start, window_end) in enumerate(windows, start=1):
            window_data = _window_ohlcv(ohlcv, window_start, window_end)
            if window_data.empty:
                continue

            config = _base_config(args, raw_config, params, start_override=window_start, end_override=window_end)
            result = BacktestEngine(config).run(window_data, strategy)
            detail_row = {
                "run": run_number,
                "window": window_number,
                "window_start": window_start,
                "window_end": window_end,
                **_summary_row(params, result.summary),
            }
            detail_rows.append(detail_row)
            run_window_rows.append(detail_row)

        if run_window_rows:
            aggregate_rows.append({"run": run_number, **aggregate_walk_forward(params, run_window_rows)})

    if not aggregate_rows:
        raise SystemExit("No walk-forward windows produced backtest results.")

    aggregate_results = pd.DataFrame(aggregate_rows).sort_values("score", ascending=False).reset_index(drop=True)
    detail_results = pd.DataFrame(detail_rows).sort_values(["run", "window"]).reset_index(drop=True)
    aggregate_path = output_dir / "walk_forward_results.csv"
    details_path = output_dir / "walk_forward_details.csv"
    aggregate_results.to_csv(aggregate_path, index=False)
    detail_results.to_csv(details_path, index=False)

    print(f"\nWalk-forward parameter sweep complete: {len(aggregate_results)} parameter sets")
    print(f"Results: {aggregate_path}")
    print(f"Details: {details_path}")
    print("\nTop 10")
    columns = [
        "run",
        "score",
        "avg_net_pnl_pct",
        "median_net_pnl_pct",
        "worst_net_pnl_pct",
        "avg_max_drawdown_pct",
        "worst_max_drawdown_pct",
        "positive_windows",
        "total_windows",
        "stop_loss_pct_on_margin",
        "max_account_drawdown_pct",
        "max_daily_loss_pct",
        "max_consecutive_losses",
        "cooldown_bars_after_loss_streak",
    ]
    print(aggregate_results[columns].head(10).to_string(index=False))


def main() -> None:
    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    backtest_config = raw_config.get("backtest", {})
    strategy_config = raw_config.get("strategy", {})
    data_config = raw_config.get("data", {})
    params_grid = build_parameter_grid(max_runs=args.max_runs, quick=args.quick)

    if args.walk_forward and not args.windows:
        raise SystemExit("--windows is required with --walk-forward")
    windows = parse_windows(args.windows) if args.walk_forward else []
    if args.walk_forward and not windows:
        raise SystemExit("--windows is required with --walk-forward")

    first_config = _base_config(
        args,
        raw_config,
        params_grid[0],
        start_override=min((window[0] for window in windows), default=None),
        end_override=max((window[1] for window in windows), default=None),
    )
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    fast_ema = int(_coalesce(args.fast_ema, strategy_config.get("fast_ema"), 20))
    slow_ema = int(_coalesce(args.slow_ema, strategy_config.get("slow_ema"), 50))

    client = OKXClient(config=raw_config.get("exchange", {}))
    ohlcv = client.fetch_ohlcv_history(
        symbol=first_config.symbol,
        timeframe=first_config.timeframe,
        start=first_config.start,
        end=first_config.end,
        limit=limit,
    )
    if ohlcv.empty:
        raise SystemExit("No OHLCV candles returned for the requested range.")

    strategy = EMACrossoverStrategy(fast_ema=fast_ema, slow_ema=slow_ema)
    output_dir = Path(_coalesce(args.output_dir, backtest_config.get("output_dir"), "logs"))
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.walk_forward:
        _run_walk_forward(args, raw_config, ohlcv, strategy, params_grid, windows, output_dir)
        return

    rows = []
    for run_number, params in enumerate(params_grid, start=1):
        config = _base_config(args, raw_config, params)
        result = BacktestEngine(config).run(ohlcv, strategy)
        rows.append({"run": run_number, **_summary_row(params, result.summary)})

    results = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
    results_path = output_dir / "parameter_sweep_results.csv"
    results.to_csv(results_path, index=False)

    print(f"\nParameter sweep complete: {len(results)} runs")
    print(f"Results: {results_path}")
    print("\nTop 10")
    columns = [
        "run",
        "score",
        "final_equity",
        "net_pnl_pct",
        "max_drawdown_pct",
        "total_trades",
        "win_rate",
        "profit_factor",
        "stop_loss_pct_on_margin",
        "max_account_drawdown_pct",
        "max_daily_loss_pct",
        "max_consecutive_losses",
        "cooldown_bars_after_loss_streak",
    ]
    print(results[columns].head(10).to_string(index=False))


if __name__ == "__main__":
    main()
