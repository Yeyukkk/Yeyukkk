"""
Paper trading entry point — IMPLEMENTED IN SPRINT 5.

Will load config/paper.yaml, instantiate the configured Strategy + PaperExecutor,
and run an orchestration loop that:
  1. fetches latest OHLCV for each (symbol, htf, ltf)
  2. calls strategy.generate_signals()
  3. filters by risk module
  4. forwards survivors to executor.open_position()
  5. calls executor.check_position_exits() each cycle
  6. persists portfolio state
"""
from core.monitoring.logger import get_logger

log = get_logger(__name__)


def main():
    log.error("paper.not_implemented", sprint="will be built in Sprint 5")
    raise SystemExit(
        "run_paper is not implemented yet. "
        "Build order: Sprint 1 (backtest) → 2 (strategy port) → 3 (filters) → "
        "4 (risk) → 5 (paper executor)."
    )


if __name__ == "__main__":
    main()
