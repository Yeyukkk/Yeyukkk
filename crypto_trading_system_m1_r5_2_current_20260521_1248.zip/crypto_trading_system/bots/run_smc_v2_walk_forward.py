"""SMC v2 walk-forward experiment runner.

Runs predefined SMC v2 experiments across multiple time windows in-process,
saves per-window details and aggregate rankings, and prints a ranked
console table.

Public OKX market data only — no live trading, no private endpoints,
no API keys. Research/backtesting only.
"""

from __future__ import annotations

import argparse
import time
from dataclasses import dataclass, replace
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd

from bots.run_backtest import (
    DEFAULT_HTF_TIMEFRAME,
    _build_backtest_config,
    _build_smc_v2,
    _coalesce,
    _load_or_fetch_ohlcv,
    _load_strategy_yaml,
    _load_yaml,
)
from core.backtest import BacktestConfig, BacktestEngine
from core.data import OKXClient
from core.strategy import SMCStrategyV2


ENGINE_RUN_OUTPUT_DIR = "logs/_smc_v2_wf_tmp"


@dataclass(frozen=True)
class Experiment:
    """A single SMC v2 experiment definition."""

    name: str
    long_only: bool = False
    short_only: bool = False
    blocked_entry_hours_utc: tuple[int, ...] = ()
    block_new_york_shorts: bool = False


PREDEFINED_EXPERIMENTS: list[Experiment] = [
    Experiment(name="baseline"),
    Experiment(name="long_only", long_only=True),
    Experiment(name="block_15", blocked_entry_hours_utc=(15,)),
    Experiment(name="long_only_block_15", long_only=True, blocked_entry_hours_utc=(15,)),
    Experiment(name="block_new_york_shorts", block_new_york_shorts=True),
]


DETAILS_COLUMNS: list[str] = [
    "experiment",
    "symbol",
    "timeframe",
    "htf_timeframe",
    "start",
    "end",
    "final_equity",
    "net_pnl",
    "net_pnl_pct",
    "max_drawdown_pct",
    "total_trades",
    "win_rate",
    "profit_factor",
    "long_trades",
    "short_trades",
]


RESULTS_COLUMNS: list[str] = [
    "experiment",
    "windows",
    "positive_windows",
    "avg_net_pnl_pct",
    "median_net_pnl_pct",
    "worst_net_pnl_pct",
    "best_net_pnl_pct",
    "avg_max_drawdown_pct",
    "worst_max_drawdown_pct",
    "total_trades",
    "avg_win_rate",
    "avg_profit_factor",
    "total_long_trades",
    "total_short_trades",
    "score",
]


CONSOLE_COLUMNS: list[str] = [
    "experiment",
    "score",
    "avg_net_pnl_pct",
    "worst_net_pnl_pct",
    "avg_max_drawdown_pct",
    "positive_windows",
    "total_trades",
    "avg_profit_factor",
]


def parse_windows(raw: str | None) -> list[tuple[str, str]]:
    """Parse "YYYY-MM-DD:YYYY-MM-DD,YYYY-MM-DD:YYYY-MM-DD" into [(start, end), ...]."""

    if raw is None or not str(raw).strip():
        raise ValueError("--windows must be a non-empty string")

    windows: list[tuple[str, str]] = []
    for token in str(raw).split(","):
        value = token.strip()
        if not value:
            continue
        parts = value.split(":")
        if len(parts) != 2:
            raise ValueError(f"Invalid window {value!r}: expected START:END format")
        start, end = parts[0].strip(), parts[1].strip()
        if not start or not end:
            raise ValueError(f"Invalid window {value!r}: missing start or end")
        try:
            start_ts = pd.Timestamp(start)
            end_ts = pd.Timestamp(end)
        except Exception as exc:
            raise ValueError(f"Invalid window {value!r}: cannot parse date ({exc})") from exc
        if pd.isna(start_ts) or pd.isna(end_ts):
            raise ValueError(f"Invalid window {value!r}: invalid date")
        if start_ts >= end_ts:
            raise ValueError(f"Invalid window {value!r}: start must be before end")
        windows.append((start, end))

    if not windows:
        raise ValueError("--windows must contain at least one window")
    return windows


def compute_score(
    *,
    avg_net_pnl_pct: float,
    avg_max_drawdown_pct: float,
    worst_net_pnl_pct: float,
) -> float:
    """score = avg_net_pnl_pct - 0.7 * avg_max_drawdown_pct - abs(worst_net_pnl_pct)."""

    return float(avg_net_pnl_pct) - 0.7 * float(avg_max_drawdown_pct) - abs(float(worst_net_pnl_pct))


def aggregate_experiment_rows(experiment_name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate per-window detail rows for a single experiment."""

    if not rows:
        raise ValueError("At least one detail row is required to aggregate")

    net_pnls = [float(row["net_pnl_pct"]) for row in rows]
    drawdowns = [float(row["max_drawdown_pct"]) for row in rows]
    win_rates = [float(row["win_rate"]) for row in rows]
    profit_factors = [
        float(row["profit_factor"])
        for row in rows
        if row.get("profit_factor") is not None and not pd.isna(row["profit_factor"])
    ]
    total_trades = sum(int(row["total_trades"]) for row in rows)
    total_long_trades = sum(int(row["long_trades"]) for row in rows)
    total_short_trades = sum(int(row["short_trades"]) for row in rows)

    avg_net_pnl_pct = sum(net_pnls) / len(net_pnls)
    avg_max_drawdown_pct = sum(drawdowns) / len(drawdowns)
    worst_net_pnl_pct = min(net_pnls)
    best_net_pnl_pct = max(net_pnls)
    worst_max_drawdown_pct = max(drawdowns)
    median_net_pnl_pct = float(median(net_pnls))
    avg_win_rate = sum(win_rates) / len(win_rates)
    avg_profit_factor = (sum(profit_factors) / len(profit_factors)) if profit_factors else 0.0
    positive_windows = sum(1 for value in net_pnls if value > 0)

    return {
        "experiment": experiment_name,
        "windows": len(rows),
        "positive_windows": positive_windows,
        "avg_net_pnl_pct": avg_net_pnl_pct,
        "median_net_pnl_pct": median_net_pnl_pct,
        "worst_net_pnl_pct": worst_net_pnl_pct,
        "best_net_pnl_pct": best_net_pnl_pct,
        "avg_max_drawdown_pct": avg_max_drawdown_pct,
        "worst_max_drawdown_pct": worst_max_drawdown_pct,
        "total_trades": total_trades,
        "avg_win_rate": avg_win_rate,
        "avg_profit_factor": avg_profit_factor,
        "total_long_trades": total_long_trades,
        "total_short_trades": total_short_trades,
        "score": compute_score(
            avg_net_pnl_pct=avg_net_pnl_pct,
            avg_max_drawdown_pct=avg_max_drawdown_pct,
            worst_net_pnl_pct=worst_net_pnl_pct,
        ),
    }


def build_experiment_strategy(
    *,
    experiment: Experiment,
    symbol: str,
    ltf_timeframe: str,
    htf_timeframe: str,
    strategy_yaml: dict[str, Any] | None = None,
) -> SMCStrategyV2:
    """Construct an SMC v2 strategy with experiment switches applied to YAML defaults."""

    return _build_smc_v2(
        strategy_yaml or {},
        symbol=symbol,
        ltf_timeframe=ltf_timeframe,
        htf_timeframe=htf_timeframe,
        cli_long_only=experiment.long_only,
        cli_short_only=experiment.short_only,
        cli_blocked_hours=(
            list(experiment.blocked_entry_hours_utc) if experiment.blocked_entry_hours_utc else None
        ),
        cli_block_new_york_shorts=experiment.block_new_york_shorts,
    )


def _detail_row_from_summary(
    *,
    experiment: Experiment,
    summary: dict[str, Any],
    window: tuple[str, str],
    htf_timeframe: str,
) -> dict[str, Any]:
    start, end = window
    return {
        "experiment": experiment.name,
        "symbol": summary["symbol"],
        "timeframe": summary["timeframe"],
        "htf_timeframe": htf_timeframe,
        "start": start,
        "end": end,
        "final_equity": float(summary["final_equity"]),
        "net_pnl": float(summary["net_pnl"]),
        "net_pnl_pct": float(summary["net_pnl_pct"]) * 100.0,
        "max_drawdown_pct": float(summary["max_drawdown_pct"]) * 100.0,
        "total_trades": int(summary["total_trades"]),
        "win_rate": float(summary["win_rate"]),
        "profit_factor": summary["profit_factor"],
        "long_trades": int(summary["long_trades"]),
        "short_trades": int(summary["short_trades"]),
    }


def _run_one(
    *,
    experiment: Experiment,
    base_config: BacktestConfig,
    window: tuple[str, str],
    htf_timeframe: str,
    ltf_ohlcv: pd.DataFrame,
    htf_ohlcv: pd.DataFrame,
    strategy_yaml: dict[str, Any],
) -> dict[str, Any]:
    start, end = window
    config = replace(
        base_config,
        start=start,
        end=end,
        output_dir=ENGINE_RUN_OUTPUT_DIR,
    )
    strategy = build_experiment_strategy(
        experiment=experiment,
        symbol=config.symbol,
        ltf_timeframe=config.timeframe,
        htf_timeframe=htf_timeframe,
        strategy_yaml=strategy_yaml,
    )
    result = BacktestEngine(config).run(
        ltf_ohlcv,
        strategy,
        htf_ohlcv=htf_ohlcv,
        htf_timeframe=htf_timeframe,
    )
    return _detail_row_from_summary(
        experiment=experiment,
        summary=result.summary,
        window=window,
        htf_timeframe=htf_timeframe,
    )


def _format_console_table(rows: list[dict[str, Any]]) -> str:
    headers = CONSOLE_COLUMNS
    table: list[list[str]] = [list(headers)]
    for row in rows:
        table.append(
            [
                str(row["experiment"]),
                f"{row['score']:.3f}",
                f"{row['avg_net_pnl_pct']:.2f}",
                f"{row['worst_net_pnl_pct']:.2f}",
                f"{row['avg_max_drawdown_pct']:.2f}",
                str(row["positive_windows"]),
                str(row["total_trades"]),
                f"{row['avg_profit_factor']:.2f}",
            ]
        )
    widths = [max(len(line[idx]) for line in table) for idx in range(len(headers))]
    formatted: list[str] = []
    for index, line in enumerate(table):
        formatted.append(" | ".join(value.ljust(widths[idx]) for idx, value in enumerate(line)))
        if index == 0:
            formatted.append("-+-".join("-" * width for width in widths))
    return "\n".join(formatted)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run predefined SMC v2 experiments across walk-forward windows.",
    )
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--htf-timeframe", default=None)
    parser.add_argument(
        "--windows",
        required=True,
        help='Comma-separated windows, format "YYYY-MM-DD:YYYY-MM-DD,YYYY-MM-DD:YYYY-MM-DD".',
    )
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--allow-short", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--output", default="logs/smc_v2_walk_forward_results.csv")
    parser.add_argument("--details-output", default="logs/smc_v2_walk_forward_details.csv")
    return parser


def _inject_config_defaults(args: argparse.Namespace, first_window: tuple[str, str]) -> None:
    """Inject attributes _build_backtest_config expects but our CLI does not expose."""

    args.start = first_window[0]
    args.end = first_window[1]
    args.output_dir = ENGINE_RUN_OUTPUT_DIR
    args.use_smc_filter = False
    args.smc_features_path = None
    args.smc_lookback_bars = None
    args.require_bullish_bos = False


def main() -> None:
    overall_start = time.perf_counter()

    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    windows = parse_windows(args.windows)
    _inject_config_defaults(args, windows[0])
    base_config = _build_backtest_config(args, raw_config)

    data_config = raw_config.get("data", {})
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    client = OKXClient(config=raw_config.get("exchange", {}))

    strategy_yaml = _load_strategy_yaml("smc_v2")
    htf_timeframe = str(
        _coalesce(args.htf_timeframe, strategy_yaml.get("htf_timeframe"), DEFAULT_HTF_TIMEFRAME)
    )

    print(
        f"Walk-forward: symbol={base_config.symbol} timeframe={base_config.timeframe} "
        f"htf={htf_timeframe} windows={len(windows)} experiments={len(PREDEFINED_EXPERIMENTS)}"
    )

    detail_rows: list[dict[str, Any]] = []
    for window_index, window in enumerate(windows, start=1):
        start, end = window
        print(f"\n=== Window {window_index}/{len(windows)}: {start} -> {end} ===")
        ltf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="LTF",
            symbol=base_config.symbol,
            timeframe=base_config.timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if ltf_ohlcv.empty:
            raise SystemExit(f"No LTF data for window {start} -> {end}")
        htf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="HTF",
            symbol=base_config.symbol,
            timeframe=htf_timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if htf_ohlcv.empty:
            raise SystemExit(f"No HTF data for window {start} -> {end}")

        for experiment in PREDEFINED_EXPERIMENTS:
            experiment_start = time.perf_counter()
            print(f"  - Running experiment: {experiment.name}")
            row = _run_one(
                experiment=experiment,
                base_config=base_config,
                window=window,
                htf_timeframe=htf_timeframe,
                ltf_ohlcv=ltf_ohlcv,
                htf_ohlcv=htf_ohlcv,
                strategy_yaml=strategy_yaml,
            )
            elapsed = time.perf_counter() - experiment_start
            print(
                f"    {experiment.name}: net_pnl_pct={row['net_pnl_pct']:.2f}%, "
                f"trades={row['total_trades']}, max_dd={row['max_drawdown_pct']:.2f}%, "
                f"engine={elapsed:.1f}s"
            )
            detail_rows.append(row)

    details_df = pd.DataFrame(detail_rows, columns=DETAILS_COLUMNS)
    details_path = Path(args.details_output)
    details_path.parent.mkdir(parents=True, exist_ok=True)
    details_df.to_csv(details_path, index=False)

    aggregate_rows: list[dict[str, Any]] = []
    for experiment in PREDEFINED_EXPERIMENTS:
        rows_for_experiment = [row for row in detail_rows if row["experiment"] == experiment.name]
        if not rows_for_experiment:
            continue
        aggregate_rows.append(aggregate_experiment_rows(experiment.name, rows_for_experiment))

    aggregate_rows.sort(key=lambda row: row["score"], reverse=True)
    results_df = pd.DataFrame(aggregate_rows, columns=RESULTS_COLUMNS)
    results_path = Path(args.output)
    results_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(results_path, index=False)

    print("\n=== Ranked experiments (by score, descending) ===")
    print(_format_console_table(aggregate_rows))

    total_elapsed = time.perf_counter() - overall_start
    print(f"\nDetails: {details_path}")
    print(f"Results: {results_path}")
    print(f"Total runtime: {total_elapsed:.1f}s")


if __name__ == "__main__":
    main()
