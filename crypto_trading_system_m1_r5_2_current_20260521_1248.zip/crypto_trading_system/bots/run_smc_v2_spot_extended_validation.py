"""R5.1 spot-only extended validation for SMC v2 filters.

Runs only the reference long_only_block_15 filter and the R5.0 best
block_hours_7_8_13_15 filter across an extended BTC/USDT spot window set.
Research/backtesting only: public OHLCV, no private endpoints, no orders.
"""

from __future__ import annotations

import argparse
import time
from dataclasses import replace
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd

from bots.run_backtest import (
    DEFAULT_HTF_TIMEFRAME,
    _build_backtest_config,
    _coalesce,
    _load_or_fetch_ohlcv,
    _load_strategy_yaml,
    _load_yaml,
)
from bots.run_smc_v2_spot_controlled_filters import (
    DETAILS_COLUMNS,
    SpotFilterExperiment,
    build_spot_filter_strategy,
    validate_spot_symbol,
)
from bots.run_smc_v2_walk_forward import parse_windows
from core.backtest import BacktestConfig, BacktestEngine
from core.data import OKXClient


ENGINE_RUN_OUTPUT_DIR = "logs/_r5_1_spot_extended_tmp"
DEFAULT_REPORT_OUTPUT = "logs/r5_1_spot_extended_validation_report.txt"


EXTENDED_EXPERIMENTS: list[SpotFilterExperiment] = [
    SpotFilterExperiment(
        name="reference_long_only_block_15",
        long_only=True,
        blocked_entry_hours_utc=(15,),
    ),
    SpotFilterExperiment(
        name="block_hours_7_8_13_15",
        long_only=True,
        blocked_entry_hours_utc=(7, 8, 13, 15),
    ),
]


RESULTS_COLUMNS: list[str] = [
    "experiment",
    "windows",
    "positive_windows",
    "positive_window_rate",
    "avg_net_pnl_pct",
    "median_net_pnl_pct",
    "worst_net_pnl_pct",
    "best_net_pnl_pct",
    "avg_max_drawdown_pct",
    "worst_max_drawdown_pct",
    "total_trades",
    "avg_win_rate",
    "avg_profit_factor",
    "total_long_trades",
    "total_short_trades",
    "score",
]


ROBUSTNESS_CRITERIA = {
    "windows": 8,
    "positive_window_rate": 0.70,
    "avg_net_pnl_pct": 0.0,
    "avg_profit_factor": 1.2,
    "worst_net_pnl_pct": -6.0,
    "total_trades": 80,
    "avg_max_drawdown_pct": 10.0,
}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run R5.1 BTC/USDT spot-only extended validation.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--htf-timeframe", default=None)
    parser.add_argument("--windows", required=True)
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--allow-short", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--refresh-cache", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--output", default="logs/r5_1_spot_extended_validation_results.csv")
    parser.add_argument("--details-output", default="logs/r5_1_spot_extended_validation_details.csv")
    parser.add_argument("--report-output", default=DEFAULT_REPORT_OUTPUT)
    return parser


def _inject_config_defaults(args: argparse.Namespace, first_window: tuple[str, str]) -> None:
    args.start = first_window[0]
    args.end = first_window[1]
    args.output_dir = ENGINE_RUN_OUTPUT_DIR
    args.use_smc_filter = False
    args.smc_features_path = None
    args.smc_lookback_bars = None
    args.require_bullish_bos = False


def compute_score(row: dict[str, Any]) -> float:
    base = (
        float(row["avg_net_pnl_pct"])
        - 0.7 * float(row["avg_max_drawdown_pct"])
        - abs(float(row["worst_net_pnl_pct"]))
    )
    positive_penalty = max(0.0, ROBUSTNESS_CRITERIA["positive_window_rate"] - float(row["positive_window_rate"])) * 10.0
    low_trade_penalty = max(0, ROBUSTNESS_CRITERIA["total_trades"] - int(row["total_trades"])) * 0.10
    return base - positive_penalty - low_trade_penalty


def aggregate_experiment_rows(experiment_name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        raise ValueError("At least one detail row is required to aggregate")

    net_pnls = [float(row["net_pnl_pct"]) for row in rows]
    drawdowns = [float(row["max_drawdown_pct"]) for row in rows]
    win_rates = [float(row["win_rate"]) for row in rows]
    profit_factors = [
        float(row["profit_factor"])
        for row in rows
        if row.get("profit_factor") is not None and not pd.isna(row["profit_factor"])
    ]
    positive_windows = sum(1 for value in net_pnls if value > 0)
    aggregate = {
        "experiment": experiment_name,
        "windows": len(rows),
        "positive_windows": positive_windows,
        "positive_window_rate": positive_windows / len(rows),
        "avg_net_pnl_pct": sum(net_pnls) / len(net_pnls),
        "median_net_pnl_pct": float(median(net_pnls)),
        "worst_net_pnl_pct": min(net_pnls),
        "best_net_pnl_pct": max(net_pnls),
        "avg_max_drawdown_pct": sum(drawdowns) / len(drawdowns),
        "worst_max_drawdown_pct": max(drawdowns),
        "total_trades": sum(int(row["total_trades"]) for row in rows),
        "avg_win_rate": sum(win_rates) / len(win_rates),
        "avg_profit_factor": (sum(profit_factors) / len(profit_factors)) if profit_factors else 0.0,
        "total_long_trades": sum(int(row["long_trades"]) for row in rows),
        "total_short_trades": sum(int(row["short_trades"]) for row in rows),
    }
    aggregate["score"] = compute_score(aggregate)
    return aggregate


def robustness_failures(row: dict[str, Any]) -> list[str]:
    failures: list[str] = []
    if int(row["windows"]) < ROBUSTNESS_CRITERIA["windows"]:
        failures.append(f"windows < {ROBUSTNESS_CRITERIA['windows']}")
    if float(row["positive_window_rate"]) < ROBUSTNESS_CRITERIA["positive_window_rate"]:
        failures.append("positive_window_rate < 70%")
    if float(row["avg_net_pnl_pct"]) <= ROBUSTNESS_CRITERIA["avg_net_pnl_pct"]:
        failures.append("avg_net_pnl_pct <= 0")
    if float(row["avg_profit_factor"]) <= ROBUSTNESS_CRITERIA["avg_profit_factor"]:
        failures.append("avg_profit_factor <= 1.2")
    if float(row["worst_net_pnl_pct"]) <= ROBUSTNESS_CRITERIA["worst_net_pnl_pct"]:
        failures.append("worst_net_pnl_pct <= -6.0")
    if int(row["total_trades"]) < ROBUSTNESS_CRITERIA["total_trades"]:
        failures.append("total_trades < 80")
    if float(row["avg_max_drawdown_pct"]) >= ROBUSTNESS_CRITERIA["avg_max_drawdown_pct"]:
        failures.append("avg_max_drawdown_pct >= 10.0")
    return failures


def passes_robustness(row: dict[str, Any]) -> bool:
    return not robustness_failures(row)


def _detail_row_from_summary(
    *,
    experiment: SpotFilterExperiment,
    summary: dict[str, Any],
    window: tuple[str, str],
    htf_timeframe: str,
) -> dict[str, Any]:
    start, end = window
    return {
        "experiment": experiment.name,
        "symbol": summary["symbol"],
        "timeframe": summary["timeframe"],
        "htf_timeframe": htf_timeframe,
        "start": start,
        "end": end,
        "final_equity": float(summary["final_equity"]),
        "net_pnl": float(summary["net_pnl"]),
        "net_pnl_pct": float(summary["net_pnl_pct"]) * 100.0,
        "max_drawdown_pct": float(summary["max_drawdown_pct"]) * 100.0,
        "total_trades": int(summary["total_trades"]),
        "win_rate": float(summary["win_rate"]),
        "profit_factor": summary["profit_factor"],
        "long_trades": int(summary["long_trades"]),
        "short_trades": int(summary["short_trades"]),
    }


def run_one_window(
    *,
    experiment: SpotFilterExperiment,
    base_config: BacktestConfig,
    window: tuple[str, str],
    htf_timeframe: str,
    ltf_ohlcv: pd.DataFrame,
    htf_ohlcv: pd.DataFrame,
    strategy_yaml: dict[str, Any],
) -> dict[str, Any]:
    start, end = window
    config = replace(base_config, start=start, end=end, output_dir=ENGINE_RUN_OUTPUT_DIR)
    strategy = build_spot_filter_strategy(
        experiment=experiment,
        symbol=config.symbol,
        ltf_timeframe=config.timeframe,
        htf_timeframe=htf_timeframe,
        strategy_yaml=strategy_yaml,
    )
    result = BacktestEngine(config).run(
        ltf_ohlcv,
        strategy,
        htf_ohlcv=htf_ohlcv,
        htf_timeframe=htf_timeframe,
    )
    return _detail_row_from_summary(
        experiment=experiment,
        summary=result.summary,
        window=window,
        htf_timeframe=htf_timeframe,
    )


def format_ranked_table(rows: list[dict[str, Any]]) -> str:
    columns = [
        "experiment",
        "score",
        "windows",
        "positive_windows",
        "positive_window_rate",
        "avg_net_pnl_pct",
        "worst_net_pnl_pct",
        "avg_max_drawdown_pct",
        "total_trades",
        "avg_profit_factor",
    ]
    frame = pd.DataFrame(rows, columns=columns)
    if frame.empty:
        return ""
    return frame.to_string(
        index=False,
        formatters={
            "score": "{:.2f}".format,
            "positive_window_rate": "{:.2%}".format,
            "avg_net_pnl_pct": "{:.2f}".format,
            "worst_net_pnl_pct": "{:.2f}".format,
            "avg_max_drawdown_pct": "{:.2f}".format,
            "avg_profit_factor": "{:.2f}".format,
        },
    )


def build_report(results: pd.DataFrame, details: pd.DataFrame) -> str:
    ranked = results.sort_values("score", ascending=False).reset_index(drop=True)
    reference = results[results["experiment"] == "reference_long_only_block_15"].iloc[0].to_dict()
    block = results[results["experiment"] == "block_hours_7_8_13_15"].iloc[0].to_dict()
    block_details = details[details["experiment"] == "block_hours_7_8_13_15"].copy()
    worst_window = block_details.sort_values("net_pnl_pct", ascending=True).iloc[0].to_dict()
    failures = robustness_failures(block)

    lines = [
        "R5.1 Spot Extended Validation Report",
        "Research only. This is not a profitability claim.",
        "",
        "Ranked table:",
        format_ranked_table(ranked.to_dict(orient="records")),
        "",
        "Reference vs block_hours_7_8_13_15:",
        (
            f"Reference avg_net_pnl_pct={reference['avg_net_pnl_pct']:.2f}, "
            f"positive_windows={int(reference['positive_windows'])}/{int(reference['windows'])}, "
            f"total_trades={int(reference['total_trades'])}, avg_profit_factor={reference['avg_profit_factor']:.2f}."
        ),
        (
            f"Block-hours avg_net_pnl_pct={block['avg_net_pnl_pct']:.2f}, "
            f"positive_windows={int(block['positive_windows'])}/{int(block['windows'])} "
            f"({float(block['positive_window_rate']) * 100:.1f}%), "
            f"total_trades={int(block['total_trades'])}, avg_profit_factor={block['avg_profit_factor']:.2f}."
        ),
        "",
        "Per-window performance for block_hours_7_8_13_15:",
        block_details[
            ["start", "end", "net_pnl_pct", "max_drawdown_pct", "total_trades", "profit_factor"]
        ].to_string(index=False),
        "",
        (
            f"Worst block-hours window: {worst_window['start']} -> {worst_window['end']} "
            f"at {worst_window['net_pnl_pct']:.2f}%."
        ),
        f"Average drawdown: {block['avg_max_drawdown_pct']:.2f}%.",
        f"Worst drawdown: {block['worst_max_drawdown_pct']:.2f}%.",
    ]
    if failures:
        lines.append("R5.1 robustness result: FAILED.")
        lines.append("Failed criteria: " + "; ".join(failures) + ".")
    else:
        lines.append("R5.1 robustness result: PASSED.")
    lines.append("Explicit statement: this is research only, not a profitability claim.")
    return "\n".join(lines) + "\n"


def main() -> None:
    overall_start = time.perf_counter()
    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    windows = parse_windows(args.windows)
    _inject_config_defaults(args, windows[0])
    base_config = _build_backtest_config(args, raw_config)
    validate_spot_symbol(base_config.symbol)

    data_config = raw_config.get("data", {})
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    client = OKXClient(config=raw_config.get("exchange", {}))
    strategy_yaml = _load_strategy_yaml("smc_v2")
    htf_timeframe = str(_coalesce(args.htf_timeframe, strategy_yaml.get("htf_timeframe"), DEFAULT_HTF_TIMEFRAME))

    print(
        f"R5.1 spot extended validation: symbol={base_config.symbol} timeframe={base_config.timeframe} "
        f"htf={htf_timeframe} windows={len(windows)} experiments={len(EXTENDED_EXPERIMENTS)}"
    )

    detail_rows: list[dict[str, Any]] = []
    for window_index, window in enumerate(windows, start=1):
        start, end = window
        print(f"\n=== Window {window_index}/{len(windows)}: {start} -> {end} ===")
        ltf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="LTF",
            symbol=base_config.symbol,
            timeframe=base_config.timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        htf_ohlcv = _load_or_fetch_ohlcv(
            client,
            label="HTF",
            symbol=base_config.symbol,
            timeframe=htf_timeframe,
            start=start,
            end=end,
            limit=limit,
            no_cache=args.no_cache,
            refresh_cache=args.refresh_cache,
        )
        if ltf_ohlcv.empty or htf_ohlcv.empty:
            raise SystemExit(f"No OHLCV data for window {start} -> {end}")

        for experiment in EXTENDED_EXPERIMENTS:
            started = time.perf_counter()
            print(f"  - Running experiment: {experiment.name}")
            row = run_one_window(
                experiment=experiment,
                base_config=base_config,
                window=window,
                htf_timeframe=htf_timeframe,
                ltf_ohlcv=ltf_ohlcv,
                htf_ohlcv=htf_ohlcv,
                strategy_yaml=strategy_yaml,
            )
            print(
                f"    {experiment.name}: net_pnl_pct={row['net_pnl_pct']:.2f}%, "
                f"trades={row['total_trades']}, max_dd={row['max_drawdown_pct']:.2f}%, "
                f"elapsed={time.perf_counter() - started:.1f}s"
            )
            detail_rows.append(row)

    details_df = pd.DataFrame(detail_rows, columns=DETAILS_COLUMNS)
    details_path = Path(args.details_output)
    details_path.parent.mkdir(parents=True, exist_ok=True)
    details_df.to_csv(details_path, index=False)

    aggregate_rows = [
        aggregate_experiment_rows(
            experiment.name,
            [row for row in detail_rows if row["experiment"] == experiment.name],
        )
        for experiment in EXTENDED_EXPERIMENTS
    ]
    aggregate_rows.sort(key=lambda row: row["score"], reverse=True)
    results_df = pd.DataFrame(aggregate_rows, columns=RESULTS_COLUMNS)
    results_path = Path(args.output)
    results_path.parent.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(results_path, index=False)

    report = build_report(results_df, details_df)
    report_path = Path(args.report_output)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")

    print("\n=== Ranked R5.1 spot extended validation ===")
    print(format_ranked_table(aggregate_rows))
    print(f"\nDetails: {details_path}")
    print(f"Results: {results_path}")
    print(f"Report: {report_path}")
    print(f"Total runtime: {time.perf_counter() - overall_start:.1f}s")


if __name__ == "__main__":
    main()
