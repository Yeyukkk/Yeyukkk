"""Run public-data-only SMC-filtered walk-forward backtests."""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd

from bots.run_backtest import _coalesce, _load_yaml
from bots.run_parameter_sweep import parse_windows
from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.data import OKXClient
from core.strategy import build_smc_features, save_smc_features


def safe_window_label(start: str, end: str) -> str:
    safe_start = re.sub(r"[^A-Za-z0-9]+", "-", start).strip("-")
    safe_end = re.sub(r"[^A-Za-z0-9]+", "-", end).strip("-")
    return f"{safe_start}_{safe_end}"


def aggregate_window_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not rows:
        raise ValueError("At least one walk-forward result row is required")

    net_pnls = [float(row["net_pnl_pct"]) for row in rows]
    drawdowns = [float(row["max_drawdown_pct"]) for row in rows]
    return {
        "average_net_pnl_pct": sum(net_pnls) / len(net_pnls),
        "median_net_pnl_pct": median(net_pnls),
        "worst_net_pnl_pct": min(net_pnls),
        "average_max_drawdown_pct": sum(drawdowns) / len(drawdowns),
        "worst_max_drawdown_pct": max(drawdowns),
        "positive_windows": sum(1 for value in net_pnls if value > 0),
        "total_windows": len(rows),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run SMC-filtered walk-forward validation.")
    parser.add_argument("--config", default=None)
    parser.add_argument("--symbol", default=None)
    parser.add_argument("--timeframe", default=None)
    parser.add_argument("--windows", required=True)
    parser.add_argument("--initial-equity", type=float, default=None)
    parser.add_argument("--fee-rate", type=float, default=None)
    parser.add_argument("--slippage-bps", type=float, default=None)
    parser.add_argument("--position-size-pct", type=float, default=None)
    parser.add_argument("--leverage", type=float, default=None)
    parser.add_argument("--max-margin-pct", type=float, default=None)
    parser.add_argument("--stop-loss-pct-on-margin", type=float, default=None)
    parser.add_argument("--take-profit-pct-on-margin", type=float, default=None)
    parser.add_argument("--max-account-drawdown-pct", type=float, default=None)
    parser.add_argument("--max-daily-loss-pct", type=float, default=None)
    parser.add_argument("--max-consecutive-losses", type=int, default=None)
    parser.add_argument("--cooldown-bars-after-loss-streak", type=int, default=None)
    parser.add_argument("--maintenance-margin-pct", type=float, default=None)
    parser.add_argument("--disable-liquidation-check", action="store_true")
    parser.add_argument("--smc-lookback-bars", type=int, default=None)
    parser.add_argument("--require-bullish-bos", action="store_true")
    parser.add_argument("--fast-ema", type=int, default=None)
    parser.add_argument("--slow-ema", type=int, default=None)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--swing-length", type=int, default=50)
    parser.add_argument("--previous-time-frame", default="1D")
    parser.add_argument("--session", default="London")
    parser.add_argument("--session-time-zone", default="UTC")
    return parser


def _required(value: Any, name: str) -> str:
    if value is None:
        raise SystemExit(f"{name} is required unless provided in config.")
    return str(value)


def _window_bounds(windows: list[tuple[str, str]]) -> tuple[str, str]:
    first = min((window[0] for window in windows), key=lambda value: pd.to_datetime(value, utc=True))
    last = max((window[1] for window in windows), key=lambda value: pd.to_datetime(value, utc=True))
    return first, last


def _window_ohlcv(ohlcv: pd.DataFrame, start: str, end: str) -> pd.DataFrame:
    timestamps = pd.to_datetime(ohlcv["timestamp"], utc=True)
    start_ts = pd.to_datetime(start, utc=True)
    end_ts = pd.to_datetime(end, utc=True)
    return ohlcv[(timestamps >= start_ts) & (timestamps < end_ts)].copy().reset_index(drop=True)


def _backtest_config(
    args: argparse.Namespace,
    raw_config: dict[str, Any],
    start: str,
    end: str,
    output_dir: Path,
    smc_features_path: Path,
) -> BacktestConfig:
    backtest_config = raw_config.get("backtest", {})
    symbol = _required(_coalesce(args.symbol, backtest_config.get("symbol")), "--symbol")
    timeframe = _required(_coalesce(args.timeframe, backtest_config.get("timeframe")), "--timeframe")
    liquidation_enabled = False if args.disable_liquidation_check else bool(
        backtest_config.get("liquidation_check_enabled", True)
    )
    stop_loss = _coalesce(args.stop_loss_pct_on_margin, backtest_config.get("stop_loss_pct_on_margin"), 0.30)
    take_profit = _coalesce(args.take_profit_pct_on_margin, backtest_config.get("take_profit_pct_on_margin"))

    return BacktestConfig(
        symbol=symbol,
        timeframe=timeframe,
        start=start,
        end=end,
        initial_equity=float(_coalesce(args.initial_equity, backtest_config.get("initial_equity"), 10_000.0)),
        fee_rate=float(_coalesce(args.fee_rate, backtest_config.get("fee_rate"), 0.0005)),
        slippage_bps=float(_coalesce(args.slippage_bps, backtest_config.get("slippage_bps"), 2.0)),
        position_size_pct=float(_coalesce(args.position_size_pct, backtest_config.get("position_size_pct"), 1.0)),
        leverage=float(_coalesce(args.leverage, backtest_config.get("leverage"), 10.0)),
        max_margin_pct=float(_coalesce(args.max_margin_pct, backtest_config.get("max_margin_pct"), 0.20)),
        stop_loss_pct_on_margin=float(stop_loss) if stop_loss is not None else None,
        take_profit_pct_on_margin=float(take_profit) if take_profit is not None else None,
        max_account_drawdown_pct=float(
            _coalesce(args.max_account_drawdown_pct, backtest_config.get("max_account_drawdown_pct"), 0.30)
        ),
        max_daily_loss_pct=float(_coalesce(args.max_daily_loss_pct, backtest_config.get("max_daily_loss_pct"), 0.05)),
        max_consecutive_losses=int(
            _coalesce(args.max_consecutive_losses, backtest_config.get("max_consecutive_losses"), 5)
        ),
        cooldown_bars_after_loss_streak=int(
            _coalesce(
                args.cooldown_bars_after_loss_streak,
                backtest_config.get("cooldown_bars_after_loss_streak"),
                20,
            )
        ),
        liquidation_check_enabled=liquidation_enabled,
        maintenance_margin_pct=float(
            _coalesce(args.maintenance_margin_pct, backtest_config.get("maintenance_margin_pct"), 0.005)
        ),
        use_smc_filter=True,
        smc_features_path=str(smc_features_path),
        smc_lookback_bars=int(_coalesce(args.smc_lookback_bars, backtest_config.get("smc_lookback_bars"), 20)),
        require_bullish_bos=bool(args.require_bullish_bos or backtest_config.get("require_bullish_bos", False)),
        allow_short=False,
        output_dir=output_dir,
    )


def _result_row(window_start: str, window_end: str, summary: dict[str, Any]) -> dict[str, Any]:
    return {
        "window_start": window_start,
        "window_end": window_end,
        "final_equity": summary["final_equity"],
        "net_pnl_pct": summary["net_pnl_pct"],
        "max_drawdown_pct": summary["max_drawdown_pct"],
        "total_trades": summary["total_trades"],
        "win_rate": summary["win_rate"],
        "profit_factor": summary["profit_factor"],
        "skipped_signals": summary.get("skipped_signals", 0),
    }


def main() -> None:
    args = _build_parser().parse_args()
    raw_config = _load_yaml(args.config)
    backtest_config = raw_config.get("backtest", {})
    strategy_config = raw_config.get("strategy", {})
    data_config = raw_config.get("data", {})
    windows = parse_windows(args.windows)

    symbol = _required(_coalesce(args.symbol, backtest_config.get("symbol")), "--symbol")
    timeframe = _required(_coalesce(args.timeframe, backtest_config.get("timeframe")), "--timeframe")
    fetch_start, fetch_end = _window_bounds(windows)
    limit = int(_coalesce(args.limit, data_config.get("limit"), 100))
    output_root = Path(_coalesce(args.output_dir, backtest_config.get("output_dir"), "logs"))
    output_root.mkdir(parents=True, exist_ok=True)
    walk_forward_dir = output_root / "smc_walk_forward"
    walk_forward_dir.mkdir(parents=True, exist_ok=True)

    client = OKXClient(config=raw_config.get("exchange", {}))
    ohlcv = client.fetch_ohlcv_history(
        symbol=symbol,
        timeframe=timeframe,
        start=fetch_start,
        end=fetch_end,
        limit=limit,
    )
    if ohlcv.empty:
        raise SystemExit("No OHLCV candles returned for the requested walk-forward range.")

    fast_ema = int(_coalesce(args.fast_ema, strategy_config.get("fast_ema"), 20))
    slow_ema = int(_coalesce(args.slow_ema, strategy_config.get("slow_ema"), 50))
    strategy = EMACrossoverStrategy(fast_ema=fast_ema, slow_ema=slow_ema)
    rows: list[dict[str, Any]] = []

    for window_start, window_end in windows:
        window_data = _window_ohlcv(ohlcv, window_start, window_end)
        if window_data.empty:
            raise SystemExit(f"No OHLCV candles returned for window {window_start}:{window_end}.")

        label = safe_window_label(window_start, window_end)
        features_path = output_root / f"smc_features_{label}.csv"
        window_output_dir = walk_forward_dir / label
        features = build_smc_features(
            window_data,
            swing_length=args.swing_length,
            previous_time_frame=args.previous_time_frame,
            session=args.session,
            session_time_zone=args.session_time_zone,
        )
        save_smc_features(features, features_path)

        config = _backtest_config(
            args=args,
            raw_config=raw_config,
            start=window_start,
            end=window_end,
            output_dir=window_output_dir,
            smc_features_path=features_path,
        )
        result = BacktestEngine(config).run(window_data, strategy)
        rows.append(_result_row(window_start, window_end, result.summary))

    results = pd.DataFrame(rows)
    results_path = output_root / "smc_walk_forward_results.csv"
    results.to_csv(results_path, index=False)
    aggregate = aggregate_window_metrics(rows)

    print("\nSMC walk-forward complete")
    print(f"Results: {results_path}")
    print(f"Window outputs: {walk_forward_dir}")
    print(f"Average net_pnl_pct: {aggregate['average_net_pnl_pct'] * 100:.2f}%")
    print(f"Median net_pnl_pct: {aggregate['median_net_pnl_pct'] * 100:.2f}%")
    print(f"Worst net_pnl_pct: {aggregate['worst_net_pnl_pct'] * 100:.2f}%")
    print(f"Average max_drawdown_pct: {aggregate['average_max_drawdown_pct'] * 100:.2f}%")
    print(f"Worst max_drawdown_pct: {aggregate['worst_max_drawdown_pct'] * 100:.2f}%")
    print(f"Positive windows: {aggregate['positive_windows']} / {aggregate['total_windows']}")


if __name__ == "__main__":
    main()
