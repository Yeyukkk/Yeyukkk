"""
Executor interface.

Three implementations will share this contract:
  - BacktestExecutor (Sprint 1): simulates fills on historical bars
  - PaperExecutor    (Sprint 5): simulates fills on live ticks
  - LiveExecutor     (Sprint 6): real OKX orders with native algo SL/TP

Keeping a single interface means a bot can swap modes by changing one line.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, Any

from core.strategy.signal import Signal


@dataclass
class Position:
    """Active position tracked by an executor."""
    id: str
    symbol: str
    direction: Literal["LONG", "SHORT"]
    entry_price: float
    amount: float                  # base-asset quantity (coins)
    notional_usdt: float           # entry_price * amount
    margin_usdt: float             # notional / leverage
    leverage: int
    stop_loss: float
    take_profit: float
    opened_at: datetime
    strategy_name: str | None = None
    htf: str | None = None
    ltf: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class FillResult:
    """Returned by open_position / close_position."""
    success: bool
    position: Position | None = None
    fill_price: float | None = None
    fees_paid: float = 0.0
    gross_pnl: float = 0.0
    net_pnl: float = 0.0
    reason: str = ""


class Executor(ABC):

    # Identifies the mode in logs / Telegram. Set by subclasses.
    mode: str = "ABSTRACT"

    @abstractmethod
    def open_position(self, signal: Signal, amount: float) -> FillResult:
        """
        Open a position with the requested base-asset amount.
        The executor is responsible for:
          - applying its own fill model (slippage/fees/queue)
          - rejecting if it cannot place SL/TP atomically (live)
          - returning a FillResult either way
        """
        ...

    @abstractmethod
    def close_position(
        self,
        position: Position,
        exit_price: float | None,
        reason: str,
    ) -> FillResult:
        """
        Close (flatten) a position. exit_price=None means 'market close at current'.
        """
        ...

    @abstractmethod
    def get_open_positions(self) -> list[Position]:
        ...

    @abstractmethod
    def get_equity_usdt(self) -> float:
        """Current account equity in USDT (paper balance, live balance, backtest cash)."""
        ...

    @abstractmethod
    def check_position_exits(self) -> list[FillResult]:
        """
        Called once per cycle. The executor inspects current price vs SL/TP
        on each open position and closes any that hit. Returns list of fills.

        Live executors using exchange-side algo orders may return [] here
        (closes happen out-of-band) and rely on a separate reconciliation step.
        """
        ...
