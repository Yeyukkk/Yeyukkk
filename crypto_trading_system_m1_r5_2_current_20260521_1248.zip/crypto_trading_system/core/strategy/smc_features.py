"""Smart Money Concepts feature extraction.

This module only creates offline features. It does not generate orders or feed
SMC signals into the existing EMA strategy.
"""

from __future__ import annotations

import contextlib
import io
import re
from pathlib import Path
from typing import Callable

import pandas as pd

with contextlib.redirect_stdout(io.StringIO()):
    from smartmoneyconcepts import smc


OHLCV_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]


def _snake_case(value: str) -> str:
    value = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", value)
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", value).lower()
    return re.sub(r"[^a-z0-9]+", "_", value).strip("_")


def _prepare_ohlcv(ohlcv: pd.DataFrame) -> pd.DataFrame:
    missing = [column for column in OHLCV_COLUMNS if column not in ohlcv.columns]
    if missing:
        raise ValueError(f"Missing OHLCV columns: {missing}")

    df = ohlcv[OHLCV_COLUMNS].copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    for column in OHLCV_COLUMNS[1:]:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    df = df.dropna(subset=OHLCV_COLUMNS)
    df = df.drop_duplicates("timestamp")
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def _smc_input(ohlcv: pd.DataFrame) -> pd.DataFrame:
    return ohlcv[["open", "high", "low", "close", "volume"]].copy().reset_index(drop=True)


def _smc_time_input(ohlcv: pd.DataFrame) -> pd.DataFrame:
    df = ohlcv[OHLCV_COLUMNS].copy()
    return df.set_index("timestamp")[["open", "high", "low", "close", "volume"]]


def _append_feature(
    features: pd.DataFrame,
    raw: pd.DataFrame,
    prefix: str,
    confirmation_bars: int,
    primary_columns: list[str],
) -> None:
    raw = raw.reset_index(drop=True)
    for column in raw.columns:
        name = f"{prefix}_{_snake_case(str(column))}"
        features[f"{name}_raw"] = raw[column]
        features[f"{name}_confirmed"] = raw[column].shift(confirmation_bars)

    for column in primary_columns:
        if column in raw.columns:
            name = f"{prefix}_{_snake_case(str(column))}"
            features[f"{name}_is_confirmed"] = features[f"{name}_confirmed"].notna()

    features[f"{prefix}_confirmation_bars"] = confirmation_bars


def _try_feature(name: str, fn: Callable[[], pd.DataFrame]) -> pd.DataFrame | None:
    try:
        return fn()
    except Exception:
        return None


def build_smc_features(
    ohlcv: pd.DataFrame,
    swing_length: int = 50,
    previous_time_frame: str = "1D",
    session: str = "London",
    session_time_zone: str = "UTC",
) -> pd.DataFrame:
    """Return OHLCV plus raw and confirmed SMC feature columns.

    `swing_highs_lows` uses future candles, so swing-derived features are
    shifted by `swing_length` bars. FVG uses the next candle, so it is shifted by
    one bar. Previous high/low and session flags are not shifted.
    """

    base = _prepare_ohlcv(ohlcv)
    smc_ohlcv = _smc_input(base)
    smc_time_ohlcv = _smc_time_input(base)
    features = base.copy()

    swings = _try_feature("swing_highs_lows", lambda: smc.swing_highs_lows(smc_ohlcv, swing_length=swing_length))
    if swings is not None:
        _append_feature(features, swings, "smc_swing", swing_length, ["HighLow"])

    if swings is not None:
        bos_choch = _try_feature("bos_choch", lambda: smc.bos_choch(smc_ohlcv, swings))
        if bos_choch is not None:
            _append_feature(features, bos_choch, "smc_bos_choch", swing_length, ["BOS", "CHOCH"])

        order_blocks = _try_feature("ob", lambda: smc.ob(smc_ohlcv, swings))
        if order_blocks is not None:
            _append_feature(features, order_blocks, "smc_ob", swing_length, ["OB"])

        liquidity = _try_feature("liquidity", lambda: smc.liquidity(smc_ohlcv, swings))
        if liquidity is not None:
            _append_feature(features, liquidity, "smc_liquidity", swing_length, ["Liquidity"])

    fvg = _try_feature("fvg", lambda: smc.fvg(smc_ohlcv))
    if fvg is not None:
        _append_feature(features, fvg, "smc_fvg", 1, ["FVG"])

    previous = _try_feature(
        "previous_high_low",
        lambda: smc.previous_high_low(smc_time_ohlcv, time_frame=previous_time_frame),
    )
    if previous is not None:
        _append_feature(features, previous, "smc_previous_high_low", 0, ["BrokenHigh", "BrokenLow"])

    session_features = _try_feature(
        "sessions",
        lambda: smc.sessions(smc_time_ohlcv.copy(), session=session, time_zone=session_time_zone),
    )
    if session_features is not None:
        _append_feature(features, session_features, "smc_sessions", 0, ["Active"])

    return features


def save_smc_features(features: pd.DataFrame, output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    features.to_csv(path, index=False)
    return path
