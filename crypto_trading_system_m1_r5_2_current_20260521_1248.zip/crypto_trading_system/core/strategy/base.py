"""
Strategy interface.

Implementations live as sibling modules (smc_ict.py in Sprint 2).
A strategy is PURE: given (HTF df, LTF df), it returns Signals.
It does not fetch data, does not place orders, does not know about the executor.

This purity is what makes the same code work in backtest, paper, and live.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import pandas as pd

from core.strategy.signal import Signal


class Strategy(ABC):
    """
    Subclasses receive their parameters from a single dict (loaded from YAML).
    """

    def __init__(self, params: dict[str, Any]):
        self.params = params
        self.name: str = params.get("name", self.__class__.__name__)

    @abstractmethod
    def generate_signals(
        self,
        symbol: str,
        htf_df: pd.DataFrame,
        ltf_df: pd.DataFrame,
    ) -> list[Signal]:
        """
        Return a (possibly empty) list of Signal objects for the latest bar.

        IMPORTANT for backtest correctness:
        - Only use information available up to ltf_df.iloc[-1]
        - Never peek at future bars
        - Avoid look-ahead bias in indicator calculations
        """
        ...

    # Optional hook for strategies that want to maintain rolling state
    def reset_state(self) -> None:  # noqa: B027
        pass
