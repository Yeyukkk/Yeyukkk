"""
Signal is the contract between Strategy and Executor.

A Strategy returns a list of Signals. An Executor turns Signals into orders
(paper, backtest, or live). Neither side knows the other's implementation.

Keep this dataclass STABLE — every executor depends on its shape.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Literal, Any

Direction = Literal["LONG", "SHORT"]
SignalSide = Literal["long", "short"]
SignalAction = Literal["entry", "exit"]


@dataclass(frozen=True)
class Signal:
    """Structured strategy signal.

    The older `direction` / `stop_loss` / `take_profit` fields are retained for
    executor compatibility. New backtest code should prefer `side`, `action`,
    `stop_loss_price`, and `take_profit_price`.
    """

    symbol: str
    direction: Direction | None = None
    timestamp: datetime | None = None

    entry_price: float | None = None
    stop_loss: float | None = None
    take_profit: float | None = None

    score: float | None = None
    reasons: list[str] = field(default_factory=list)

    htf: str | None = None
    ltf: str | None = None
    strategy_name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    timeframe: str | None = None
    side: SignalSide | None = None
    action: SignalAction = "entry"
    stop_loss_price: float | None = None
    take_profit_price: float | None = None
    reason: str = ""

    def __post_init__(self) -> None:
        side = self.side
        direction = self.direction
        if side is None and direction is not None:
            side = direction.lower()  # type: ignore[assignment]
        if direction is None and side is not None:
            direction = side.upper()  # type: ignore[assignment]

        if side is not None and side not in ("long", "short"):
            raise ValueError(f"bad side: {side}")
        if direction is not None and direction not in ("LONG", "SHORT"):
            raise ValueError(f"bad direction: {direction}")
        if self.action not in ("entry", "exit"):
            raise ValueError(f"bad action: {self.action}")

        object.__setattr__(self, "side", side)
        object.__setattr__(self, "direction", direction)
        object.__setattr__(self, "stop_loss_price", self.stop_loss_price or self.stop_loss)
        object.__setattr__(self, "take_profit_price", self.take_profit_price or self.take_profit)
        if self.stop_loss is None and self.stop_loss_price is not None:
            object.__setattr__(self, "stop_loss", self.stop_loss_price)
        if self.take_profit is None and self.take_profit_price is not None:
            object.__setattr__(self, "take_profit", self.take_profit_price)
        if self.timeframe is None and self.ltf is not None:
            object.__setattr__(self, "timeframe", self.ltf)
        if not self.reason and self.reasons:
            object.__setattr__(self, "reason", "; ".join(self.reasons))

    # ---------------------------------------------------------------- properties

    @property
    def risk_per_unit(self) -> float:
        """Distance from entry to SL in price terms."""
        if self.entry_price is None or self.stop_loss_price is None:
            return 0.0
        return abs(self.entry_price - self.stop_loss_price)

    @property
    def reward_per_unit(self) -> float:
        """Distance from entry to TP in price terms."""
        if self.entry_price is None or self.take_profit_price is None:
            return 0.0
        return abs(self.take_profit_price - self.entry_price)

    @property
    def rr_ratio(self) -> float:
        if self.risk_per_unit <= 0:
            return 0.0
        return self.reward_per_unit / self.risk_per_unit

    @property
    def sl_distance_pct(self) -> float:
        if self.entry_price is None or self.entry_price <= 0:
            return 0.0
        return self.risk_per_unit / self.entry_price

    @property
    def tp_distance_pct(self) -> float:
        if self.entry_price is None or self.entry_price <= 0:
            return 0.0
        return self.reward_per_unit / self.entry_price

    # --------------------------------------------------------------- validation

    def validate(self) -> None:
        """Raise if the signal is geometrically nonsensical."""
        if self.side not in ("long", "short"):
            raise ValueError(f"bad side: {self.side}")
        if self.entry_price is None or self.stop_loss_price is None or self.take_profit_price is None:
            raise ValueError("entry, stop loss, and take profit prices are required")
        if self.entry_price <= 0 or self.stop_loss_price <= 0 or self.take_profit_price <= 0:
            raise ValueError("prices must be positive")
        if self.side == "long":
            if not (self.stop_loss_price < self.entry_price < self.take_profit_price):
                raise ValueError(
                    f"long geometry invalid: SL={self.stop_loss_price}, "
                    f"entry={self.entry_price}, TP={self.take_profit_price}"
                )
        else:
            if not (self.take_profit_price < self.entry_price < self.stop_loss_price):
                raise ValueError(
                    f"short geometry invalid: TP={self.take_profit_price}, "
                    f"entry={self.entry_price}, SL={self.stop_loss_price}"
                )
        if self.risk_per_unit <= 0:
            raise ValueError("risk per unit must be > 0")

    def validate_geometry(self) -> None:
        """Alias for tests and strategy code that use geometry terminology."""

        self.validate()

    # ------------------------------------------------------------- serialization

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat() if self.timestamp is not None else None
        return d
