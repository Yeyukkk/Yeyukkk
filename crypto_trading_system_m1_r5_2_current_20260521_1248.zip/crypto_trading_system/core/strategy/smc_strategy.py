"""Minimal SMC/ICT strategy v1.

This module is research-only. It creates structured backtest signals from
closed LTF/HTF candle slices and does not place orders.
"""

from __future__ import annotations

import contextlib
import io
import re
from dataclasses import dataclass, field
from datetime import time
from typing import Any, Literal

import pandas as pd

from core.strategy.signal import Signal

with contextlib.suppress(Exception), contextlib.redirect_stdout(io.StringIO()):
    from smartmoneyconcepts import smc as _smc  # type: ignore


Bias = Literal["bullish", "bearish", "neutral"]


@dataclass(frozen=True)
class _FVGSetup:
    direction: Bias
    index: int
    timestamp: pd.Timestamp
    bottom: float
    top: float
    mitigation_index: int


@dataclass(frozen=True)
class SMCStrategyV1:
    symbol: str = "BTC/USDT"
    htf_timeframe: str = "1h"
    ltf_timeframe: str = "15m"
    atr_period: int = 14
    atr_buffer_multiplier: float = 0.5
    risk_reward: float = 2.0
    min_score: float = 0.0
    structure_lookback: int = 80
    fvg_lookback: int = 50
    ltf_lookback_bars: int = 300
    htf_lookback_bars: int = 200
    min_risk_pct: float = 0.001
    min_target_pct: float = 0.002
    min_reward_to_fee_ratio: float = 2.0
    estimated_round_trip_cost_pct: float = 0.0014
    min_rr: float = 1.5
    setup_cooldown_bars: int = 4
    _last_emitted_setup: tuple[str, float, float, int] | None = field(default=None, init=False, compare=False)

    @property
    def name(self) -> str:
        return "smc_v1"

    def generate_signals(self, ltf_ohlcv: pd.DataFrame, htf_ohlcv: pd.DataFrame) -> list[Signal]:
        current_bar_number = len(ltf_ohlcv) - 1
        ltf = self._prepare(ltf_ohlcv).tail(self.ltf_lookback_bars).reset_index(drop=True)
        htf = self._prepare(htf_ohlcv).tail(self.htf_lookback_bars).reset_index(drop=True)
        if len(ltf) < max(4, self.atr_period) or len(htf) < 3:
            return []

        bias, bias_metadata = self._htf_bias(htf)
        if bias == "neutral":
            return []

        setup = self._latest_mitigated_fvg(ltf, bias)
        if setup is None:
            return []

        atr = self._atr(ltf)
        if atr is None or atr <= 0:
            return []

        entry_price = float(ltf.iloc[-1]["close"])
        if entry_price <= 0:
            return []

        buffer = self.atr_buffer_multiplier * atr
        if bias == "bullish":
            side = "long"
            stop_loss_price = setup.bottom - buffer
            risk = entry_price - stop_loss_price
            take_profit_price = entry_price + self.risk_reward * risk
            reason = "smc_bullish_bias_ltf_fvg_mitigation"
        else:
            side = "short"
            stop_loss_price = setup.top + buffer
            risk = stop_loss_price - entry_price
            take_profit_price = entry_price - self.risk_reward * risk
            reason = "smc_bearish_bias_ltf_fvg_mitigation"

        if min(entry_price, stop_loss_price, take_profit_price, risk) <= 0:
            return []

        quality = self._quality_metrics(entry_price, stop_loss_price, take_profit_price)
        if not self._passes_quality_filters(quality):
            return []

        score = self._score(setup, ltf)
        if score < self.min_score:
            return []

        if self._is_recent_duplicate(side, setup, current_bar_number):
            return []

        signal = Signal(
            timestamp=pd.Timestamp(ltf.iloc[-1]["timestamp"]).to_pydatetime(),
            symbol=self.symbol,
            timeframe=self.ltf_timeframe,
            side=side,  # type: ignore[arg-type]
            action="entry",
            entry_price=entry_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            reason=reason,
            score=score,
            strategy_name=self.name,
            htf=self.htf_timeframe,
            ltf=self.ltf_timeframe,
            metadata={
                "htf_bias": bias,
                "htf_bias_timestamp": bias_metadata.get("timestamp"),
                "fvg_timestamp": setup.timestamp.isoformat(),
                "fvg_bottom": setup.bottom,
                "fvg_top": setup.top,
                "fvg_index": setup.index,
                "fvg_mitigation_index": setup.mitigation_index,
                "atr": atr,
                "atr_buffer": buffer,
                "risk_pct": quality["risk_pct"],
                "target_pct": quality["target_pct"],
                "rr": quality["rr"],
                "reward_to_fee_ratio": quality["reward_to_fee_ratio"],
                "setup_timestamp": setup.timestamp.isoformat(),
                "smartmoneyconcepts_available": "_smc" in globals(),
            },
        )

        try:
            signal.validate_geometry()
        except ValueError:
            return []
        self._remember_setup(side, setup, current_bar_number)
        return [signal]

    @staticmethod
    def _prepare(ohlcv: pd.DataFrame) -> pd.DataFrame:
        required = ["timestamp", "open", "high", "low", "close", "volume"]
        missing = [column for column in required if column not in ohlcv.columns]
        if missing:
            raise ValueError(f"Missing OHLCV columns: {missing}")

        df = ohlcv[required].copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        for column in required[1:]:
            df[column] = pd.to_numeric(df[column], errors="coerce")
        df = df.dropna(subset=required).drop_duplicates("timestamp").sort_values("timestamp")
        return df.reset_index(drop=True)

    def _htf_bias(self, htf: pd.DataFrame) -> tuple[Bias, dict[str, Any]]:
        recent = htf.tail(self.structure_lookback).reset_index(drop=True)
        events: list[tuple[int, Bias]] = []
        for index in range(2, len(recent)):
            prior = recent.iloc[:index]
            close = float(recent.iloc[index]["close"])
            if close > float(prior["high"].max()):
                events.append((index, "bullish"))
            elif close < float(prior["low"].min()):
                events.append((index, "bearish"))

        if not events:
            return "neutral", {}

        index, bias = events[-1]
        return bias, {"timestamp": pd.Timestamp(recent.iloc[index]["timestamp"]).isoformat(), "index": index}

    def _latest_mitigated_fvg(self, ltf: pd.DataFrame, bias: Bias) -> _FVGSetup | None:
        setups = self._manual_fvgs(ltf, bias)
        last_index = len(ltf) - 1
        current_candle = ltf.iloc[last_index]
        for setup in reversed(setups[-self.fvg_lookback :]):
            if self._candle_mitigates_setup(current_candle, setup):
                earlier = self._first_mitigation_index(ltf.iloc[:last_index], setup)
                if earlier is not None:
                    continue
                return _FVGSetup(
                    direction=setup.direction,
                    index=setup.index,
                    timestamp=setup.timestamp,
                    bottom=setup.bottom,
                    top=setup.top,
                    mitigation_index=last_index,
                )
        return None

    @staticmethod
    def _manual_fvgs(ltf: pd.DataFrame, bias: Bias) -> list[_FVGSetup]:
        setups: list[_FVGSetup] = []
        for index in range(2, len(ltf) - 1):
            first = ltf.iloc[index - 2]
            third = ltf.iloc[index]
            first_high = float(first["high"])
            first_low = float(first["low"])
            third_high = float(third["high"])
            third_low = float(third["low"])
            timestamp = pd.Timestamp(third["timestamp"])

            if bias == "bullish" and third_low > first_high:
                setups.append(
                    _FVGSetup(
                        direction="bullish",
                        index=index,
                        timestamp=timestamp,
                        bottom=first_high,
                        top=third_low,
                        mitigation_index=-1,
                    )
                )
            elif bias == "bearish" and third_high < first_low:
                setups.append(
                    _FVGSetup(
                        direction="bearish",
                        index=index,
                        timestamp=timestamp,
                        bottom=third_high,
                        top=first_low,
                        mitigation_index=-1,
                    )
                )
        return setups

    @staticmethod
    def _first_mitigation_index(ltf: pd.DataFrame, setup: _FVGSetup) -> int | None:
        for index in range(setup.index + 1, len(ltf)):
            if SMCStrategyV1._candle_mitigates_setup(ltf.iloc[index], setup):
                return index
        return None

    @staticmethod
    def _candle_mitigates_setup(candle: pd.Series, setup: _FVGSetup) -> bool:
        high = float(candle["high"])
        low = float(candle["low"])
        close = float(candle["close"])
        overlaps = low <= setup.top and high >= setup.bottom
        closes_inside = setup.bottom <= close <= setup.top
        return overlaps or closes_inside

    def _atr(self, ltf: pd.DataFrame) -> float | None:
        if len(ltf) < self.atr_period:
            return None
        high = ltf["high"]
        low = ltf["low"]
        previous_close = ltf["close"].shift(1)
        true_range = pd.concat(
            [
                high - low,
                (high - previous_close).abs(),
                (low - previous_close).abs(),
            ],
            axis=1,
        ).max(axis=1)
        value = true_range.tail(self.atr_period).mean()
        if pd.isna(value):
            return None
        return float(value)

    @staticmethod
    def _score(setup: _FVGSetup, ltf: pd.DataFrame) -> float:
        age = max(len(ltf) - 1 - setup.index, 0)
        recency_score = max(0.0, 20.0 - age)
        return 80.0 + recency_score

    def _quality_metrics(
        self,
        entry_price: float,
        stop_loss_price: float,
        take_profit_price: float,
    ) -> dict[str, float]:
        risk_pct = abs(entry_price - stop_loss_price) / entry_price
        target_pct = abs(take_profit_price - entry_price) / entry_price
        rr = target_pct / risk_pct if risk_pct else 0.0
        reward_to_fee_ratio = (
            target_pct / self.estimated_round_trip_cost_pct if self.estimated_round_trip_cost_pct > 0 else float("inf")
        )
        return {
            "risk_pct": risk_pct,
            "target_pct": target_pct,
            "rr": rr,
            "reward_to_fee_ratio": reward_to_fee_ratio,
        }

    def _passes_quality_filters(self, quality: dict[str, float]) -> bool:
        return (
            quality["risk_pct"] >= self.min_risk_pct
            and quality["target_pct"] >= self.min_target_pct
            and quality["rr"] >= self.min_rr
            and quality["reward_to_fee_ratio"] >= self.min_reward_to_fee_ratio
        )

    def _is_recent_duplicate(self, side: str, setup: _FVGSetup, current_bar_number: int) -> bool:
        if self._last_emitted_setup is None:
            return False
        last_side, last_top, last_bottom, last_bar = self._last_emitted_setup
        same_zone = last_side == side and last_top == round(setup.top, 8) and last_bottom == round(setup.bottom, 8)
        return same_zone and (current_bar_number - last_bar) <= self.setup_cooldown_bars

    def _remember_setup(self, side: str, setup: _FVGSetup, current_bar_number: int) -> None:
        object.__setattr__(
            self,
            "_last_emitted_setup",
            (side, round(setup.top, 8), round(setup.bottom, 8), current_bar_number),
        )


@dataclass(frozen=True)
class SMCStrategyV2(SMCStrategyV1):
    """Stricter SMC strategy with killzone, sweep, and CHOCH filters."""

    use_killzone_filter: bool = True
    killzones_utc: list[dict[str, str]] = field(
        default_factory=lambda: [
            {"name": "london", "start": "07:00", "end": "10:00"},
            {"name": "new_york", "start": "13:30", "end": "16:30"},
        ]
    )
    require_liquidity_sweep: bool = True
    sweep_lookback_bars: int = 20
    require_ltf_choch: bool = True
    choch_lookback_bars: int = 20
    avoid_weekends: bool = False
    long_only: bool = False
    short_only: bool = False
    blocked_entry_hours_utc: list[int] = field(default_factory=list)
    block_new_york_shorts: bool = False
    allowed_killzones: list[str] | None = None
    blocked_killzones: list[str] | None = None
    max_risk_pct: float | None = None

    def __post_init__(self) -> None:
        if self.long_only and self.short_only:
            raise ValueError("long_only and short_only cannot both be true")

    @property
    def name(self) -> str:
        return "smc_v2"

    def generate_signals(self, ltf_ohlcv: pd.DataFrame, htf_ohlcv: pd.DataFrame) -> list[Signal]:
        current_bar_number = len(ltf_ohlcv) - 1
        ltf = self._prepare(ltf_ohlcv).tail(self.ltf_lookback_bars).reset_index(drop=True)
        htf = self._prepare(htf_ohlcv).tail(self.htf_lookback_bars).reset_index(drop=True)
        if len(ltf) < max(4, self.atr_period) or len(htf) < 3:
            return []

        current_timestamp = pd.Timestamp(ltf.iloc[-1]["timestamp"])
        killzone_name = self._killzone_for_timestamp(current_timestamp)
        passed_killzone = not self.use_killzone_filter or killzone_name is not None
        if not passed_killzone:
            return []

        bias, bias_metadata = self._htf_bias(htf)
        if bias == "neutral":
            return []

        passed_sweep, sweep_level = self._liquidity_sweep(ltf, bias)
        if self.require_liquidity_sweep and not passed_sweep:
            return []

        passed_choch, choch_level = self._choch_confirmation(ltf, bias)
        if self.require_ltf_choch and not passed_choch:
            return []

        setup = self._latest_mitigated_fvg(ltf, bias)
        if setup is None:
            return []

        atr = self._atr(ltf)
        if atr is None or atr <= 0:
            return []

        entry_price = float(ltf.iloc[-1]["close"])
        if entry_price <= 0:
            return []

        buffer = self.atr_buffer_multiplier * atr
        if bias == "bullish":
            side = "long"
            stop_loss_price = setup.bottom - buffer
            risk = entry_price - stop_loss_price
            take_profit_price = entry_price + self.risk_reward * risk
            reason = "smc_v2_bullish_bias_ltf_fvg_mitigation"
        else:
            side = "short"
            stop_loss_price = setup.top + buffer
            risk = stop_loss_price - entry_price
            take_profit_price = entry_price - self.risk_reward * risk
            reason = "smc_v2_bearish_bias_ltf_fvg_mitigation"

        if not self._passes_experiment_switches(side, current_timestamp, killzone_name):
            return []

        if min(entry_price, stop_loss_price, take_profit_price, risk) <= 0:
            return []

        quality = self._quality_metrics(entry_price, stop_loss_price, take_profit_price)
        if not self._passes_quality_filters(quality):
            return []
        if self.max_risk_pct is not None and quality["risk_pct"] > self.max_risk_pct:
            return []

        score = self._score(setup, ltf)
        if score < self.min_score:
            return []

        if self._is_recent_duplicate(side, setup, current_bar_number):
            return []

        signal = Signal(
            timestamp=current_timestamp.to_pydatetime(),
            symbol=self.symbol,
            timeframe=self.ltf_timeframe,
            side=side,  # type: ignore[arg-type]
            action="entry",
            entry_price=entry_price,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            reason=reason,
            score=score,
            strategy_name=self.name,
            htf=self.htf_timeframe,
            ltf=self.ltf_timeframe,
            metadata={
                "strategy_version": "smc_v2",
                "htf_bias": bias,
                "htf_bias_timestamp": bias_metadata.get("timestamp"),
                "fvg_timestamp": setup.timestamp.isoformat(),
                "fvg_bottom": setup.bottom,
                "fvg_top": setup.top,
                "fvg_index": setup.index,
                "fvg_mitigation_index": setup.mitigation_index,
                "atr": atr,
                "atr_buffer": buffer,
                "risk_pct": quality["risk_pct"],
                "target_pct": quality["target_pct"],
                "rr": quality["rr"],
                "reward_to_fee_ratio": quality["reward_to_fee_ratio"],
                "setup_timestamp": setup.timestamp.isoformat(),
                "killzone_name": killzone_name,
                "passed_killzone": passed_killzone,
                "passed_liquidity_sweep": passed_sweep,
                "passed_choch": passed_choch,
                "sweep_level": sweep_level,
                "choch_level": choch_level,
                "experiment_long_only": self.long_only,
                "experiment_short_only": self.short_only,
                "experiment_blocked_hours": list(self.blocked_entry_hours_utc),
                "experiment_block_new_york_shorts": self.block_new_york_shorts,
                "experiment_allowed_killzones": self.allowed_killzones,
                "experiment_blocked_killzones": self.blocked_killzones,
                "experiment_max_risk_pct": self.max_risk_pct,
                "smartmoneyconcepts_available": "_smc" in globals(),
            },
        )

        try:
            signal.validate_geometry()
        except ValueError:
            return []
        self._remember_setup(side, setup, current_bar_number)
        return [signal]

    def _passes_experiment_switches(
        self,
        side: str,
        timestamp: pd.Timestamp,
        killzone_name: str | None,
    ) -> bool:
        timestamp = pd.Timestamp(timestamp)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        else:
            timestamp = timestamp.tz_convert("UTC")

        if side == "short" and self.long_only:
            return False
        if side == "long" and self.short_only:
            return False
        blocked_hours = set(int(hour) for hour in self.blocked_entry_hours_utc)
        expected_entry_timestamp = timestamp + self._timeframe_delta(self.ltf_timeframe)
        if int(timestamp.hour) in blocked_hours or int(expected_entry_timestamp.hour) in blocked_hours:
            return False
        if self.allowed_killzones is not None:
            allowed = {str(name) for name in self.allowed_killzones}
            if killzone_name not in allowed:
                return False
        if self.blocked_killzones is not None:
            blocked = {str(name) for name in self.blocked_killzones}
            if killzone_name in blocked:
                return False
        if side == "short" and self.block_new_york_shorts and killzone_name == "new_york":
            return False
        return True

    @staticmethod
    def _timeframe_delta(timeframe: str) -> pd.Timedelta:
        value = str(timeframe).strip().lower()
        match = re.fullmatch(r"(\d+)(m|min|h|d)", value)
        if match is None:
            return pd.Timedelta(0)

        amount = int(match.group(1))
        unit = match.group(2)
        if unit in {"m", "min"}:
            return pd.Timedelta(minutes=amount)
        if unit == "h":
            return pd.Timedelta(hours=amount)
        return pd.Timedelta(days=amount)

    def _killzone_for_timestamp(self, timestamp: pd.Timestamp) -> str | None:
        timestamp = pd.Timestamp(timestamp)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        else:
            timestamp = timestamp.tz_convert("UTC")

        if self.avoid_weekends and timestamp.weekday() >= 5:
            return None

        current_time = timestamp.time().replace(second=0, microsecond=0)
        for zone in self.killzones_utc:
            start = self._parse_session_time(str(zone["start"]))
            end = self._parse_session_time(str(zone["end"]))
            if self._time_in_range(current_time, start, end):
                return str(zone.get("name", "killzone"))
        return None

    @staticmethod
    def _parse_session_time(value: str) -> time:
        hour, minute = value.split(":", 1)
        return time(hour=int(hour), minute=int(minute))

    @staticmethod
    def _time_in_range(current: time, start: time, end: time) -> bool:
        if start <= end:
            return start <= current < end
        return current >= start or current < end

    def _liquidity_sweep(self, ltf: pd.DataFrame, bias: Bias) -> tuple[bool, float | None]:
        window = ltf.tail(max(self.sweep_lookback_bars + 1, 3)).reset_index(drop=True)
        if len(window) < 3:
            return False, None

        current_close = float(window.iloc[-1]["close"])
        if bias == "bullish":
            for index in range(len(window) - 1, 0, -1):
                prior = window.iloc[:index]
                if len(prior) < 2:
                    continue
                swept_level = float(prior["low"].min())
                if float(window.iloc[index]["low"]) < swept_level and current_close > swept_level:
                    return True, swept_level
        elif bias == "bearish":
            for index in range(len(window) - 1, 0, -1):
                prior = window.iloc[:index]
                if len(prior) < 2:
                    continue
                swept_level = float(prior["high"].max())
                if float(window.iloc[index]["high"]) > swept_level and current_close < swept_level:
                    return True, swept_level
        return False, None

    def _choch_confirmation(self, ltf: pd.DataFrame, bias: Bias) -> tuple[bool, float | None]:
        window = ltf.tail(max(self.choch_lookback_bars + 1, 3)).reset_index(drop=True)
        if len(window) < 3:
            return False, None

        if bias == "bullish":
            for index in range(len(window) - 1, 1, -1):
                prior = window.iloc[:index]
                choch_level = float(prior["high"].max())
                if float(window.iloc[index]["close"]) > choch_level:
                    return True, choch_level
        elif bias == "bearish":
            for index in range(len(window) - 1, 1, -1):
                prior = window.iloc[:index]
                choch_level = float(prior["low"].min())
                if float(window.iloc[index]["close"]) < choch_level:
                    return True, choch_level
        return False, None
