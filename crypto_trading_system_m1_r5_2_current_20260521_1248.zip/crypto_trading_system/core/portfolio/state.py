"""
Portfolio state: balance, day boundary tracking, daily PnL, signal dedup cache.

Persisted to JSON for resumability. On startup, live mode should call
reconcile_with_exchange() to overwrite local state with the exchange's view —
local file is a cache, exchange is source of truth.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, date
from pathlib import Path
from typing import Any


def _today_utc() -> str:
    return datetime.now(timezone.utc).date().isoformat()


@dataclass
class PortfolioState:
    initial_balance: float
    balance: float
    day: str = field(default_factory=_today_utc)
    day_start_balance: float = 0.0
    daily_realized_pnl: float = 0.0
    closed_trades: int = 0
    seen_signals: list[str] = field(default_factory=list)
    last_entry_time_by_symbol: dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if self.day_start_balance == 0.0:
            self.day_start_balance = self.balance

    # ------------------------------------------------------ day boundary

    def roll_day_if_needed(self) -> bool:
        """Reset daily counters if a new UTC day has begun. Returns True if rolled."""
        today = _today_utc()
        if self.day == today:
            return False
        self.day = today
        self.day_start_balance = self.balance
        self.daily_realized_pnl = 0.0
        # Keep seen_signals (don't reset — duplicate signals across midnight still bad)
        return True

    # ------------------------------------------------------- risk helpers

    def daily_loss_used_usdt(self) -> float:
        return max(0.0, -self.daily_realized_pnl)

    def max_daily_loss_usdt(self, pct: float) -> float:
        return self.day_start_balance * pct

    # ------------------------------------------------------ signal dedup

    def remember_signal(self, key: str, cap: int = 1000) -> None:
        self.seen_signals.append(key)
        if len(self.seen_signals) > cap:
            self.seen_signals = self.seen_signals[-cap:]

    def has_seen_signal(self, key: str) -> bool:
        return key in self.seen_signals

    # --------------------------------------------------------- realized PnL

    def apply_realized_pnl(self, net_pnl: float) -> None:
        self.balance += net_pnl
        self.daily_realized_pnl += net_pnl
        self.closed_trades += 1

    # ------------------------------------------------------ persistence

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PortfolioState":
        return cls(**d)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Atomic write — avoid corrupt JSON if killed mid-write
        tmp = path.with_suffix(path.suffix + ".tmp")
        with open(tmp, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
        tmp.replace(path)

    @classmethod
    def load_or_create(cls, path: str | Path, initial_balance: float) -> "PortfolioState":
        path = Path(path)
        if path.exists():
            with open(path, "r") as f:
                state = cls.from_dict(json.load(f))
            state.roll_day_if_needed()
            return state
        state = cls(initial_balance=initial_balance, balance=initial_balance)
        state.save(path)
        return state
