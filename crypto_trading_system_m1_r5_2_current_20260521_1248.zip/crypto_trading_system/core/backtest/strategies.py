"""Baseline backtest strategies."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class EMACrossoverStrategy:
    """Long-only EMA crossover strategy used to validate the backtest flow."""

    fast_ema: int = 20
    slow_ema: int = 50

    def __post_init__(self) -> None:
        if self.fast_ema <= 0 or self.slow_ema <= 0:
            raise ValueError("EMA periods must be positive")
        if self.fast_ema >= self.slow_ema:
            raise ValueError("fast_ema must be smaller than slow_ema")

    @property
    def name(self) -> str:
        return f"ema_cross_{self.fast_ema}_{self.slow_ema}"

    def generate_signals(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        """Return OHLCV data with EMA columns and crossover signals.

        Signals are generated on candle close and are intended to be executed by
        the engine on the next candle open.
        """

        required_columns = {"timestamp", "open", "high", "low", "close", "volume"}
        missing = required_columns.difference(ohlcv.columns)
        if missing:
            raise ValueError(f"Missing OHLCV columns: {sorted(missing)}")

        df = ohlcv.copy()
        df["fast_ema"] = df["close"].ewm(
            span=self.fast_ema,
            adjust=False,
            min_periods=self.fast_ema,
        ).mean()
        df["slow_ema"] = df["close"].ewm(
            span=self.slow_ema,
            adjust=False,
            min_periods=self.slow_ema,
        ).mean()

        prev_fast = df["fast_ema"].shift(1)
        prev_slow = df["slow_ema"].shift(1)
        has_history = df["fast_ema"].notna() & df["slow_ema"].notna() & prev_fast.notna() & prev_slow.notna()

        crosses_above = has_history & (prev_fast <= prev_slow) & (df["fast_ema"] > df["slow_ema"])
        crosses_below = has_history & (prev_fast >= prev_slow) & (df["fast_ema"] < df["slow_ema"])

        df["signal"] = ""
        df["signal_reason"] = ""
        df.loc[crosses_above, "signal"] = "long_entry"
        df.loc[crosses_above, "signal_reason"] = "fast_ema_cross_above_slow_ema"
        df.loc[crosses_below, "signal"] = "long_exit"
        df.loc[crosses_below, "signal_reason"] = "fast_ema_cross_below_slow_ema"

        return df

