"""Offline public-data backtest engine."""

from __future__ import annotations

import json
import inspect
from collections.abc import Iterable
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Protocol

import pandas as pd

from core.data.multitimeframe import closed_higher_timeframe_slice, infer_timeframe_delta, timeframe_to_timedelta
from core.strategy.signal import Signal


SIGNAL_METADATA_COLUMNS = [
    "strategy_version",
    "killzone_name",
    "passed_killzone",
    "passed_liquidity_sweep",
    "passed_choch",
    "sweep_level",
    "choch_level",
    "risk_pct",
    "target_pct",
    "rr",
    "reward_to_fee_ratio",
]


class Strategy(Protocol):
    def generate_signals(self, ohlcv: pd.DataFrame) -> Any:
        ...


@dataclass(frozen=True)
class BacktestConfig:
    symbol: str
    timeframe: str
    start: str
    end: str
    initial_equity: float = 10_000.0
    fee_rate: float = 0.0005
    slippage_bps: float = 2.0
    position_size_pct: float = 1.0
    leverage: float = 10.0
    max_margin_pct: float = 0.20
    stop_loss_pct_on_margin: float | None = 0.30
    take_profit_pct_on_margin: float | None = None
    max_account_drawdown_pct: float = 0.30
    max_daily_loss_pct: float = 0.05
    max_consecutive_losses: int = 5
    cooldown_bars_after_loss_streak: int = 20
    liquidation_check_enabled: bool = True
    maintenance_margin_pct: float = 0.005
    use_smc_filter: bool = False
    smc_features_path: str | None = None
    smc_lookback_bars: int = 20
    require_bullish_bos: bool = False
    allow_short: bool = False
    output_dir: str | Path = "logs"

    def __post_init__(self) -> None:
        if self.initial_equity <= 0:
            raise ValueError("initial_equity must be positive")
        if self.fee_rate < 0:
            raise ValueError("fee_rate cannot be negative")
        if self.slippage_bps < 0:
            raise ValueError("slippage_bps cannot be negative")
        if not 0 < self.position_size_pct <= 1:
            raise ValueError("position_size_pct must be in the interval (0, 1]")
        if self.leverage <= 0:
            raise ValueError("leverage must be positive")
        if not 0 < self.max_margin_pct <= 1:
            raise ValueError("max_margin_pct must be in the interval (0, 1]")
        if self.stop_loss_pct_on_margin is not None and self.stop_loss_pct_on_margin <= 0:
            raise ValueError("stop_loss_pct_on_margin must be positive or None")
        if self.take_profit_pct_on_margin is not None and self.take_profit_pct_on_margin <= 0:
            raise ValueError("take_profit_pct_on_margin must be positive or None")
        if not 0 < self.max_account_drawdown_pct <= 1:
            raise ValueError("max_account_drawdown_pct must be in the interval (0, 1]")
        if not 0 < self.max_daily_loss_pct <= 1:
            raise ValueError("max_daily_loss_pct must be in the interval (0, 1]")
        if self.max_consecutive_losses <= 0:
            raise ValueError("max_consecutive_losses must be positive")
        if self.cooldown_bars_after_loss_streak < 0:
            raise ValueError("cooldown_bars_after_loss_streak cannot be negative")
        if self.maintenance_margin_pct < 0:
            raise ValueError("maintenance_margin_pct cannot be negative")
        if self.smc_lookback_bars < 1:
            raise ValueError("smc_lookback_bars must be positive")


@dataclass
class Trade:
    trade_id: int
    symbol: str
    timeframe: str
    side: str
    entry_time: str
    exit_time: str
    entry_price: float
    exit_price: float
    quantity: float
    notional: float
    leverage: float
    margin_used: float
    margin_pct_of_equity: float
    position_notional: float
    position_notional_pct_of_equity: float
    entry_notional: float
    exit_notional: float
    entry_fee: float
    exit_fee: float
    total_fee: float
    gross_pnl: float
    net_pnl: float
    pnl_pct: float
    pnl_pct_on_margin: float
    pnl_pct_on_equity: float
    equity_before: float
    equity_after: float
    stop_loss_price: float | None
    take_profit_price: float | None
    signal_score: float | None
    strategy_version: str | None
    killzone_name: str | None
    passed_killzone: bool | None
    passed_liquidity_sweep: bool | None
    passed_choch: bool | None
    sweep_level: float | None
    choch_level: float | None
    risk_pct: float | None
    target_pct: float | None
    rr: float | None
    reward_to_fee_ratio: float | None
    entry_reason: str
    exit_reason: str
    bars_held: int


@dataclass
class BacktestResult:
    config: BacktestConfig
    trades: list[Trade]
    equity_curve: pd.DataFrame
    summary: dict[str, Any]
    summary_path: Path
    trades_path: Path
    equity_curve_path: Path
    skipped_signals_path: Path


@dataclass
class _OpenPosition:
    trade_id: int
    side: str
    entry_time: pd.Timestamp
    entry_price: float
    quantity: float
    notional: float
    leverage: float
    margin_used: float
    margin_pct_of_equity: float
    position_notional: float
    position_notional_pct_of_equity: float
    entry_fee: float
    equity_before: float
    entry_reason: str
    entry_index: int
    stop_loss_price: float | None = None
    take_profit_price: float | None = None
    signal_score: float | None = None
    strategy_version: str | None = None
    killzone_name: str | None = None
    passed_killzone: bool | None = None
    passed_liquidity_sweep: bool | None = None
    passed_choch: bool | None = None
    sweep_level: float | None = None
    choch_level: float | None = None
    risk_pct: float | None = None
    target_pct: float | None = None
    rr: float | None = None
    reward_to_fee_ratio: float | None = None


class BacktestEngine:
    """Executes long-only signals against OHLCV data without live trading."""

    def __init__(self, config: BacktestConfig) -> None:
        self.config = config
        self.output_dir = Path(config.output_dir)
        self._smc_features = self._load_smc_features()

    def run(
        self,
        ohlcv: pd.DataFrame,
        strategy: Strategy,
        htf_ohlcv: pd.DataFrame | None = None,
        htf_timeframe: str | None = None,
    ) -> BacktestResult:
        data = self._prepare_ohlcv(ohlcv)
        if data.empty:
            raise ValueError("No OHLCV data available for backtest")

        signals = self._generate_signals(data, strategy, htf_ohlcv=htf_ohlcv, htf_timeframe=htf_timeframe)

        cash = float(self.config.initial_equity)
        open_position: _OpenPosition | None = None
        trades: list[Trade] = []
        curve_rows: list[dict[str, float | str]] = []
        trade_id = 1
        peak_equity = float(self.config.initial_equity)
        account_drawdown_locked = False
        consecutive_losses = 0
        cooldown_until_index = -1
        skipped_signal_reasons = {
            "max_account_drawdown": 0,
            "max_daily_loss": 0,
            "cooldown_after_loss_streak": 0,
            "insufficient_cash": 0,
            "short_not_allowed": 0,
            "smc_filter_no_bullish_bos": 0,
        }
        skipped_signal_rows: list[dict[str, float | int | str]] = []
        current_day: pd.Timestamp | None = None
        day_start_equity = float(self.config.initial_equity)
        daily_realized_pnl = 0.0

        for index, row in signals.iterrows():
            row_time = pd.Timestamp(row["timestamp"])
            row_day = row_time.floor("D")
            if current_day is None or row_day != current_day:
                current_day = row_day
                day_start_equity = self._equity(cash, open_position, float(row["open"]))
                daily_realized_pnl = 0.0

            risk_exited_this_bar = False
            if index > 0:
                prior_signal = str(signals.iloc[index - 1].get("signal", ""))
                prior_reason = str(signals.iloc[index - 1].get("signal_reason", ""))

                if open_position is not None:
                    risk_exit = self._risk_exit(row, open_position)
                    if risk_exit is not None:
                        exit_reason, execution_price = risk_exit
                        trade, cash = self._exit_position(
                            row=row,
                            position=open_position,
                            cash=cash,
                            exit_reason=exit_reason,
                            exit_index=index,
                            use_close_price=False,
                            execution_price=execution_price,
                        )
                        trades.append(trade)
                        daily_realized_pnl += trade.net_pnl
                        consecutive_losses, cooldown_until_index = self._update_loss_streak(
                            trade=trade,
                            consecutive_losses=consecutive_losses,
                            cooldown_until_index=cooldown_until_index,
                            exit_index=index,
                        )
                        open_position = None
                        risk_exited_this_bar = True

                if (
                    prior_signal in ("long_exit", "short_exit")
                    and open_position is not None
                    and prior_signal.startswith(open_position.side)
                ):
                    trade, cash = self._exit_position(
                        row=row,
                        position=open_position,
                        cash=cash,
                        exit_reason="ema_cross_exit",
                        exit_index=index,
                        use_close_price=False,
                    )
                    trades.append(trade)
                    daily_realized_pnl += trade.net_pnl
                    consecutive_losses, cooldown_until_index = self._update_loss_streak(
                        trade=trade,
                        consecutive_losses=consecutive_losses,
                        cooldown_until_index=cooldown_until_index,
                        exit_index=index,
                    )
                    open_position = None

                elif prior_signal in ("long_entry", "short_entry") and open_position is None and not risk_exited_this_bar:
                    side = prior_signal.split("_", 1)[0]
                    equity_before = self._equity(cash, open_position, float(row["open"]))
                    peak_equity = max(peak_equity, equity_before)
                    if peak_equity and (1.0 - equity_before / peak_equity) >= self.config.max_account_drawdown_pct:
                        account_drawdown_locked = True

                    skip_reason = self._entry_skip_reason(
                        index=index,
                        cash=cash,
                        equity_before=equity_before,
                        account_drawdown_locked=account_drawdown_locked,
                        daily_realized_pnl=daily_realized_pnl,
                        day_start_equity=day_start_equity,
                        cooldown_until_index=cooldown_until_index,
                        entry_time=row["timestamp"],
                        side=side,
                    )
                    if skip_reason is not None:
                        skipped_signal_reasons[skip_reason] += 1
                        skipped_signal_rows.append(
                            {
                                "timestamp": self._format_timestamp(row["timestamp"]),
                                "signal": prior_signal,
                                "reason": skip_reason,
                                "equity": equity_before,
                                "cash": cash,
                                "bar_index": index,
                            }
                        )
                    else:
                        open_position, cash = self._enter_position(
                            row=row,
                            trade_id=trade_id,
                            cash=cash,
                            equity_before=equity_before,
                            entry_reason=prior_reason or "long_entry",
                            entry_index=index,
                            side=side,
                            desired_entry_price=self._optional_float(signals.iloc[index - 1].get("signal_entry_price")),
                            stop_loss_price=self._optional_float(
                                signals.iloc[index - 1].get("signal_stop_loss_price")
                            ),
                            take_profit_price=self._optional_float(
                                signals.iloc[index - 1].get("signal_take_profit_price")
                            ),
                            signal_score=self._optional_float(signals.iloc[index - 1].get("signal_score")),
                            strategy_version=self._optional_str(signals.iloc[index - 1].get("strategy_version")),
                            killzone_name=self._optional_str(signals.iloc[index - 1].get("killzone_name")),
                            passed_killzone=self._optional_bool(signals.iloc[index - 1].get("passed_killzone")),
                            passed_liquidity_sweep=self._optional_bool(
                                signals.iloc[index - 1].get("passed_liquidity_sweep")
                            ),
                            passed_choch=self._optional_bool(signals.iloc[index - 1].get("passed_choch")),
                            sweep_level=self._optional_float(signals.iloc[index - 1].get("sweep_level")),
                            choch_level=self._optional_float(signals.iloc[index - 1].get("choch_level")),
                            risk_pct=self._optional_float(signals.iloc[index - 1].get("risk_pct")),
                            target_pct=self._optional_float(signals.iloc[index - 1].get("target_pct")),
                            rr=self._optional_float(signals.iloc[index - 1].get("rr")),
                            reward_to_fee_ratio=self._optional_float(
                                signals.iloc[index - 1].get("reward_to_fee_ratio")
                            ),
                        )
                        if open_position is not None:
                            trade_id += 1
                        else:
                            skipped_signal_reasons["insufficient_cash"] += 1
                            skipped_signal_rows.append(
                                {
                                    "timestamp": self._format_timestamp(row["timestamp"]),
                                    "signal": prior_signal,
                                    "reason": "insufficient_cash",
                                    "equity": equity_before,
                                    "cash": cash,
                                    "bar_index": index,
                                }
                            )

            mark_price = float(row["close"])
            equity = self._equity(cash, open_position, mark_price)
            peak_equity = max(peak_equity, equity)
            if peak_equity and (1.0 - equity / peak_equity) >= self.config.max_account_drawdown_pct:
                account_drawdown_locked = True
            drawdown_pct = (equity / peak_equity - 1.0) if peak_equity else 0.0
            curve_rows.append(
                {
                    "timestamp": self._format_timestamp(row["timestamp"]),
                    "equity": equity,
                    "cash": cash,
                    "position_qty": open_position.quantity if open_position else 0.0,
                    "position_market_value": (open_position.quantity * mark_price) if open_position else 0.0,
                    "unrealized_pnl": self._unrealized_pnl(open_position, mark_price),
                    "drawdown_pct": drawdown_pct,
                }
            )

        if open_position is not None:
            final_row = signals.iloc[-1]
            trade, cash = self._exit_position(
                row=final_row,
                position=open_position,
                cash=cash,
                exit_reason="end_of_data",
                exit_index=len(signals) - 1,
                use_close_price=True,
            )
            trades.append(trade)
            open_position = None

            final_equity = cash
            peak_equity = max(peak_equity, final_equity)
            curve_rows[-1].update(
                {
                    "equity": final_equity,
                    "cash": cash,
                    "position_qty": 0.0,
                    "position_market_value": 0.0,
                    "unrealized_pnl": 0.0,
                    "drawdown_pct": (final_equity / peak_equity - 1.0) if peak_equity else 0.0,
                }
            )

        equity_curve = pd.DataFrame(curve_rows)
        summary = self._build_summary(
            trades=trades,
            equity_curve=equity_curve,
            skipped_signal_reasons=skipped_signal_reasons,
        )
        summary_path, trades_path, equity_curve_path, skipped_signals_path = self._save_outputs(
            trades,
            equity_curve,
            summary,
            skipped_signal_rows,
        )

        return BacktestResult(
            config=self.config,
            trades=trades,
            equity_curve=equity_curve,
            summary=summary,
            summary_path=summary_path,
            trades_path=trades_path,
            equity_curve_path=equity_curve_path,
            skipped_signals_path=skipped_signals_path,
        )

    def _prepare_ohlcv(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        required = ["timestamp", "open", "high", "low", "close", "volume"]
        missing = [column for column in required if column not in ohlcv.columns]
        if missing:
            raise ValueError(f"Missing OHLCV columns: {missing}")

        df = ohlcv[required].copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        for column in required[1:]:
            df[column] = pd.to_numeric(df[column], errors="coerce")

        start = pd.to_datetime(self.config.start, utc=True)
        end = pd.to_datetime(self.config.end, utc=True)
        df = df[(df["timestamp"] >= start) & (df["timestamp"] < end)]

        valid = (
            df[required].notna().all(axis=1)
            & (df["open"] > 0)
            & (df["high"] > 0)
            & (df["low"] > 0)
            & (df["close"] > 0)
            & (df["high"] >= df["low"])
            & (df["volume"] >= 0)
        )
        df = df[valid].drop_duplicates("timestamp")
        return df.sort_values("timestamp").reset_index(drop=True)

    def _prepare_higher_timeframe_ohlcv(self, htf_ohlcv: pd.DataFrame) -> pd.DataFrame:
        required = ["timestamp", "open", "high", "low", "close", "volume"]
        missing = [column for column in required if column not in htf_ohlcv.columns]
        if missing:
            raise ValueError(f"Missing HTF OHLCV columns: {missing}")

        df = htf_ohlcv[required].copy()
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
        for column in required[1:]:
            df[column] = pd.to_numeric(df[column], errors="coerce")

        end = pd.to_datetime(self.config.end, utc=True)
        df = df[df["timestamp"] < end]

        valid = (
            df[required].notna().all(axis=1)
            & (df["open"] > 0)
            & (df["high"] > 0)
            & (df["low"] > 0)
            & (df["close"] > 0)
            & (df["high"] >= df["low"])
            & (df["volume"] >= 0)
        )
        df = df[valid].drop_duplicates("timestamp")
        return df.sort_values("timestamp").reset_index(drop=True)

    def _generate_signals(
        self,
        data: pd.DataFrame,
        strategy: Strategy,
        htf_ohlcv: pd.DataFrame | None,
        htf_timeframe: str | None,
    ) -> pd.DataFrame:
        if htf_ohlcv is None or not self._strategy_accepts_multitimeframe(strategy):
            return self._normalize_strategy_output(strategy.generate_signals(data), data)

        htf_data = self._prepare_higher_timeframe_ohlcv(htf_ohlcv)
        if htf_data.empty:
            raise ValueError("No higher-timeframe OHLCV data available for backtest")
        htf_delta = timeframe_to_timedelta(htf_timeframe) if htf_timeframe else infer_timeframe_delta(htf_data)

        rows: list[pd.Series] = []
        for index, row in data.iterrows():
            if len(data) >= 1000 and index > 0 and index % 1000 == 0:
                print(f"Signal progress: {index}/{len(data)} LTF candles...")
            ltf_slice = data.iloc[: index + 1].copy()
            htf_slice = closed_higher_timeframe_slice(
                htf_data,
                current_timestamp=row["timestamp"],
                timeframe_delta=htf_delta,
            )
            generated = self._normalize_strategy_output(  # type: ignore[misc]
                strategy.generate_signals(ltf_slice, htf_slice),
                ltf_slice,
            )
            signal_row = row.copy()
            if generated.empty:
                signal_row["signal"] = ""
                signal_row["signal_reason"] = ""
            else:
                for column, value in generated.iloc[-1].items():
                    signal_row[column] = value
            rows.append(signal_row)

        return self._ensure_signal_columns(pd.DataFrame(rows).reset_index(drop=True))

    def _normalize_strategy_output(self, output: Any, template: pd.DataFrame) -> pd.DataFrame:
        if isinstance(output, pd.DataFrame):
            return self._ensure_signal_columns(output)
        if isinstance(output, Signal):
            return self._signals_to_frame([output], template)
        if isinstance(output, Iterable) and not isinstance(output, (str, bytes, dict)):
            signals = list(output)
            if all(isinstance(signal, Signal) for signal in signals):
                return self._signals_to_frame(signals, template)
        raise TypeError("Strategy must return a pandas DataFrame, Signal, or iterable of Signal objects")

    def _signals_to_frame(self, signals: list[Signal], template: pd.DataFrame) -> pd.DataFrame:
        frame = self._ensure_signal_columns(template.copy())
        for column in [
            "signal_entry_price",
            "signal_stop_loss_price",
            "signal_take_profit_price",
            "signal_score",
            *SIGNAL_METADATA_COLUMNS,
        ]:
            if column not in frame.columns:
                frame[column] = None

        frame_timestamps = pd.to_datetime(frame["timestamp"], utc=True)
        for signal in signals:
            if signal.timestamp is None:
                continue
            signal_ts = pd.to_datetime(signal.timestamp, utc=True)
            matches = frame_timestamps[frame_timestamps == signal_ts]
            if matches.empty:
                continue
            self._apply_structured_signal(frame, matches.index[-1], signal)
        return frame

    @staticmethod
    def _apply_structured_signal(frame: pd.DataFrame, index: int, signal: Signal) -> None:
        if signal.side not in ("long", "short"):
            raise ValueError("Structured Signal.side must be 'long' or 'short'")
        if signal.action not in ("entry", "exit"):
            raise ValueError("Structured Signal.action must be 'entry' or 'exit'")

        frame.loc[index, "signal"] = f"{signal.side}_{signal.action}"
        frame.loc[index, "signal_reason"] = signal.reason or "; ".join(signal.reasons) or f"structured_{signal.action}"
        frame.loc[index, "signal_entry_price"] = signal.entry_price
        frame.loc[index, "signal_stop_loss_price"] = signal.stop_loss_price
        frame.loc[index, "signal_take_profit_price"] = signal.take_profit_price
        frame.loc[index, "signal_score"] = signal.score
        for column in SIGNAL_METADATA_COLUMNS:
            frame.loc[index, column] = signal.metadata.get(column)

    @staticmethod
    def _strategy_accepts_multitimeframe(strategy: Strategy) -> bool:
        try:
            signature = inspect.signature(strategy.generate_signals)
        except (TypeError, ValueError):
            return False

        parameters = list(signature.parameters.values())
        if any(parameter.kind == inspect.Parameter.VAR_POSITIONAL for parameter in parameters):
            return True

        positional = [
            parameter
            for parameter in parameters
            if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
        ]
        return len(positional) >= 2

    @staticmethod
    def _ensure_signal_columns(signals: pd.DataFrame) -> pd.DataFrame:
        signals = signals.copy()
        if "signal" not in signals.columns:
            signals["signal"] = ""
        if "signal_reason" not in signals.columns:
            signals["signal_reason"] = ""
        return signals

    def _entry_skip_reason(
        self,
        index: int,
        cash: float,
        equity_before: float,
        account_drawdown_locked: bool,
        daily_realized_pnl: float,
        day_start_equity: float,
        cooldown_until_index: int,
        entry_time: pd.Timestamp,
        side: str = "long",
    ) -> str | None:
        if account_drawdown_locked:
            return "max_account_drawdown"
        if daily_realized_pnl <= -(day_start_equity * self.config.max_daily_loss_pct):
            return "max_daily_loss"
        if index <= cooldown_until_index:
            return "cooldown_after_loss_streak"
        if side == "short" and not self.config.allow_short:
            return "short_not_allowed"

        target_margin = equity_before * self.config.max_margin_pct
        affordable_margin = cash / (1.0 + self.config.leverage * self.config.fee_rate)
        if min(target_margin, affordable_margin) <= 0:
            return "insufficient_cash"
        if side == "long" and not self._smc_entry_allowed(entry_time):
            return "smc_filter_no_bullish_bos"
        return None

    def _load_smc_features(self) -> pd.DataFrame | None:
        if not (self.config.use_smc_filter and self.config.require_bullish_bos):
            return None

        features_path = Path(self.config.smc_features_path or self.output_dir / "smc_features.csv")
        if not features_path.exists():
            raise FileNotFoundError(f"SMC features file not found: {features_path}")

        features = pd.read_csv(features_path)
        if "timestamp" not in features.columns:
            raise ValueError("SMC features file must contain timestamp")
        if "smc_bos_choch_bos_confirmed" not in features.columns:
            raise ValueError("SMC features file must contain smc_bos_choch_bos_confirmed")

        features = features.copy()
        features["timestamp"] = pd.to_datetime(features["timestamp"], utc=True)
        features["smc_bos_choch_bos_confirmed"] = pd.to_numeric(
            features["smc_bos_choch_bos_confirmed"],
            errors="coerce",
        )
        return features.sort_values("timestamp").reset_index(drop=True)

    def _smc_entry_allowed(self, entry_time: pd.Timestamp) -> bool:
        if not (self.config.use_smc_filter and self.config.require_bullish_bos):
            return True
        if self._smc_features is None:
            return False

        entry_ts = pd.Timestamp(entry_time).tz_convert("UTC")
        lookback = self._smc_features[self._smc_features["timestamp"] <= entry_ts].tail(self.config.smc_lookback_bars)
        return bool((lookback["smc_bos_choch_bos_confirmed"] == 1.0).any())

    def _update_loss_streak(
        self,
        trade: Trade,
        consecutive_losses: int,
        cooldown_until_index: int,
        exit_index: int,
    ) -> tuple[int, int]:
        if trade.net_pnl < 0:
            consecutive_losses += 1
            if consecutive_losses >= self.config.max_consecutive_losses:
                cooldown_until_index = max(
                    cooldown_until_index,
                    exit_index + self.config.cooldown_bars_after_loss_streak,
                )
        else:
            consecutive_losses = 0
        return consecutive_losses, cooldown_until_index

    def _risk_exit(self, row: pd.Series, position: _OpenPosition) -> tuple[str, float] | None:
        open_price = float(row["open"])
        high_price = float(row["high"])
        low_price = float(row["low"])

        explicit_exit = self._explicit_price_exit(open_price, high_price, low_price, position)
        if explicit_exit is not None:
            return explicit_exit

        loss_thresholds: list[tuple[str, float]] = []
        if self.config.stop_loss_pct_on_margin is not None:
            stop_distance = self.config.stop_loss_pct_on_margin * position.margin_used / position.quantity
            stop_price = position.entry_price - stop_distance if position.side == "long" else position.entry_price + stop_distance
            loss_thresholds.append(("stop_loss", stop_price))

        if self.config.liquidation_check_enabled:
            maintenance_margin = position.position_notional * self.config.maintenance_margin_pct
            if position.side == "long":
                liquidation_price = position.entry_price + (
                    (maintenance_margin - position.margin_used) / position.quantity
                )
            else:
                liquidation_price = position.entry_price + (
                    (position.margin_used - maintenance_margin) / position.quantity
                )
            loss_thresholds.append(("liquidation", liquidation_price))

        open_loss_hits = [
            (reason, price)
            for reason, price in loss_thresholds
            if (open_price <= price if position.side == "long" else open_price >= price)
        ]
        if open_loss_hits:
            reason, _ = (
                max(open_loss_hits, key=lambda item: item[1])
                if position.side == "long"
                else min(open_loss_hits, key=lambda item: item[1])
            )
            return reason, open_price

        intrabar_loss_hits = [
            (reason, price)
            for reason, price in loss_thresholds
            if (low_price <= price if position.side == "long" else high_price >= price)
        ]
        if intrabar_loss_hits:
            reason, execution_price = (
                max(intrabar_loss_hits, key=lambda item: item[1])
                if position.side == "long"
                else min(intrabar_loss_hits, key=lambda item: item[1])
            )
            return reason, execution_price

        if self.config.take_profit_pct_on_margin is not None:
            take_profit_distance = self.config.take_profit_pct_on_margin * position.margin_used / position.quantity
            take_profit_price = (
                position.entry_price + take_profit_distance
                if position.side == "long"
                else position.entry_price - take_profit_distance
            )
            if position.side == "long":
                if open_price >= take_profit_price:
                    return "take_profit", open_price
                if high_price >= take_profit_price:
                    return "take_profit", take_profit_price
            else:
                if open_price <= take_profit_price:
                    return "take_profit", open_price
                if low_price <= take_profit_price:
                    return "take_profit", take_profit_price

        return None

    @staticmethod
    def _explicit_price_exit(
        open_price: float,
        high_price: float,
        low_price: float,
        position: _OpenPosition,
    ) -> tuple[str, float] | None:
        if position.stop_loss_price is not None:
            if position.side == "long":
                if open_price <= position.stop_loss_price:
                    return "stop_loss", open_price
                if low_price <= position.stop_loss_price:
                    return "stop_loss", position.stop_loss_price
            else:
                if open_price >= position.stop_loss_price:
                    return "stop_loss", open_price
                if high_price >= position.stop_loss_price:
                    return "stop_loss", position.stop_loss_price

        if position.take_profit_price is not None:
            if position.side == "long":
                if open_price >= position.take_profit_price:
                    return "take_profit", open_price
                if high_price >= position.take_profit_price:
                    return "take_profit", position.take_profit_price
            else:
                if open_price <= position.take_profit_price:
                    return "take_profit", open_price
                if low_price <= position.take_profit_price:
                    return "take_profit", position.take_profit_price

        return None

    def _enter_position(
        self,
        row: pd.Series,
        trade_id: int,
        cash: float,
        equity_before: float,
        entry_reason: str,
        entry_index: int,
        side: str,
        desired_entry_price: float | None = None,
        stop_loss_price: float | None = None,
        take_profit_price: float | None = None,
        signal_score: float | None = None,
        strategy_version: str | None = None,
        killzone_name: str | None = None,
        passed_killzone: bool | None = None,
        passed_liquidity_sweep: bool | None = None,
        passed_choch: bool | None = None,
        sweep_level: float | None = None,
        choch_level: float | None = None,
        risk_pct: float | None = None,
        target_pct: float | None = None,
        rr: float | None = None,
        reward_to_fee_ratio: float | None = None,
    ) -> tuple[_OpenPosition | None, float]:
        if side not in ("long", "short"):
            raise ValueError(f"Unsupported position side: {side}")

        raw_entry_price = self._select_entry_price(row, desired_entry_price)
        entry_price = self._apply_slippage(raw_entry_price, side="buy" if side == "long" else "sell")
        target_margin = equity_before * self.config.max_margin_pct
        affordable_margin = cash / (1.0 + self.config.leverage * self.config.fee_rate)
        margin_used = min(target_margin, affordable_margin)
        if margin_used <= 0:
            return None, cash

        position_notional = margin_used * self.config.leverage
        quantity = position_notional / entry_price
        entry_fee = position_notional * self.config.fee_rate
        cash_after_entry = cash - margin_used - entry_fee
        if cash_after_entry < -1e-8:
            return None, cash

        margin_pct_of_equity = margin_used / equity_before if equity_before else 0.0
        position_notional_pct_of_equity = position_notional / equity_before if equity_before else 0.0
        position = _OpenPosition(
            trade_id=trade_id,
            side=side,
            entry_time=row["timestamp"],
            entry_price=entry_price,
            quantity=quantity,
            notional=position_notional,
            leverage=self.config.leverage,
            margin_used=margin_used,
            margin_pct_of_equity=margin_pct_of_equity,
            position_notional=position_notional,
            position_notional_pct_of_equity=position_notional_pct_of_equity,
            entry_fee=entry_fee,
            equity_before=equity_before,
            entry_reason=entry_reason,
            entry_index=entry_index,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            signal_score=signal_score,
            strategy_version=strategy_version,
            killzone_name=killzone_name,
            passed_killzone=passed_killzone,
            passed_liquidity_sweep=passed_liquidity_sweep,
            passed_choch=passed_choch,
            sweep_level=sweep_level,
            choch_level=choch_level,
            risk_pct=risk_pct,
            target_pct=target_pct,
            rr=rr,
            reward_to_fee_ratio=reward_to_fee_ratio,
        )
        return position, max(cash_after_entry, 0.0)

    @staticmethod
    def _select_entry_price(row: pd.Series, desired_entry_price: float | None) -> float:
        if desired_entry_price is not None and float(row["low"]) <= desired_entry_price <= float(row["high"]):
            return float(desired_entry_price)
        return float(row["open"])

    def _exit_position(
        self,
        row: pd.Series,
        position: _OpenPosition,
        cash: float,
        exit_reason: str,
        exit_index: int,
        use_close_price: bool,
        execution_price: float | None = None,
    ) -> tuple[Trade, float]:
        raw_price = float(execution_price if execution_price is not None else row["close"] if use_close_price else row["open"])
        exit_price = self._apply_slippage(raw_price, side="sell" if position.side == "long" else "buy")
        exit_notional = position.quantity * exit_price
        exit_fee = exit_notional * self.config.fee_rate

        if position.side == "long":
            gross_pnl = (exit_price - position.entry_price) * position.quantity
        else:
            gross_pnl = (position.entry_price - exit_price) * position.quantity
        raw_cash_after_exit = cash + position.margin_used + gross_pnl - exit_fee
        cash_after_exit = max(raw_cash_after_exit, 0.0)
        equity_after = cash_after_exit
        net_pnl = equity_after - position.equity_before
        total_fee = position.entry_fee + exit_fee
        pnl_pct = net_pnl / position.position_notional if position.position_notional else 0.0
        pnl_pct_on_margin = net_pnl / position.margin_used if position.margin_used else 0.0
        pnl_pct_on_equity = net_pnl / position.equity_before if position.equity_before else 0.0

        trade = Trade(
            trade_id=position.trade_id,
            symbol=self.config.symbol,
            timeframe=self.config.timeframe,
            side=position.side,
            entry_time=self._format_timestamp(position.entry_time),
            exit_time=self._format_timestamp(row["timestamp"]),
            entry_price=entry_price_round(position.entry_price),
            exit_price=entry_price_round(exit_price),
            quantity=position.quantity,
            notional=position.notional,
            leverage=position.leverage,
            margin_used=position.margin_used,
            margin_pct_of_equity=position.margin_pct_of_equity,
            position_notional=position.position_notional,
            position_notional_pct_of_equity=position.position_notional_pct_of_equity,
            entry_notional=position.position_notional,
            exit_notional=exit_notional,
            entry_fee=position.entry_fee,
            exit_fee=exit_fee,
            total_fee=total_fee,
            gross_pnl=gross_pnl,
            net_pnl=net_pnl,
            pnl_pct=pnl_pct,
            pnl_pct_on_margin=pnl_pct_on_margin,
            pnl_pct_on_equity=pnl_pct_on_equity,
            equity_before=position.equity_before,
            equity_after=equity_after,
            stop_loss_price=position.stop_loss_price,
            take_profit_price=position.take_profit_price,
            signal_score=position.signal_score,
            strategy_version=position.strategy_version,
            killzone_name=position.killzone_name,
            passed_killzone=position.passed_killzone,
            passed_liquidity_sweep=position.passed_liquidity_sweep,
            passed_choch=position.passed_choch,
            sweep_level=position.sweep_level,
            choch_level=position.choch_level,
            risk_pct=position.risk_pct,
            target_pct=position.target_pct,
            rr=position.rr,
            reward_to_fee_ratio=position.reward_to_fee_ratio,
            entry_reason=position.entry_reason,
            exit_reason=exit_reason,
            bars_held=max(exit_index - position.entry_index, 0),
        )
        return trade, cash_after_exit

    def _apply_slippage(self, price: float, side: str) -> float:
        slip = self.config.slippage_bps / 10_000.0
        if side == "buy":
            return price * (1.0 + slip)
        if side == "sell":
            return price * (1.0 - slip)
        raise ValueError(f"Unsupported side: {side}")

    @staticmethod
    def _equity(cash: float, position: _OpenPosition | None, mark_price: float) -> float:
        if position is None:
            return cash
        return cash + position.margin_used + BacktestEngine._unrealized_pnl(position, mark_price)

    @staticmethod
    def _unrealized_pnl(position: _OpenPosition | None, mark_price: float) -> float:
        if position is None:
            return 0.0
        if position.side == "long":
            return (mark_price - position.entry_price) * position.quantity
        return (position.entry_price - mark_price) * position.quantity

    def _build_summary(
        self,
        trades: list[Trade],
        equity_curve: pd.DataFrame,
        skipped_signal_reasons: dict[str, int],
    ) -> dict[str, Any]:
        final_equity = float(equity_curve["equity"].iloc[-1]) if not equity_curve.empty else self.config.initial_equity
        net_pnls = [trade.net_pnl for trade in trades]
        wins = [pnl for pnl in net_pnls if pnl > 0]
        losses = [pnl for pnl in net_pnls if pnl < 0]
        margin_values = [trade.margin_used for trade in trades]
        margin_pct_values = [trade.margin_pct_of_equity for trade in trades]
        notional_values = [trade.position_notional for trade in trades]
        notional_pct_values = [trade.position_notional_pct_of_equity for trade in trades]
        total_fees = float(sum(trade.total_fee for trade in trades))
        skipped_signals = int(sum(skipped_signal_reasons.values()))

        gross_profit = float(sum(wins))
        gross_loss = float(sum(losses))
        profit_factor = (gross_profit / abs(gross_loss)) if gross_loss < 0 else None
        total_trades = len(trades)

        peak = equity_curve["equity"].cummax()
        drawdown_amount = equity_curve["equity"] - peak
        max_drawdown = abs(float(drawdown_amount.min())) if not drawdown_amount.empty else 0.0
        max_drawdown_pct = abs(float(equity_curve["drawdown_pct"].min())) if not equity_curve.empty else 0.0

        return {
            "symbol": self.config.symbol,
            "timeframe": self.config.timeframe,
            "start": self.config.start,
            "end": self.config.end,
            "initial_equity": float(self.config.initial_equity),
            "final_equity": final_equity,
            "net_pnl": final_equity - float(self.config.initial_equity),
            "net_pnl_pct": (final_equity / float(self.config.initial_equity) - 1.0),
            "total_trades": total_trades,
            "winning_trades": len(wins),
            "losing_trades": len(losses),
            "win_rate": (len(wins) / total_trades) if total_trades else 0.0,
            "gross_profit": gross_profit,
            "gross_loss": gross_loss,
            "profit_factor": profit_factor,
            "average_win": (gross_profit / len(wins)) if wins else 0.0,
            "average_loss": (gross_loss / len(losses)) if losses else 0.0,
            "expectancy": (sum(net_pnls) / total_trades) if total_trades else 0.0,
            "max_drawdown": max_drawdown,
            "max_drawdown_pct": max_drawdown_pct,
            "average_bars_held": (
                sum(trade.bars_held for trade in trades) / total_trades if total_trades else 0.0
            ),
            "fee_rate": float(self.config.fee_rate),
            "slippage_bps": float(self.config.slippage_bps),
            "position_size_pct": float(self.config.position_size_pct),
            "leverage": float(self.config.leverage),
            "max_margin_pct": float(self.config.max_margin_pct),
            "allow_short": bool(self.config.allow_short),
            "long_trades": sum(1 for trade in trades if trade.side == "long"),
            "short_trades": sum(1 for trade in trades if trade.side == "short"),
            "stop_loss_exits": sum(1 for trade in trades if trade.exit_reason == "stop_loss"),
            "take_profit_exits": sum(1 for trade in trades if trade.exit_reason == "take_profit"),
            "liquidation_exits": sum(1 for trade in trades if trade.exit_reason == "liquidation"),
            "ema_cross_exits": sum(1 for trade in trades if trade.exit_reason == "ema_cross_exit"),
            "skipped_signals": skipped_signals,
            "skipped_signal_reasons": skipped_signal_reasons,
            "use_smc_filter": bool(self.config.use_smc_filter),
            "smc_lookback_bars": int(self.config.smc_lookback_bars),
            "require_bullish_bos": bool(self.config.require_bullish_bos),
            "smc_filter_skipped_signals": int(skipped_signal_reasons.get("smc_filter_no_bullish_bos", 0)),
            "max_account_drawdown_pct_limit": float(self.config.max_account_drawdown_pct),
            "max_daily_loss_pct_limit": float(self.config.max_daily_loss_pct),
            "max_consecutive_losses": int(self.config.max_consecutive_losses),
            "cooldown_bars_after_loss_streak": int(self.config.cooldown_bars_after_loss_streak),
            "average_margin_used": (sum(margin_values) / total_trades) if total_trades else 0.0,
            "max_margin_used": max(margin_values) if margin_values else 0.0,
            "average_margin_pct_of_equity": (sum(margin_pct_values) / total_trades) if total_trades else 0.0,
            "max_margin_pct_of_equity_used": max(margin_pct_values) if margin_pct_values else 0.0,
            "average_position_notional": (sum(notional_values) / total_trades) if total_trades else 0.0,
            "max_position_notional_used": max(notional_values) if notional_values else 0.0,
            "average_position_notional_pct_of_equity": (
                sum(notional_pct_values) / total_trades if total_trades else 0.0
            ),
            "max_position_notional_pct_of_equity_used": max(notional_pct_values) if notional_pct_values else 0.0,
            "total_fees": total_fees,
        }

    def _save_outputs(
        self,
        trades: list[Trade],
        equity_curve: pd.DataFrame,
        summary: dict[str, Any],
        skipped_signal_rows: list[dict[str, float | int | str]],
    ) -> tuple[Path, Path, Path, Path]:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        summary_path = self.output_dir / "backtest_summary.json"
        trades_path = self.output_dir / "backtest_trades.csv"
        equity_curve_path = self.output_dir / "backtest_equity_curve.csv"
        skipped_signals_path = self.output_dir / "backtest_skipped_signals.csv"

        summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")

        trade_columns = [field.name for field in fields(Trade)]
        trades_df = pd.DataFrame([asdict(trade) for trade in trades], columns=trade_columns)
        trades_df.to_csv(trades_path, index=False)

        equity_curve.to_csv(equity_curve_path, index=False)
        skipped_columns = ["timestamp", "signal", "reason", "equity", "cash", "bar_index"]
        skipped_df = pd.DataFrame(skipped_signal_rows, columns=skipped_columns)
        skipped_df.to_csv(skipped_signals_path, index=False)
        return summary_path, trades_path, equity_curve_path, skipped_signals_path

    @staticmethod
    def _format_timestamp(value: Any) -> str:
        return pd.Timestamp(value).tz_convert("UTC").isoformat()

    @staticmethod
    def _optional_float(value: Any) -> float | None:
        if value is None:
            return None
        if pd.isna(value):
            return None
        return float(value)

    @staticmethod
    def _optional_str(value: Any) -> str | None:
        if value is None:
            return None
        if pd.isna(value):
            return None
        return str(value)

    @staticmethod
    def _optional_bool(value: Any) -> bool | None:
        if value is None:
            return None
        if pd.isna(value):
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        return str(value).strip().lower() in {"1", "true", "yes"}


def entry_price_round(value: float) -> float:
    """Keep exported prices readable without changing portfolio math."""

    return round(float(value), 10)
