"""
Telegram alerting. Drop-in replacement for the inline send_telegram_message
that existed in the legacy bots, with:
  - rate-limit-safe queueing on errors (no fatal exits)
  - HTML escape helper
  - silent no-op if token/chat_id missing (dev-friendly)
"""
from __future__ import annotations

import html
from typing import Optional

import requests

from core.config import env
from core.monitoring.logger import get_logger

log = get_logger(__name__)


class TelegramClient:
    def __init__(
        self,
        token: Optional[str] = None,
        chat_id: Optional[str] = None,
        timeout: int = 15,
    ):
        self.token = token or env("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or env("TELEGRAM_CHAT_ID")
        self.timeout = timeout
        self.enabled = bool(self.token and self.chat_id)

        if not self.enabled:
            log.warning("telegram.disabled", reason="missing token or chat_id")

    def send(self, text: str, parse_mode: str = "HTML") -> bool:
        if not self.enabled:
            return False

        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": parse_mode,
            "disable_web_page_preview": True,
        }

        try:
            resp = requests.post(url, json=payload, timeout=self.timeout)
            if resp.status_code == 200:
                return True
            log.warning(
                "telegram.send_failed",
                status=resp.status_code,
                body=resp.text[:200],
            )
            return False
        except Exception as e:
            # Never crash the bot because Telegram is down.
            log.warning("telegram.send_error", error=type(e).__name__, message=str(e))
            return False

    @staticmethod
    def escape(text: str) -> str:
        return html.escape(text)
