"""
Structured logging. Console + rotating file.

Usage:
    from core.monitoring.logger import get_logger
    log = get_logger(__name__)
    log.info("position.opened", symbol="BTC/USDT:USDT", direction="LONG", entry=68000.0)
"""
from __future__ import annotations

import logging
import logging.handlers
import sys
from pathlib import Path

import structlog

from core.config import env, PROJECT_ROOT

_configured = False


def configure_logging() -> None:
    """Idempotent. Call once at program start (configure_logging() in main)."""
    global _configured
    if _configured:
        return

    level_name = (env("LOG_LEVEL") or "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    log_dir = Path(env("LOG_DIR") or "logs")
    if not log_dir.is_absolute():
        log_dir = PROJECT_ROOT / log_dir
    log_dir.mkdir(parents=True, exist_ok=True)

    # Stdlib root logger setup — both console and rotating file
    root = logging.getLogger()
    root.setLevel(level)
    # Clear any pre-existing handlers (re-runs in REPL etc.)
    root.handlers.clear()

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    root.addHandler(console)

    file_handler = logging.handlers.RotatingFileHandler(
        log_dir / "app.log",
        maxBytes=10 * 1024 * 1024,
        backupCount=10,
    )
    file_handler.setLevel(level)
    root.addHandler(file_handler)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.dev.ConsoleRenderer(colors=sys.stdout.isatty()),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    _configured = True


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    if not _configured:
        configure_logging()
    return structlog.get_logger(name)
