"""No-lookahead helpers for multi-timeframe feature alignment."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

import pandas as pd


TIMEFRAME_PATTERN = re.compile(r"^(?P<count>\d+)(?P<unit>[mhdw])$")


def timeframe_to_timedelta(timeframe: str) -> pd.Timedelta:
    """Convert common ccxt-style timeframes to a pandas Timedelta."""

    match = TIMEFRAME_PATTERN.match(timeframe.strip().lower())
    if not match:
        raise ValueError(f"Unsupported timeframe: {timeframe!r}")

    count = int(match.group("count"))
    unit = match.group("unit")
    if unit == "m":
        return pd.Timedelta(minutes=count)
    if unit == "h":
        return pd.Timedelta(hours=count)
    if unit == "d":
        return pd.Timedelta(days=count)
    if unit == "w":
        return pd.Timedelta(weeks=count)
    raise ValueError(f"Unsupported timeframe: {timeframe!r}")


def infer_timeframe_delta(ohlcv: pd.DataFrame) -> pd.Timedelta:
    """Infer candle spacing from sorted OHLCV timestamps."""

    if "timestamp" not in ohlcv.columns:
        raise ValueError("Dataframe must contain a timestamp column")

    timestamps = pd.to_datetime(ohlcv["timestamp"], utc=True).drop_duplicates().sort_values()
    deltas = timestamps.diff().dropna()
    deltas = deltas[deltas > pd.Timedelta(0)]
    if deltas.empty:
        raise ValueError("At least two timestamps are required to infer timeframe")
    return pd.Timedelta(deltas.value_counts().idxmax())


def closed_higher_timeframe_slice(
    higher_timeframe: pd.DataFrame,
    current_timestamp: pd.Timestamp | str,
    higher_timeframe_name: str | None = None,
    timeframe_delta: pd.Timedelta | None = None,
) -> pd.DataFrame:
    """Return HTF candles whose close time is <= the current LTF timestamp."""

    if "timestamp" not in higher_timeframe.columns:
        raise ValueError("Dataframe must contain a timestamp column")
    if timeframe_delta is None:
        timeframe_delta = (
            timeframe_to_timedelta(higher_timeframe_name)
            if higher_timeframe_name
            else infer_timeframe_delta(higher_timeframe)
        )

    current_ts = pd.to_datetime(current_timestamp, utc=True)
    htf = higher_timeframe.copy()
    htf["timestamp"] = pd.to_datetime(htf["timestamp"], utc=True)
    htf = htf.drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
    available_at = htf["timestamp"] + timeframe_delta
    return htf[available_at <= current_ts].copy().reset_index(drop=True)


def attach_confirmed_higher_timeframe(
    lower_timeframe: pd.DataFrame,
    higher_timeframe: pd.DataFrame,
    higher_timeframe_name: str,
    columns: Iterable[str] | None = None,
    prefix: str | None = None,
) -> pd.DataFrame:
    """Attach higher-timeframe columns only after each higher candle has closed.

    OHLCV timestamps are candle-open times. A higher-timeframe candle that opens
    at 10:00 on a 1h chart is therefore only available to lower-timeframe rows
    at or after 11:00.
    """

    if "timestamp" not in lower_timeframe.columns or "timestamp" not in higher_timeframe.columns:
        raise ValueError("Both dataframes must contain a timestamp column")

    selected_columns = list(columns) if columns is not None else [
        column for column in higher_timeframe.columns if column != "timestamp"
    ]
    missing = [column for column in selected_columns if column not in higher_timeframe.columns]
    if missing:
        raise ValueError(f"Missing higher-timeframe columns: {missing}")

    output_prefix = prefix if prefix is not None else f"htf_{higher_timeframe_name}_"
    candle_duration = timeframe_to_timedelta(higher_timeframe_name)

    lower = lower_timeframe.copy()
    lower["_original_order"] = range(len(lower))
    lower["timestamp"] = pd.to_datetime(lower["timestamp"], utc=True)
    lower = lower.sort_values("timestamp")

    higher = higher_timeframe[["timestamp", *selected_columns]].copy()
    higher["timestamp"] = pd.to_datetime(higher["timestamp"], utc=True)
    higher = higher.drop_duplicates("timestamp").sort_values("timestamp")
    higher[f"{output_prefix}timestamp"] = higher["timestamp"]
    higher[f"{output_prefix}available_at"] = higher["timestamp"] + candle_duration
    higher = higher.rename(columns={column: f"{output_prefix}{column}" for column in selected_columns})

    merged = pd.merge_asof(
        lower,
        higher.drop(columns=["timestamp"]).sort_values(f"{output_prefix}available_at"),
        left_on="timestamp",
        right_on=f"{output_prefix}available_at",
        direction="backward",
    )
    return merged.sort_values("_original_order").drop(columns=["_original_order"]).reset_index(drop=True)


def save_multitimeframe_frame(frame: pd.DataFrame, output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)
    return path
