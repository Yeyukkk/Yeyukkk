"""Local OHLCV CSV cache helpers."""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd


OHLCV_CACHE_DIR = Path("data/ohlcv")
OHLCV_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]


def safe_cache_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9.-]+", "-", str(value)).strip("-")
    return re.sub(r"-+", "-", token)


def ohlcv_cache_path(
    exchange: str,
    symbol: str,
    timeframe: str,
    start: str,
    end: str,
    cache_dir: str | Path = OHLCV_CACHE_DIR,
) -> Path:
    filename = "_".join(
        [
            safe_cache_token(exchange.lower()),
            safe_cache_token(symbol),
            safe_cache_token(timeframe),
            safe_cache_token(start),
            safe_cache_token(end),
        ]
    )
    return Path(cache_dir) / f"{filename}.csv"


def save_ohlcv_cache(ohlcv: pd.DataFrame, path: str | Path) -> Path:
    cache_path = Path(path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    df = ohlcv[OHLCV_COLUMNS].copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
    df.to_csv(cache_path, index=False)
    return cache_path


def load_ohlcv_cache(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    missing = [column for column in OHLCV_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(f"Missing OHLCV cache columns: {missing}")

    df = df[OHLCV_COLUMNS].copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    for column in OHLCV_COLUMNS[1:]:
        df[column] = pd.to_numeric(df[column], errors="coerce")
    df = df.dropna(subset=OHLCV_COLUMNS)
    df = df.drop_duplicates("timestamp").sort_values("timestamp").reset_index(drop=True)
    return df
