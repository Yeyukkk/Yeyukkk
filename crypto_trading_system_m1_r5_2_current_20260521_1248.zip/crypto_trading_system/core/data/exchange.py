"""Public market-data access for OKX.

This module deliberately uses only public ccxt endpoints. It does not require
API keys and does not expose account or order placement methods.
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

import ccxt
import pandas as pd


OHLCV_COLUMNS = ["timestamp", "open", "high", "low", "close", "volume"]


def _load_dotenv(path: str | Path = ".env") -> None:
    """Load simple KEY=VALUE lines from .env without adding a dependency."""

    env_path = Path(path)
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _utc_timestamp(value: str | pd.Timestamp) -> pd.Timestamp:
    ts = pd.to_datetime(value, utc=True)
    if pd.isna(ts):
        raise ValueError(f"Invalid timestamp: {value!r}")
    return ts


class OKXClient:
    """Thin public-data wrapper around ccxt's OKX exchange client."""

    def __init__(self, config: dict[str, Any] | None = None) -> None:
        _load_dotenv()
        config = config or {}

        exchange_options: dict[str, Any] = {
            "enableRateLimit": True,
            "options": {"defaultType": "spot"},
        }
        exchange_options.update(config.get("ccxt", {}))

        proxies = self._proxy_config(config)
        if proxies:
            exchange_options["proxies"] = proxies

        self.exchange = ccxt.okx(exchange_options)

    @staticmethod
    def _proxy_config(config: dict[str, Any]) -> dict[str, str]:
        configured = config.get("proxies") or {}
        http_proxy = configured.get("http") or os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
        https_proxy = configured.get("https") or os.getenv("HTTPS_PROXY") or os.getenv("https_proxy")

        proxies: dict[str, str] = {}
        if http_proxy:
            proxies["http"] = http_proxy
        if https_proxy:
            proxies["https"] = https_proxy
        return proxies

    def load_markets(self) -> dict[str, Any]:
        """Load public OKX market metadata."""

        return self.exchange.load_markets()

    def fetch_ticker(self, symbol: str) -> dict[str, Any]:
        """Fetch a public ticker snapshot."""

        return self.exchange.fetch_ticker(symbol)

    def fetch_ohlcv(
        self,
        symbol: str,
        timeframe: str = "1m",
        since: int | None = None,
        limit: int = 100,
    ) -> list[list[float]]:
        """Fetch one public OHLCV page from OKX."""

        return self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)

    def fetch_ohlcv_with_retry(
        self,
        symbol: str,
        timeframe: str = "1m",
        since: int | None = None,
        limit: int = 100,
        max_retries: int = 3,
    ) -> list[list[float]]:
        """Fetch one public OHLCV page with retry/backoff for transient limits."""

        backoffs = [2.0, 5.0, 10.0]
        attempt = 0
        while True:
            try:
                return self.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
            except (ccxt.RateLimitExceeded, ccxt.NetworkError) as exc:
                if attempt >= max_retries:
                    raise
                sleep_seconds = backoffs[min(attempt, len(backoffs) - 1)]
                attempt += 1
                print(
                    f"Warning: OKX public OHLCV fetch failed ({exc.__class__.__name__}); "
                    f"retry {attempt}/{max_retries} in {sleep_seconds:.0f}s..."
                )
                time.sleep(sleep_seconds)

    def fetch_ohlcv_history(
        self,
        symbol: str,
        timeframe: str,
        start: str | pd.Timestamp,
        end: str | pd.Timestamp,
        limit: int = 100,
    ) -> pd.DataFrame:
        """Fetch paginated public OHLCV history between UTC start and end.

        The returned DataFrame is sorted ascending, de-duplicated by candle open
        time, and filtered to the half-open interval [start, end). The method
        advances pagination by the timeframe duration, so it never reaches
        forward beyond the requested end timestamp.
        """

        if limit <= 0:
            raise ValueError("limit must be positive")

        start_ts = _utc_timestamp(start)
        end_ts = _utc_timestamp(end)
        if start_ts >= end_ts:
            raise ValueError("start must be before end")

        timeframe_ms = int(self.exchange.parse_timeframe(timeframe) * 1000)
        start_ms = int(start_ts.timestamp() * 1000)
        end_ms = int(end_ts.timestamp() * 1000)

        rows: list[list[float]] = []
        since = start_ms

        while since < end_ms:
            batch = self.fetch_ohlcv_with_retry(symbol, timeframe=timeframe, since=since, limit=limit)
            if not batch:
                break

            rows.extend(row for row in batch if start_ms <= int(row[0]) < end_ms)

            last_timestamp = int(batch[-1][0])
            next_since = last_timestamp + timeframe_ms
            if next_since <= since:
                break
            since = next_since

            if getattr(self.exchange, "rateLimit", None):
                time.sleep(float(self.exchange.rateLimit) / 1000.0)

        return self._format_ohlcv(rows, start_ts=start_ts, end_ts=end_ts)

    @staticmethod
    def _format_ohlcv(
        rows: list[list[float]],
        start_ts: pd.Timestamp | None = None,
        end_ts: pd.Timestamp | None = None,
    ) -> pd.DataFrame:
        if not rows:
            return pd.DataFrame(columns=OHLCV_COLUMNS)

        df = pd.DataFrame(rows, columns=OHLCV_COLUMNS)
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)

        for column in OHLCV_COLUMNS[1:]:
            df[column] = pd.to_numeric(df[column], errors="coerce")

        if start_ts is not None:
            df = df[df["timestamp"] >= start_ts]
        if end_ts is not None:
            df = df[df["timestamp"] < end_ts]

        df = df.dropna(subset=OHLCV_COLUMNS)
        valid_price_rows = (
            (df["open"] > 0)
            & (df["high"] > 0)
            & (df["low"] > 0)
            & (df["close"] > 0)
            & (df["high"] >= df["low"])
            & (df["volume"] >= 0)
        )
        df = df[valid_price_rows]
        df = df.drop_duplicates(subset=["timestamp"])
        df = df.sort_values("timestamp", ascending=True).reset_index(drop=True)
        return df[OHLCV_COLUMNS]
