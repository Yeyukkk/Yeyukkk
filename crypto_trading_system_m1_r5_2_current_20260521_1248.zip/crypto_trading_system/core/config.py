"""
Centralized config loading.

Two layers:
  1. Runtime config (paper.yaml / live.yaml) — describes how to run
  2. Strategy config (strategies/*.yaml) — describes the signal logic

This module loads both and merges them into a single immutable dict-like object.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = PROJECT_ROOT / "config"

# Load .env once at import. override=True so reloads take effect.
load_dotenv(PROJECT_ROOT / ".env", override=True)


class ConfigError(Exception):
    pass


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    with open(path, "r") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ConfigError(f"Config file is not a mapping: {path}")
    return data


def load_runtime_config(path: str | Path) -> dict[str, Any]:
    """
    Load a runtime config (paper.yaml or live.yaml) and automatically
    attach the referenced strategy config under the 'strategy_config' key.
    """
    path = Path(path)
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    cfg = _read_yaml(path)

    strategy_name = cfg.get("strategy")
    if not strategy_name:
        raise ConfigError(f"Runtime config {path} is missing 'strategy' key")

    strategy_path = CONFIG_DIR / "strategies" / f"{strategy_name}.yaml"
    cfg["strategy_config"] = _read_yaml(strategy_path)
    cfg["_runtime_config_path"] = str(path)
    cfg["_strategy_config_path"] = str(strategy_path)

    _validate(cfg)
    return cfg


def load_strategy_config(name: str) -> dict[str, Any]:
    """Load just a strategy config by name (used by backtest)."""
    path = CONFIG_DIR / "strategies" / f"{name}.yaml"
    return _read_yaml(path)


def get(cfg: dict, dotted_key: str, default: Any = None) -> Any:
    """Fetch a nested value using 'a.b.c' notation."""
    cur: Any = cfg
    for part in dotted_key.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def env(key: str, default: str | None = None, required: bool = False) -> str | None:
    """Read an env var. If required=True and missing, raise."""
    val = os.getenv(key, default)
    if required and not val:
        raise ConfigError(f"Required env var missing: {key}")
    return val


def _validate(cfg: dict[str, Any]) -> None:
    """Minimal sanity checks. More can be added per-bot later."""
    mode = cfg.get("mode")
    if mode not in ("PAPER", "LIVE", "BACKTEST"):
        raise ConfigError(f"Invalid mode: {mode!r} (expected PAPER | LIVE | BACKTEST)")

    if not cfg.get("symbols"):
        raise ConfigError("No symbols configured")

    tfs = cfg.get("timeframes")
    if not tfs or not isinstance(tfs, list):
        raise ConfigError("timeframes must be a non-empty list")
    for pair in tfs:
        if "htf" not in pair or "ltf" not in pair:
            raise ConfigError(f"Each timeframe entry needs htf and ltf: {pair}")


def proxy_dict() -> dict[str, str] | None:
    """Build a {'http':..., 'https':...} proxy dict from env, or None."""
    http = env("HTTP_PROXY")
    https = env("HTTPS_PROXY")
    if not http and not https:
        return None
    return {"http": http or https or "", "https": https or http or ""}
