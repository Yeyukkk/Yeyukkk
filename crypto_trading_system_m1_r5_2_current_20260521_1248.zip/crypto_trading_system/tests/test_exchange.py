from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

import pandas as pd

from core.data import OKXClient


class TestOKXPublicData(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = OKXClient()

    def test_01_client_uses_okx(self) -> None:
        self.assertEqual(self.client.exchange.id, "okx")

    def test_02_no_api_keys_required(self) -> None:
        self.assertFalse(bool(getattr(self.client.exchange, "apiKey", None)))
        self.assertFalse(bool(getattr(self.client.exchange, "secret", None)))

    def test_03_load_public_markets(self) -> None:
        markets = self.client.load_markets()
        self.assertIn("BTC/USDT", markets)

    def test_04_fetch_public_ohlcv_page(self) -> None:
        candles = self.client.fetch_ohlcv("BTC/USDT", timeframe="1m", limit=5)
        self.assertGreaterEqual(len(candles), 1)
        self.assertGreaterEqual(len(candles[0]), 6)

    def test_05_fetch_ohlcv_history_dataframe(self) -> None:
        end = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        start = end - timedelta(hours=3)
        df = self.client.fetch_ohlcv_history("BTC/USDT", "1m", start=start.isoformat(), end=end.isoformat(), limit=100)

        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(list(df.columns), ["timestamp", "open", "high", "low", "close", "volume"])
        self.assertGreater(len(df), 0)
        self.assertTrue(df["timestamp"].is_monotonic_increasing)
        self.assertEqual(str(df["timestamp"].dt.tz), "UTC")
        self.assertFalse(df["timestamp"].duplicated().any())


if __name__ == "__main__":
    unittest.main(verbosity=2)

