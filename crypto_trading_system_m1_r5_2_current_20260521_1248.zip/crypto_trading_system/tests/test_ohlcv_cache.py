from __future__ import annotations

from pathlib import Path

import ccxt
import pandas as pd

from bots.run_backtest import _load_or_fetch_ohlcv
from core.data import OKXClient, load_ohlcv_cache, ohlcv_cache_path, safe_cache_token, save_ohlcv_cache


def _ohlcv_frame() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "timestamp": pd.Timestamp("2024-01-01 00:15", tz="UTC"),
                "open": 101.0,
                "high": 102.0,
                "low": 100.0,
                "close": 101.5,
                "volume": 11.0,
            },
            {
                "timestamp": pd.Timestamp("2024-01-01 00:00", tz="UTC"),
                "open": 100.0,
                "high": 101.0,
                "low": 99.0,
                "close": 100.5,
                "volume": 10.0,
            },
        ]
    )


def test_ohlcv_cache_filename_sanitization(tmp_path: Path) -> None:
    assert safe_cache_token("BTC/USDT:USDT") == "BTC-USDT-USDT"
    assert (
        ohlcv_cache_path("OKX", "BTC/USDT", "15m", "2024-01-01", "2024-03-01", cache_dir=tmp_path)
        == tmp_path / "okx_BTC-USDT_15m_2024-01-01_2024-03-01.csv"
    )


def test_ohlcv_cache_save_load_roundtrip(tmp_path: Path) -> None:
    cache_path = tmp_path / "cache.csv"

    saved_path = save_ohlcv_cache(_ohlcv_frame(), cache_path)
    loaded = load_ohlcv_cache(saved_path)

    assert saved_path == cache_path
    assert list(loaded.columns) == ["timestamp", "open", "high", "low", "close", "volume"]
    assert loaded["timestamp"].dt.tz is not None
    assert loaded["timestamp"].is_monotonic_increasing
    assert loaded["close"].tolist() == [100.5, 101.5]


def test_run_backtest_loader_uses_existing_cache(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    cache_path = ohlcv_cache_path("okx", "BTC/USDT", "15m", "2024-01-01", "2024-01-02")
    save_ohlcv_cache(_ohlcv_frame(), cache_path)

    class DummyClient:
        def __init__(self) -> None:
            self.calls = 0

        def fetch_ohlcv_history(self, **kwargs) -> pd.DataFrame:
            self.calls += 1
            raise AssertionError("fetch_ohlcv_history should not be called when cache exists")

    client = DummyClient()
    loaded = _load_or_fetch_ohlcv(
        client=client,  # type: ignore[arg-type]
        label="LTF",
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-02",
        limit=100,
        no_cache=False,
        refresh_cache=False,
    )

    assert client.calls == 0
    assert len(loaded) == 2


def test_ohlcv_retry_recovers_after_rate_limit(monkeypatch) -> None:
    client = OKXClient(config={})
    calls = {"count": 0}

    def flaky_fetch(symbol: str, timeframe: str = "1m", since: int | None = None, limit: int = 100):
        calls["count"] += 1
        if calls["count"] < 3:
            raise ccxt.RateLimitExceeded("too many requests")
        return [[1_704_067_200_000, 100.0, 101.0, 99.0, 100.5, 10.0]]

    monkeypatch.setattr(client, "fetch_ohlcv", flaky_fetch)
    monkeypatch.setattr("core.data.exchange.time.sleep", lambda seconds: None)

    rows = client.fetch_ohlcv_with_retry("BTC/USDT", timeframe="15m", since=1_704_067_200_000, limit=100)

    assert calls["count"] == 3
    assert rows[0][4] == 100.5
