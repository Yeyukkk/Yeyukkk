from __future__ import annotations

from typing import Any

import pandas as pd
import pytest

from bots.run_smc_v2_failure_diagnostics import (
    EXIT_REASON_SUMMARY_COLUMNS,
    HOUR_SUMMARY_COLUMNS,
    KILLZONE_SUMMARY_COLUMNS,
    REWARD_FEE_SUMMARY_COLUMNS,
    RISK_BUCKET_SUMMARY_COLUMNS,
    STREAK_SUMMARY_COLUMNS,
    TARGET_EXPERIMENT,
    TRADE_COLUMNS,
    WINDOW_SUMMARY_COLUMNS,
    aggregate_exit_reason_summary,
    aggregate_hour_summary,
    aggregate_killzone_summary,
    aggregate_reward_fee_summary,
    aggregate_risk_bucket_summary,
    aggregate_window_summary,
    assign_reward_fee_bucket,
    assign_risk_bucket,
    build_report_text,
    build_streak_summary,
    build_top_n,
    compute_profit_factor,
    derive_time_columns,
    losing_streak_counts,
    max_consecutive_losses,
)


def test_target_experiment_is_long_only_block_15() -> None:
    assert TARGET_EXPERIMENT.name == "long_only_block_15"
    assert TARGET_EXPERIMENT.long_only is True
    assert TARGET_EXPERIMENT.short_only is False
    assert TARGET_EXPERIMENT.blocked_entry_hours_utc == (15,)
    assert TARGET_EXPERIMENT.block_new_york_shorts is False


def test_assign_risk_bucket_known_values() -> None:
    assert assign_risk_bucket(0.001) == "<=0.25%"
    assert assign_risk_bucket(0.0025) == "<=0.25%"
    assert assign_risk_bucket(0.003) == "0.25%-0.50%"
    assert assign_risk_bucket(0.005) == "0.25%-0.50%"
    assert assign_risk_bucket(0.006) == "0.50%-0.75%"
    assert assign_risk_bucket(0.0075) == "0.50%-0.75%"
    assert assign_risk_bucket(0.008) == "0.75%-1.00%"
    assert assign_risk_bucket(0.01) == "0.75%-1.00%"
    assert assign_risk_bucket(0.015) == ">1.00%"


def test_assign_risk_bucket_unknown_inputs() -> None:
    assert assign_risk_bucket(None) == "unknown"
    assert assign_risk_bucket(float("nan")) == "unknown"
    assert assign_risk_bucket("not-a-number") == "unknown"
    assert assign_risk_bucket(0.0) == "unknown"
    assert assign_risk_bucket(-0.01) == "unknown"


def test_assign_reward_fee_bucket_known_values() -> None:
    assert assign_reward_fee_bucket(3.0) == "<5"
    assert assign_reward_fee_bucket(4.99) == "<5"
    assert assign_reward_fee_bucket(5.0) == "5-10"
    assert assign_reward_fee_bucket(8.0) == "5-10"
    assert assign_reward_fee_bucket(10.0) == "10-20"
    assert assign_reward_fee_bucket(15.0) == "10-20"
    assert assign_reward_fee_bucket(20.0) == ">20"
    assert assign_reward_fee_bucket(25.0) == ">20"


def test_assign_reward_fee_bucket_unknown_inputs() -> None:
    assert assign_reward_fee_bucket(None) == "unknown"
    assert assign_reward_fee_bucket(float("nan")) == "unknown"
    assert assign_reward_fee_bucket("nope") == "unknown"


def test_compute_profit_factor() -> None:
    assert compute_profit_factor([]) is None
    assert compute_profit_factor([5.0, 10.0]) is None
    assert compute_profit_factor([10.0, -5.0, 3.0]) == pytest.approx(13.0 / 5.0)
    assert compute_profit_factor([-5.0, -3.0]) == pytest.approx(0.0)


def test_compute_profit_factor_ignores_nan() -> None:
    assert compute_profit_factor([10.0, float("nan"), -5.0]) == pytest.approx(10.0 / 5.0)


def test_max_consecutive_losses() -> None:
    assert max_consecutive_losses([]) == 0
    assert max_consecutive_losses([5.0, 3.0]) == 0
    assert max_consecutive_losses([-5.0, -3.0]) == 2
    assert max_consecutive_losses([-1, 2, -1, -1, 5, -1, -1, -1]) == 3
    assert max_consecutive_losses([0.0, -1.0, -2.0]) == 2  # zero is not a loss


def test_losing_streak_counts_combinations() -> None:
    empty = losing_streak_counts([])
    assert empty == {"streaks_2_losses": 0, "streaks_3_losses": 0, "streaks_4plus_losses": 0}

    counts = losing_streak_counts([-1, -1, 5])
    assert counts["streaks_2_losses"] == 1
    assert counts["streaks_3_losses"] == 0
    assert counts["streaks_4plus_losses"] == 0

    counts = losing_streak_counts([5, -1, -1, -1])
    assert counts["streaks_3_losses"] == 1

    counts = losing_streak_counts([-1, -1, -1, -1, 5])
    assert counts["streaks_4plus_losses"] == 1
    assert counts["streaks_3_losses"] == 0
    assert counts["streaks_2_losses"] == 0

    counts = losing_streak_counts([-1, -1, 5, -1, -1, -1, 5, -1, -1, -1, -1])
    assert counts == {"streaks_2_losses": 1, "streaks_3_losses": 1, "streaks_4plus_losses": 1}


def test_derive_time_columns() -> None:
    df = pd.DataFrame(
        {
            "entry_time": [
                "2024-01-15T07:00:00+00:00",
                "2024-03-01T15:30:00+00:00",
                "2024-05-04T22:45:00+00:00",
            ],
        }
    )
    out = derive_time_columns(df)
    assert out["entry_hour_utc"].tolist() == [7, 15, 22]
    # 2024-01-15 is Monday(0); 2024-03-01 Friday(4); 2024-05-04 Saturday(5)
    assert out["entry_weekday_utc"].tolist() == [0, 4, 5]
    assert out["entry_month"].tolist() == [1, 3, 5]


def test_derive_time_columns_handles_missing_entry_time() -> None:
    out = derive_time_columns(pd.DataFrame({"foo": [1, 2]}))
    assert set(["entry_hour_utc", "entry_weekday_utc", "entry_month"]).issubset(out.columns)


def _trade(**overrides: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "window": "W1",
        "start": "2024-01-01",
        "end": "2024-03-01",
        "symbol": "BTC/USDT",
        "timeframe": "15m",
        "htf_timeframe": "1h",
        "trade_id": 1,
        "side": "long",
        "entry_time": "2024-01-15T07:00:00+00:00",
        "exit_time": "2024-01-15T10:00:00+00:00",
        "entry_price": 100.0,
        "exit_price": 105.0,
        "net_pnl": 5.0,
        "pnl_pct": 0.05,
        "pnl_pct_on_margin": 0.5,
        "exit_reason": "take_profit",
        "bars_held": 12,
        "stop_loss_price": 95.0,
        "take_profit_price": 110.0,
        "strategy_version": "smc_v2",
        "killzone_name": "london",
        "passed_killzone": True,
        "passed_liquidity_sweep": True,
        "passed_choch": True,
        "sweep_level": 99.0,
        "choch_level": 102.0,
        "risk_pct": 0.005,
        "target_pct": 0.010,
        "rr": 2.0,
        "reward_to_fee_ratio": 14.0,
    }
    base.update(overrides)
    return base


def test_aggregate_window_summary_preserves_window_labels() -> None:
    rows = [
        _trade(window="W1", net_pnl=10.0, exit_reason="take_profit", bars_held=10,
               entry_time="2024-01-01T07:00:00+00:00"),
        _trade(window="W1", net_pnl=-5.0, exit_reason="stop_loss", bars_held=8,
               entry_time="2024-01-02T07:00:00+00:00"),
        _trade(window="W2", net_pnl=-3.0, exit_reason="stop_loss", bars_held=5,
               entry_time="2024-03-15T07:00:00+00:00"),
    ]
    trades = pd.DataFrame(rows)
    metadata = {
        "W1": {"start": "2024-01-01", "end": "2024-03-01", "net_pnl_pct": 0.5, "max_drawdown_pct": 1.0},
        "W2": {"start": "2024-03-01", "end": "2024-05-01", "net_pnl_pct": -0.3, "max_drawdown_pct": 2.0},
    }
    summary = aggregate_window_summary(trades, metadata, ["W1", "W2"])

    assert list(summary["window"]) == ["W1", "W2"]
    assert list(summary.columns) == WINDOW_SUMMARY_COLUMNS

    w1 = summary[summary["window"] == "W1"].iloc[0]
    assert w1["total_trades"] == 2
    assert w1["net_pnl"] == pytest.approx(5.0)
    assert w1["win_rate"] == pytest.approx(0.5)
    assert w1["max_drawdown_pct"] == 1.0
    assert w1["max_consecutive_losses"] == 1
    assert w1["stop_loss_trades"] == 1
    assert w1["take_profit_trades"] == 1
    assert w1["worst_trade"] == pytest.approx(-5.0)
    assert w1["best_trade"] == pytest.approx(10.0)

    w2 = summary[summary["window"] == "W2"].iloc[0]
    assert w2["total_trades"] == 1
    assert w2["max_consecutive_losses"] == 1


def test_aggregate_window_summary_empty_window() -> None:
    metadata = {"W1": {"start": "s", "end": "e", "net_pnl_pct": 0.0, "max_drawdown_pct": 0.0}}
    summary = aggregate_window_summary(pd.DataFrame(columns=["window", "net_pnl"]), metadata, ["W1"])
    row = summary.iloc[0]
    assert row["total_trades"] == 0
    assert row["max_consecutive_losses"] == 0


def test_aggregate_hour_summary_columns_and_sort() -> None:
    trades = pd.DataFrame(
        [
            _trade(entry_hour_utc=7, net_pnl=10.0, exit_reason="take_profit"),
            _trade(entry_hour_utc=13, net_pnl=-5.0, exit_reason="stop_loss"),
            _trade(entry_hour_utc=7, net_pnl=-2.0, exit_reason="stop_loss"),
        ]
    )
    summary = aggregate_hour_summary(trades)
    assert list(summary.columns) == HOUR_SUMMARY_COLUMNS
    assert list(summary["entry_hour_utc"]) == [7, 13]
    hour7 = summary[summary["entry_hour_utc"] == 7].iloc[0]
    assert hour7["trades"] == 2
    assert hour7["net_pnl"] == pytest.approx(8.0)
    assert hour7["stop_loss_rate"] == pytest.approx(0.5)


def test_aggregate_killzone_summary_columns() -> None:
    trades = pd.DataFrame(
        [
            _trade(killzone_name="london", net_pnl=5.0),
            _trade(killzone_name="new_york", net_pnl=-3.0, exit_reason="stop_loss"),
        ]
    )
    summary = aggregate_killzone_summary(trades)
    assert list(summary.columns) == KILLZONE_SUMMARY_COLUMNS
    assert set(summary["killzone_name"]) == {"london", "new_york"}


def test_aggregate_exit_reason_summary_columns() -> None:
    trades = pd.DataFrame(
        [
            _trade(exit_reason="take_profit", net_pnl=10.0),
            _trade(exit_reason="stop_loss", net_pnl=-5.0),
        ]
    )
    summary = aggregate_exit_reason_summary(trades)
    assert list(summary.columns) == EXIT_REASON_SUMMARY_COLUMNS
    tp = summary[summary["exit_reason"] == "take_profit"].iloc[0]
    assert tp["trades"] == 1
    assert tp["net_pnl"] == pytest.approx(10.0)


def test_aggregate_risk_bucket_summary_buckets_correctly() -> None:
    trades = pd.DataFrame(
        [
            _trade(risk_pct=0.002, net_pnl=5.0),
            _trade(risk_pct=0.004, net_pnl=-2.0, exit_reason="stop_loss"),
            _trade(risk_pct=0.012, net_pnl=10.0),
            _trade(risk_pct=None, net_pnl=-1.0),
        ]
    )
    summary = aggregate_risk_bucket_summary(trades)
    assert list(summary.columns) == RISK_BUCKET_SUMMARY_COLUMNS
    assert set(summary["risk_bucket"]) == {"<=0.25%", "0.25%-0.50%", ">1.00%", "unknown"}


def test_aggregate_reward_fee_summary_buckets_correctly() -> None:
    trades = pd.DataFrame(
        [
            _trade(reward_to_fee_ratio=3.0, net_pnl=5.0),
            _trade(reward_to_fee_ratio=8.0, net_pnl=-2.0),
            _trade(reward_to_fee_ratio=15.0, net_pnl=10.0),
            _trade(reward_to_fee_ratio=25.0, net_pnl=-7.0),
            _trade(reward_to_fee_ratio=None, net_pnl=1.0),
        ]
    )
    summary = aggregate_reward_fee_summary(trades)
    assert list(summary.columns) == REWARD_FEE_SUMMARY_COLUMNS
    assert set(summary["reward_fee_bucket"]) == {"<5", "5-10", "10-20", ">20", "unknown"}


def test_aggregators_tolerate_missing_metadata_columns() -> None:
    minimal = pd.DataFrame(
        [
            {"window": "W1", "net_pnl": 10.0, "exit_reason": "take_profit", "bars_held": 5,
             "side": "long", "entry_time": "2024-01-01T07:00:00+00:00"},
            {"window": "W1", "net_pnl": -5.0, "exit_reason": "stop_loss", "bars_held": 3,
             "side": "long", "entry_time": "2024-01-02T15:00:00+00:00"},
        ]
    )
    trades = derive_time_columns(minimal)
    # None of these should raise even though killzone_name / risk_pct /
    # reward_to_fee_ratio are missing.
    kz = aggregate_killzone_summary(trades)
    risk = aggregate_risk_bucket_summary(trades)
    rf = aggregate_reward_fee_summary(trades)
    exits = aggregate_exit_reason_summary(trades)
    hours = aggregate_hour_summary(trades)
    streaks = build_streak_summary(trades, ["W1"])
    assert isinstance(kz, pd.DataFrame)
    assert isinstance(risk, pd.DataFrame)
    assert isinstance(rf, pd.DataFrame)
    assert isinstance(exits, pd.DataFrame)
    assert isinstance(hours, pd.DataFrame)
    assert isinstance(streaks, pd.DataFrame)
    # Risk and reward-fee buckets should classify missing values as "unknown".
    assert (risk["risk_bucket"] == "unknown").all()
    assert (rf["reward_fee_bucket"] == "unknown").all()


def test_build_streak_summary_overall_and_per_window() -> None:
    trades = pd.DataFrame(
        [
            _trade(window="W1", net_pnl=-1.0, entry_time="2024-01-01T07:00:00+00:00"),
            _trade(window="W1", net_pnl=-1.0, entry_time="2024-01-02T07:00:00+00:00"),
            _trade(window="W1", net_pnl=5.0, entry_time="2024-01-03T07:00:00+00:00"),
            _trade(window="W2", net_pnl=-1.0, entry_time="2024-03-15T07:00:00+00:00"),
            _trade(window="W2", net_pnl=-1.0, entry_time="2024-03-16T07:00:00+00:00"),
            _trade(window="W2", net_pnl=-1.0, entry_time="2024-03-17T07:00:00+00:00"),
        ]
    )
    summary = build_streak_summary(trades, ["W1", "W2"])
    assert list(summary.columns) == STREAK_SUMMARY_COLUMNS
    assert list(summary["scope"]) == ["overall", "W1", "W2"]
    overall = summary[summary["scope"] == "overall"].iloc[0]
    # All 6 trades concatenated: 2 losses, 1 win, 3 losses → overall max streak is 3
    assert overall["max_consecutive_losses"] == 3
    w1 = summary[summary["scope"] == "W1"].iloc[0]
    assert w1["max_consecutive_losses"] == 2
    w2 = summary[summary["scope"] == "W2"].iloc[0]
    assert w2["max_consecutive_losses"] == 3


def test_build_top_n_orders_correctly() -> None:
    trades = pd.DataFrame(
        [
            _trade(trade_id=1, net_pnl=10.0),
            _trade(trade_id=2, net_pnl=-7.0),
            _trade(trade_id=3, net_pnl=5.0),
            _trade(trade_id=4, net_pnl=-2.0),
        ]
    )
    winners = build_top_n(trades, n=2, ascending=False)
    losers = build_top_n(trades, n=2, ascending=True)
    assert list(winners["trade_id"]) == [1, 3]
    assert list(losers["trade_id"]) == [2, 4]


def test_build_top_n_empty() -> None:
    out = build_top_n(pd.DataFrame(columns=["net_pnl"]), n=5)
    assert isinstance(out, pd.DataFrame)
    assert out.empty


def test_build_report_text_includes_required_sections() -> None:
    trades = pd.DataFrame(
        [
            _trade(window="W1", net_pnl=10.0, exit_reason="take_profit",
                   entry_time="2024-01-01T07:00:00+00:00",
                   entry_hour_utc=7, killzone_name="london", risk_pct=0.005,
                   reward_to_fee_ratio=14.0),
            _trade(window="W1", net_pnl=-5.0, exit_reason="stop_loss",
                   entry_time="2024-01-02T15:00:00+00:00",
                   entry_hour_utc=15, killzone_name="new_york", risk_pct=0.012,
                   reward_to_fee_ratio=3.0),
        ]
    )
    metadata = {
        "W1": {"start": "2024-01-01", "end": "2024-03-01", "net_pnl_pct": 0.5, "max_drawdown_pct": 1.0},
    }
    ws = aggregate_window_summary(trades, metadata, ["W1"])
    hs = aggregate_hour_summary(trades)
    kz = aggregate_killzone_summary(trades)
    er = aggregate_exit_reason_summary(trades)
    rb = aggregate_risk_bucket_summary(trades)
    rf = aggregate_reward_fee_summary(trades)
    ss = build_streak_summary(trades, ["W1"])

    text = build_report_text(
        trades=trades,
        window_summary=ws,
        hour_summary=hs,
        killzone_summary=kz,
        exit_reason_summary=er,
        risk_bucket_summary=rb,
        reward_fee_summary=rf,
        streak_summary=ss,
        symbol="BTC/USDT",
        timeframe="15m",
        htf_timeframe="1h",
        period_start="2024-01-01",
        period_end="2024-03-01",
    )

    assert "long_only_block_15" in text
    assert "Overall" in text
    assert "Best window" in text
    assert "Worst window" in text
    assert "Best hour" in text
    assert "Worst hour" in text
    assert "Best killzone" in text
    assert "Worst killzone" in text
    assert "Risk buckets losing money" in text
    assert "Reward-to-fee buckets losing money" in text
    assert "Concentration check" in text
    assert "This is diagnostics only, not a profitability claim." in text


def test_trade_columns_stable() -> None:
    assert TRADE_COLUMNS == [
        "window",
        "start",
        "end",
        "symbol",
        "timeframe",
        "htf_timeframe",
        "trade_id",
        "side",
        "entry_time",
        "exit_time",
        "entry_price",
        "exit_price",
        "net_pnl",
        "pnl_pct",
        "pnl_pct_on_margin",
        "exit_reason",
        "bars_held",
        "stop_loss_price",
        "take_profit_price",
        "strategy_version",
        "killzone_name",
        "passed_killzone",
        "passed_liquidity_sweep",
        "passed_choch",
        "sweep_level",
        "choch_level",
        "risk_pct",
        "target_pct",
        "rr",
        "reward_to_fee_ratio",
        "entry_hour_utc",
        "entry_weekday_utc",
        "entry_month",
    ]


def test_summary_column_lists_stable() -> None:
    assert WINDOW_SUMMARY_COLUMNS[0] == "window"
    assert "max_consecutive_losses" in WINDOW_SUMMARY_COLUMNS
    assert HOUR_SUMMARY_COLUMNS[0] == "entry_hour_utc"
    assert KILLZONE_SUMMARY_COLUMNS[0] == "killzone_name"
    assert EXIT_REASON_SUMMARY_COLUMNS[0] == "exit_reason"
    assert RISK_BUCKET_SUMMARY_COLUMNS[0] == "risk_bucket"
    assert REWARD_FEE_SUMMARY_COLUMNS[0] == "reward_fee_bucket"
    assert STREAK_SUMMARY_COLUMNS == [
        "scope",
        "max_consecutive_losses",
        "streaks_2_losses",
        "streaks_3_losses",
        "streaks_4plus_losses",
    ]
