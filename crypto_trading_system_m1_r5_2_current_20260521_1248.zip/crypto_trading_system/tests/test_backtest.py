from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest

from bots.run_parameter_sweep import aggregate_walk_forward, build_parameter_grid, parse_windows, score_result
from bots.run_smc_diagnostics import diagnose_trades, summarize_feature_lift
from bots.run_smc_walk_forward import aggregate_window_metrics, safe_window_label
from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.strategy import build_smc_features, save_smc_features


class ScriptedSignalStrategy:
    def __init__(self, signals: dict[int, str]) -> None:
        self.signals = signals

    def generate_signals(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        df = ohlcv.copy()
        df["signal"] = ""
        df["signal_reason"] = ""
        for index, signal in self.signals.items():
            df.loc[index, "signal"] = signal
            df.loc[index, "signal_reason"] = f"scripted_{signal}"
        return df


def _synthetic_ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=140, freq="15min", tz="UTC")
    prices = (
        [110 - i * 0.25 for i in range(50)]
        + [97.5 + i * 0.65 for i in range(45)]
        + [126.75 - i * 0.7 for i in range(45)]
    )
    rows = []
    previous_close = prices[0]
    for ts, close in zip(timestamps, prices, strict=True):
        open_price = previous_close
        high = max(open_price, close) + 0.5
        low = min(open_price, close) - 0.5
        rows.append(
            {
                "timestamp": ts,
                "open": open_price,
                "high": high,
                "low": low,
                "close": close,
                "volume": 100.0,
            }
        )
        previous_close = close
    return pd.DataFrame(rows)


def _scripted_ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=7, freq="15min", tz="UTC")
    opens = [100.0, 100.0, 105.0, 110.0, 120.0, 80.0, 90.0]
    closes = [100.0, 105.0, 95.0, 110.0, 120.0, 85.0, 90.0]
    rows = []
    for ts, open_price, close_price in zip(timestamps, opens, closes, strict=True):
        rows.append(
            {
                "timestamp": ts,
                "open": open_price,
                "high": max(open_price, close_price) + 1.0,
                "low": min(open_price, close_price) - 1.0,
                "close": close_price,
                "volume": 100.0,
            }
        )
    return pd.DataFrame(rows)


def _risk_ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=5, freq="15min", tz="UTC")
    rows = [
        (100.0, 101.0, 99.0, 100.0),
        (100.0, 101.0, 99.0, 100.0),
        (100.0, 101.0, 96.0, 98.0),
        (100.0, 101.0, 99.0, 100.0),
        (100.0, 101.0, 99.0, 100.0),
    ]
    return pd.DataFrame(
        [
            {
                "timestamp": ts,
                "open": open_price,
                "high": high,
                "low": low,
                "close": close,
                "volume": 100.0,
            }
            for ts, (open_price, high, low, close) in zip(timestamps, rows, strict=True)
        ]
    )


def test_backtest_runs_on_synthetic_data_and_writes_outputs(tmp_path: Path) -> None:
    output_dir = tmp_path / "logs"
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-03",
        initial_equity=10_000,
        fee_rate=0.0005,
        slippage_bps=2,
        position_size_pct=1.0,
        output_dir=output_dir,
    )

    result = BacktestEngine(config).run(
        _synthetic_ohlcv(),
        EMACrossoverStrategy(fast_ema=3, slow_ema=8),
    )

    summary_path = output_dir / "backtest_summary.json"
    trades_path = output_dir / "backtest_trades.csv"
    equity_curve_path = output_dir / "backtest_equity_curve.csv"
    skipped_signals_path = output_dir / "backtest_skipped_signals.csv"

    assert result.summary_path == summary_path
    assert summary_path.exists()
    assert trades_path.exists()
    assert equity_curve_path.exists()
    assert skipped_signals_path.exists()

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    for key in [
        "final_equity",
        "total_trades",
        "max_drawdown_pct",
        "net_pnl_pct",
        "leverage",
        "max_margin_pct",
        "average_margin_used",
        "max_margin_used",
        "total_fees",
        "allow_short",
        "long_trades",
        "short_trades",
        "use_smc_filter",
        "smc_lookback_bars",
        "require_bullish_bos",
        "smc_filter_skipped_signals",
    ]:
        assert key in summary

    trades = pd.read_csv(trades_path)
    equity_curve = pd.read_csv(equity_curve_path)
    assert summary["total_trades"] >= 1
    assert summary["allow_short"] is False
    assert summary["long_trades"] == summary["total_trades"]
    assert summary["short_trades"] == 0
    assert len(trades) == summary["total_trades"]
    assert not equity_curve.empty
    assert set(["timestamp", "equity", "cash", "position_qty", "drawdown_pct"]).issubset(equity_curve.columns)


def test_ema_signals_use_closed_candles_without_future_data() -> None:
    ohlcv = _synthetic_ohlcv()
    strategy = EMACrossoverStrategy(fast_ema=3, slow_ema=8)
    signals = strategy.generate_signals(ohlcv)

    early_signals = signals.loc[:7, "signal"]
    assert (early_signals == "").all()

    mutated = ohlcv.copy()
    mutated.loc[80:, "close"] = mutated.loc[80:, "close"] * 10
    mutated_signals = strategy.generate_signals(mutated)

    pd.testing.assert_series_equal(
        signals.loc[:79, "fast_ema"],
        mutated_signals.loc[:79, "fast_ema"],
        check_names=False,
    )
    pd.testing.assert_series_equal(
        signals.loc[:79, "slow_ema"],
        mutated_signals.loc[:79, "slow_ema"],
        check_names=False,
    )
    pd.testing.assert_series_equal(
        signals.loc[:79, "signal"],
        mutated_signals.loc[:79, "signal"],
        check_names=False,
    )


def test_execution_accounting_and_qc_invariants(tmp_path: Path) -> None:
    output_dir = tmp_path / "logs"
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0.01,
        slippage_bps=100,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        output_dir=output_dir,
    )
    strategy = ScriptedSignalStrategy(
        {
            0: "long_entry",
            1: "long_entry",
            3: "long_exit",
        }
    )

    result = BacktestEngine(config).run(_scripted_ohlcv(), strategy)
    trades = pd.read_csv(result.trades_path)
    equity_curve = pd.read_csv(result.equity_curve_path)
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))

    assert summary["total_trades"] == 1
    assert len(trades) == 1

    first_trade = trades.iloc[0]

    assert first_trade["entry_time"] == "2024-01-01T00:15:00+00:00"
    assert first_trade["exit_time"] == "2024-01-01T01:00:00+00:00"
    assert first_trade["exit_reason"] == "ema_cross_exit"
    assert first_trade["entry_price"] == pytest.approx(101.0)
    assert first_trade["exit_price"] == pytest.approx(118.8)

    assert first_trade["leverage"] == pytest.approx(10)
    assert first_trade["margin_used"] <= 200
    assert first_trade["margin_used"] == pytest.approx(config.initial_equity * config.max_margin_pct)
    assert first_trade["margin_pct_of_equity"] <= 0.20
    assert first_trade["margin_pct_of_equity"] == pytest.approx(0.20)
    assert first_trade["position_notional"] <= 2_000
    assert first_trade["position_notional"] == pytest.approx(first_trade["margin_used"] * config.leverage)
    assert first_trade["position_notional_pct_of_equity"] <= 2.0
    assert first_trade["position_notional_pct_of_equity"] == pytest.approx(2.0)
    assert first_trade["entry_notional"] == pytest.approx(first_trade["position_notional"])

    assert first_trade["entry_fee"] == pytest.approx(first_trade["entry_notional"] * config.fee_rate)
    assert first_trade["exit_fee"] == pytest.approx(first_trade["exit_notional"] * config.fee_rate)
    assert first_trade["total_fee"] == pytest.approx(first_trade["entry_fee"] + first_trade["exit_fee"])

    assert first_trade["notional"] == pytest.approx(first_trade["position_notional"])
    assert first_trade["pnl_pct_on_margin"] == pytest.approx(first_trade["net_pnl"] / first_trade["margin_used"])
    assert first_trade["pnl_pct_on_equity"] == pytest.approx(first_trade["net_pnl"] / first_trade["equity_before"])

    assert trades["trade_id"].tolist() == [1]
    assert (equity_curve["cash"] >= -1e-9).all()

    open_rows = equity_curve[equity_curve["position_qty"] > 0]
    assert not open_rows.empty
    assert (open_rows["position_market_value"] > 0).all()
    assert open_rows["unrealized_pnl"].abs().max() > 0

    assert summary["final_equity"] == pytest.approx(equity_curve.iloc[-1]["equity"])
    assert summary["net_pnl"] == pytest.approx(trades["net_pnl"].sum())

    assert equity_curve["drawdown_pct"].min() <= 0
    assert summary["max_drawdown_pct"] == pytest.approx(abs(equity_curve["drawdown_pct"].min()))
    assert summary["leverage"] == pytest.approx(10)
    assert summary["max_margin_pct"] == pytest.approx(0.20)
    assert summary["average_margin_used"] == pytest.approx(first_trade["margin_used"])
    assert summary["max_margin_used"] == pytest.approx(first_trade["margin_used"])
    assert summary["average_margin_pct_of_equity"] == pytest.approx(first_trade["margin_pct_of_equity"])
    assert summary["max_margin_pct_of_equity_used"] == pytest.approx(first_trade["margin_pct_of_equity"])
    assert summary["average_position_notional"] == pytest.approx(first_trade["position_notional"])
    assert summary["max_position_notional_used"] == pytest.approx(first_trade["position_notional"])
    assert summary["average_position_notional_pct_of_equity"] == pytest.approx(
        first_trade["position_notional_pct_of_equity"]
    )
    assert summary["max_position_notional_pct_of_equity_used"] == pytest.approx(
        first_trade["position_notional_pct_of_equity"]
    )
    assert summary["total_fees"] == pytest.approx(first_trade["total_fee"])


def test_stop_loss_closes_leveraged_long(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=0.30,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_risk_ohlcv(), ScriptedSignalStrategy({0: "long_entry"}))
    trade = pd.read_csv(result.trades_path).iloc[0]
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))

    assert trade["exit_reason"] == "stop_loss"
    assert trade["exit_price"] == pytest.approx(97.0)
    assert trade["pnl_pct_on_margin"] == pytest.approx(-0.30)
    assert summary["stop_loss_exits"] == 1


def test_liquidation_can_close_leveraged_long(tmp_path: Path) -> None:
    ohlcv = _risk_ohlcv()
    ohlcv.loc[2, "low"] = 90.0
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=2.0,
        maintenance_margin_pct=0.005,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(ohlcv, ScriptedSignalStrategy({0: "long_entry"}))
    trade = pd.read_csv(result.trades_path).iloc[0]
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))

    assert trade["exit_reason"] == "liquidation"
    assert trade["exit_price"] == pytest.approx(90.5)
    assert summary["liquidation_exits"] == 1


def test_max_account_drawdown_blocks_new_entries(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=0.30,
        max_account_drawdown_pct=0.05,
        max_daily_loss_pct=1.0,
        max_consecutive_losses=99,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_risk_ohlcv(), ScriptedSignalStrategy({0: "long_entry", 2: "long_entry"}))
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
    skipped = pd.read_csv(result.skipped_signals_path)

    assert summary["stop_loss_exits"] == 1
    assert summary["skipped_signal_reasons"]["max_account_drawdown"] == 1
    assert summary["skipped_signals"] == 1
    assert skipped["reason"].tolist() == ["max_account_drawdown"]


def test_daily_loss_blocks_new_entries_for_same_utc_day(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=0.30,
        max_account_drawdown_pct=1.0,
        max_daily_loss_pct=0.05,
        max_consecutive_losses=99,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_risk_ohlcv(), ScriptedSignalStrategy({0: "long_entry", 2: "long_entry"}))
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
    skipped = pd.read_csv(result.skipped_signals_path)

    assert summary["stop_loss_exits"] == 1
    assert summary["skipped_signal_reasons"]["max_daily_loss"] == 1
    assert summary["skipped_signals"] == 1
    assert skipped["reason"].tolist() == ["max_daily_loss"]


def test_cooldown_blocks_entries_after_loss_streak(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=0.30,
        max_account_drawdown_pct=1.0,
        max_daily_loss_pct=1.0,
        max_consecutive_losses=1,
        cooldown_bars_after_loss_streak=20,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_risk_ohlcv(), ScriptedSignalStrategy({0: "long_entry", 2: "long_entry"}))
    summary = json.loads(result.summary_path.read_text(encoding="utf-8"))
    skipped = pd.read_csv(result.skipped_signals_path)

    assert summary["stop_loss_exits"] == 1
    assert summary["skipped_signal_reasons"]["cooldown_after_loss_streak"] == 1
    assert summary["skipped_signals"] == 1
    assert skipped["reason"].tolist() == ["cooldown_after_loss_streak"]


def test_parameter_sweep_grid_and_score_helpers() -> None:
    grid = build_parameter_grid(max_runs=3)

    assert len(grid) == 3
    assert set(grid[0]) == {
        "stop_loss_pct_on_margin",
        "max_account_drawdown_pct",
        "max_daily_loss_pct",
        "max_consecutive_losses",
        "cooldown_bars_after_loss_streak",
    }
    assert len(build_parameter_grid(quick=True)) == 10
    assert score_result({"net_pnl_pct": 0.20, "max_drawdown_pct": 0.10}) == pytest.approx(0.13)


def test_walk_forward_helpers() -> None:
    params = build_parameter_grid(max_runs=1)[0]
    windows = parse_windows("2024-01-01:2024-03-01,2024-03-01:2024-05-01")
    aggregate = aggregate_walk_forward(
        params,
        [
            {"net_pnl_pct": 0.10, "max_drawdown_pct": 0.04, "final_equity": 1100, "total_trades": 10, "profit_factor": 1.5},
            {"net_pnl_pct": -0.05, "max_drawdown_pct": 0.08, "final_equity": 950, "total_trades": 8, "profit_factor": 0.8},
        ],
    )

    assert windows == [("2024-01-01", "2024-03-01"), ("2024-03-01", "2024-05-01")]
    assert aggregate["avg_net_pnl_pct"] == pytest.approx(0.025)
    assert aggregate["median_net_pnl_pct"] == pytest.approx(0.025)
    assert aggregate["worst_net_pnl_pct"] == pytest.approx(-0.05)
    assert aggregate["positive_windows"] == 1
    assert aggregate["total_windows"] == 2
    assert aggregate["score"] == pytest.approx(0.025 - 0.7 * 0.06 - 0.05)


def test_smc_walk_forward_helpers() -> None:
    aggregate = aggregate_window_metrics(
        [
            {"net_pnl_pct": 0.10, "max_drawdown_pct": 0.04},
            {"net_pnl_pct": -0.06, "max_drawdown_pct": 0.12},
            {"net_pnl_pct": 0.02, "max_drawdown_pct": 0.08},
        ]
    )

    assert safe_window_label("2024-01-01", "2024-03-01") == "2024-01-01_2024-03-01"
    assert aggregate["average_net_pnl_pct"] == pytest.approx(0.02)
    assert aggregate["median_net_pnl_pct"] == pytest.approx(0.02)
    assert aggregate["worst_net_pnl_pct"] == pytest.approx(-0.06)
    assert aggregate["average_max_drawdown_pct"] == pytest.approx(0.08)
    assert aggregate["worst_max_drawdown_pct"] == pytest.approx(0.12)
    assert aggregate["positive_windows"] == 2
    assert aggregate["total_windows"] == 3


def test_smc_features_on_synthetic_ohlcv(tmp_path: Path) -> None:
    features = build_smc_features(_synthetic_ohlcv(), swing_length=3)
    output_path = save_smc_features(features, tmp_path / "smc_features.csv")

    assert output_path.exists()
    assert not features.empty
    assert "smc_swing_high_low_raw" in features.columns
    assert "smc_swing_high_low_confirmed" in features.columns
    assert "smc_fvg_fvg_raw" in features.columns
    assert "smc_fvg_fvg_confirmed" in features.columns
    assert "smc_previous_high_low_previous_high_raw" in features.columns
    assert "smc_sessions_active_raw" in features.columns

    pd.testing.assert_series_equal(
        features["smc_swing_high_low_raw"].shift(3),
        features["smc_swing_high_low_confirmed"],
        check_names=False,
    )
    pd.testing.assert_series_equal(
        features["smc_fvg_fvg_raw"].shift(1),
        features["smc_fvg_fvg_confirmed"],
        check_names=False,
    )


def test_smc_diagnostics_use_lookback_only() -> None:
    timestamps = pd.date_range("2024-01-01", periods=6, freq="15min", tz="UTC")
    features = pd.DataFrame(
        {
            "timestamp": timestamps,
            "smc_fvg_fvg_confirmed": [0, 1, 0, -1, 0, 1],
            "smc_bos_choch_bos_confirmed": [0, 0, 1, 0, -1, 0],
            "smc_bos_choch_choch_confirmed": [0, 0, 0, 1, 0, -1],
            "smc_ob_ob_confirmed": [0, 0, 0, 0, 1, -1],
            "smc_liquidity_liquidity_confirmed": [0, 0, 0, 0, 0, 1],
            "smc_previous_high_low_broken_high_confirmed": [0, 1, 0, 0, 0, 0],
            "smc_previous_high_low_broken_low_confirmed": [0, 0, 0, 1, 0, 0],
            "smc_sessions_active_confirmed": [0, 1, 1, 1, 0, 0],
        }
    )
    trades = pd.DataFrame(
        {
            "trade_id": [1, 2],
            "entry_time": [timestamps[3], timestamps[5]],
            "exit_time": [timestamps[4], timestamps[5]],
            "net_pnl": [10.0, -5.0],
        }
    )

    diagnostics = diagnose_trades(features, trades, lookback_bars=2)
    summary = summarize_feature_lift(diagnostics)

    first = diagnostics.iloc[0]
    second = diagnostics.iloc[1]
    assert bool(first["bullish_fvg_confirmed"]) is True
    assert bool(first["bearish_fvg_confirmed"]) is False
    assert bool(first["bullish_bos_confirmed"]) is True
    assert bool(first["trade_is_win"]) is True
    assert bool(second["bearish_fvg_confirmed"]) is True
    assert bool(second["bullish_fvg_confirmed"]) is False
    assert bool(second["trade_is_win"]) is False
    assert summary["bullish_bos_confirmed"]["lift"] == pytest.approx(1.0)
    assert summary["bearish_fvg_confirmed"]["lift"] == pytest.approx(-1.0)


def test_smc_filter_allows_entry_with_bullish_bos(tmp_path: Path) -> None:
    ohlcv = _scripted_ohlcv()
    features_path = tmp_path / "smc_features.csv"
    pd.DataFrame(
        {
            "timestamp": ohlcv["timestamp"],
            "smc_bos_choch_bos_confirmed": [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        }
    ).to_csv(features_path, index=False)
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        use_smc_filter=True,
        smc_features_path=str(features_path),
        smc_lookback_bars=2,
        require_bullish_bos=True,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(ohlcv, ScriptedSignalStrategy({0: "long_entry", 3: "long_exit"}))

    assert result.summary["total_trades"] == 1
    assert result.summary["smc_filter_skipped_signals"] == 0
    assert result.summary["use_smc_filter"] is True
    assert result.summary["require_bullish_bos"] is True


def test_smc_filter_skips_entry_without_bullish_bos(tmp_path: Path) -> None:
    ohlcv = _scripted_ohlcv()
    features_path = tmp_path / "smc_features.csv"
    pd.DataFrame(
        {
            "timestamp": ohlcv["timestamp"],
            "smc_bos_choch_bos_confirmed": [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
        }
    ).to_csv(features_path, index=False)
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        use_smc_filter=True,
        smc_features_path=str(features_path),
        smc_lookback_bars=2,
        require_bullish_bos=True,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(ohlcv, ScriptedSignalStrategy({0: "long_entry"}))
    skipped = pd.read_csv(result.skipped_signals_path)

    assert result.summary["total_trades"] == 0
    assert result.summary["smc_filter_skipped_signals"] == 1
    assert result.summary["skipped_signal_reasons"]["smc_filter_no_bullish_bos"] == 1
    assert skipped["reason"].tolist() == ["smc_filter_no_bullish_bos"]
