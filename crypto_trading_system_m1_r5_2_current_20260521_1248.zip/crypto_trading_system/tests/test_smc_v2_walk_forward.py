from __future__ import annotations

import pytest

from bots.run_smc_v2_walk_forward import (
    CONSOLE_COLUMNS,
    DETAILS_COLUMNS,
    PREDEFINED_EXPERIMENTS,
    RESULTS_COLUMNS,
    Experiment,
    aggregate_experiment_rows,
    build_experiment_strategy,
    compute_score,
    parse_windows,
)
from core.strategy import SMCStrategyV2


def test_parse_windows_single() -> None:
    assert parse_windows("2024-01-01:2024-03-01") == [("2024-01-01", "2024-03-01")]


def test_parse_windows_multiple() -> None:
    parsed = parse_windows("2024-01-01:2024-03-01,2024-03-01:2024-05-01")
    assert parsed == [
        ("2024-01-01", "2024-03-01"),
        ("2024-03-01", "2024-05-01"),
    ]


def test_parse_windows_strips_whitespace() -> None:
    parsed = parse_windows(" 2024-01-01:2024-03-01 , 2024-03-01:2024-05-01 ")
    assert parsed == [
        ("2024-01-01", "2024-03-01"),
        ("2024-03-01", "2024-05-01"),
    ]


def test_parse_windows_empty_token_is_skipped() -> None:
    parsed = parse_windows("2024-01-01:2024-03-01,,")
    assert parsed == [("2024-01-01", "2024-03-01")]


def test_parse_windows_invalid_format() -> None:
    with pytest.raises(ValueError, match="expected START:END"):
        parse_windows("2024-01-01_2024-03-01")


def test_parse_windows_empty_string() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        parse_windows("")


def test_parse_windows_none() -> None:
    with pytest.raises(ValueError, match="non-empty"):
        parse_windows(None)


def test_parse_windows_missing_end() -> None:
    with pytest.raises(ValueError, match="missing"):
        parse_windows("2024-01-01:")


def test_parse_windows_missing_start() -> None:
    with pytest.raises(ValueError, match="missing"):
        parse_windows(":2024-03-01")


def test_parse_windows_start_after_end() -> None:
    with pytest.raises(ValueError, match="start must be before end"):
        parse_windows("2024-03-01:2024-01-01")


def test_parse_windows_invalid_date() -> None:
    with pytest.raises(ValueError):
        parse_windows("not-a-date:also-not-a-date")


def test_compute_score_matches_formula() -> None:
    score = compute_score(
        avg_net_pnl_pct=10.0,
        avg_max_drawdown_pct=5.0,
        worst_net_pnl_pct=-3.0,
    )
    assert score == pytest.approx(10.0 - 0.7 * 5.0 - abs(-3.0))


def test_compute_score_penalizes_worse_drawdown() -> None:
    base = compute_score(avg_net_pnl_pct=5.0, avg_max_drawdown_pct=2.0, worst_net_pnl_pct=-1.0)
    worse = compute_score(avg_net_pnl_pct=5.0, avg_max_drawdown_pct=10.0, worst_net_pnl_pct=-1.0)
    assert base > worse


def test_compute_score_penalizes_worse_worst_pnl() -> None:
    base = compute_score(avg_net_pnl_pct=5.0, avg_max_drawdown_pct=2.0, worst_net_pnl_pct=-1.0)
    worse = compute_score(avg_net_pnl_pct=5.0, avg_max_drawdown_pct=2.0, worst_net_pnl_pct=-10.0)
    assert base > worse


def _detail_row(
    *,
    net_pnl_pct: float,
    max_drawdown_pct: float,
    total_trades: int = 0,
    win_rate: float = 0.0,
    profit_factor: float | None = None,
    long_trades: int = 0,
    short_trades: int = 0,
) -> dict:
    return {
        "experiment": "ex",
        "net_pnl_pct": net_pnl_pct,
        "max_drawdown_pct": max_drawdown_pct,
        "total_trades": total_trades,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "long_trades": long_trades,
        "short_trades": short_trades,
    }


def test_aggregate_experiment_rows_basic() -> None:
    rows = [
        _detail_row(net_pnl_pct=10.0, max_drawdown_pct=5.0, total_trades=10, win_rate=0.6,
                    profit_factor=2.0, long_trades=7, short_trades=3),
        _detail_row(net_pnl_pct=-2.0, max_drawdown_pct=8.0, total_trades=5, win_rate=0.4,
                    profit_factor=0.8, long_trades=3, short_trades=2),
        _detail_row(net_pnl_pct=4.0, max_drawdown_pct=6.0, total_trades=0, win_rate=0.0,
                    profit_factor=None, long_trades=0, short_trades=0),
    ]
    agg = aggregate_experiment_rows("ex", rows)

    assert agg["experiment"] == "ex"
    assert agg["windows"] == 3
    assert agg["positive_windows"] == 2
    assert agg["avg_net_pnl_pct"] == pytest.approx((10.0 - 2.0 + 4.0) / 3)
    assert agg["median_net_pnl_pct"] == pytest.approx(4.0)
    assert agg["worst_net_pnl_pct"] == pytest.approx(-2.0)
    assert agg["best_net_pnl_pct"] == pytest.approx(10.0)
    assert agg["avg_max_drawdown_pct"] == pytest.approx((5.0 + 8.0 + 6.0) / 3)
    assert agg["worst_max_drawdown_pct"] == pytest.approx(8.0)
    assert agg["total_trades"] == 15
    assert agg["avg_win_rate"] == pytest.approx((0.6 + 0.4 + 0.0) / 3)
    assert agg["avg_profit_factor"] == pytest.approx((2.0 + 0.8) / 2)
    assert agg["total_long_trades"] == 10
    assert agg["total_short_trades"] == 5
    expected_score = compute_score(
        avg_net_pnl_pct=agg["avg_net_pnl_pct"],
        avg_max_drawdown_pct=agg["avg_max_drawdown_pct"],
        worst_net_pnl_pct=agg["worst_net_pnl_pct"],
    )
    assert agg["score"] == pytest.approx(expected_score)


def test_aggregate_experiment_rows_empty_raises() -> None:
    with pytest.raises(ValueError):
        aggregate_experiment_rows("ex", [])


def test_aggregate_experiment_rows_all_profit_factors_none() -> None:
    rows = [
        _detail_row(net_pnl_pct=1.0, max_drawdown_pct=1.0, profit_factor=None),
        _detail_row(net_pnl_pct=2.0, max_drawdown_pct=2.0, profit_factor=None),
    ]
    agg = aggregate_experiment_rows("ex", rows)
    assert agg["avg_profit_factor"] == 0.0


def test_predefined_experiments_names_in_required_order() -> None:
    names = [exp.name for exp in PREDEFINED_EXPERIMENTS]
    assert names == [
        "baseline",
        "long_only",
        "block_15",
        "long_only_block_15",
        "block_new_york_shorts",
    ]


def test_predefined_experiments_unique_names() -> None:
    names = [exp.name for exp in PREDEFINED_EXPERIMENTS]
    assert len(names) == len(set(names))


def _experiment_by_name(name: str) -> Experiment:
    return next(exp for exp in PREDEFINED_EXPERIMENTS if exp.name == name)


def test_build_experiment_strategy_baseline_uses_defaults() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("baseline"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )
    assert isinstance(strategy, SMCStrategyV2)
    assert strategy.long_only is False
    assert strategy.short_only is False
    assert strategy.blocked_entry_hours_utc == []
    assert strategy.block_new_york_shorts is False


def test_build_experiment_strategy_long_only_sets_flag() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("long_only"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )
    assert strategy.long_only is True
    assert strategy.short_only is False
    assert strategy.blocked_entry_hours_utc == []


def test_build_experiment_strategy_block_15_sets_hour_list() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("block_15"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )
    assert strategy.long_only is False
    assert strategy.blocked_entry_hours_utc == [15]


def test_build_experiment_strategy_long_only_block_15_sets_both() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("long_only_block_15"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )
    assert strategy.long_only is True
    assert strategy.blocked_entry_hours_utc == [15]


def test_build_experiment_strategy_block_new_york_shorts() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("block_new_york_shorts"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )
    assert strategy.block_new_york_shorts is True
    assert strategy.long_only is False
    assert strategy.blocked_entry_hours_utc == []


def test_build_experiment_strategy_propagates_symbol_and_timeframes() -> None:
    strategy = build_experiment_strategy(
        experiment=_experiment_by_name("baseline"),
        symbol="ETH/USDT",
        ltf_timeframe="5m",
        htf_timeframe="4h",
    )
    assert strategy.symbol == "ETH/USDT"
    assert strategy.ltf_timeframe == "5m"
    assert strategy.htf_timeframe == "4h"


def test_details_columns_stable() -> None:
    assert DETAILS_COLUMNS == [
        "experiment",
        "symbol",
        "timeframe",
        "htf_timeframe",
        "start",
        "end",
        "final_equity",
        "net_pnl",
        "net_pnl_pct",
        "max_drawdown_pct",
        "total_trades",
        "win_rate",
        "profit_factor",
        "long_trades",
        "short_trades",
    ]


def test_results_columns_stable() -> None:
    assert RESULTS_COLUMNS == [
        "experiment",
        "windows",
        "positive_windows",
        "avg_net_pnl_pct",
        "median_net_pnl_pct",
        "worst_net_pnl_pct",
        "best_net_pnl_pct",
        "avg_max_drawdown_pct",
        "worst_max_drawdown_pct",
        "total_trades",
        "avg_win_rate",
        "avg_profit_factor",
        "total_long_trades",
        "total_short_trades",
        "score",
    ]


def test_console_columns_stable() -> None:
    assert CONSOLE_COLUMNS == [
        "experiment",
        "score",
        "avg_net_pnl_pct",
        "worst_net_pnl_pct",
        "avg_max_drawdown_pct",
        "positive_windows",
        "total_trades",
        "avg_profit_factor",
    ]


def test_aggregate_keys_match_results_columns() -> None:
    rows = [_detail_row(net_pnl_pct=1.0, max_drawdown_pct=1.0)]
    agg = aggregate_experiment_rows("ex", rows)
    assert set(agg.keys()) == set(RESULTS_COLUMNS)
