from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.data import attach_confirmed_higher_timeframe, closed_higher_timeframe_slice, timeframe_to_timedelta


class RecordingMultiTimeframeStrategy:
    def __init__(self) -> None:
        self.latest_htf_by_ltf: list[tuple[pd.Timestamp, pd.Timestamp | None]] = []

    def generate_signals(self, ltf_ohlcv: pd.DataFrame, htf_ohlcv: pd.DataFrame) -> pd.DataFrame:
        ltf_timestamp = pd.Timestamp(ltf_ohlcv.iloc[-1]["timestamp"])
        latest_htf_timestamp = None if htf_ohlcv.empty else pd.Timestamp(htf_ohlcv.iloc[-1]["timestamp"])
        self.latest_htf_by_ltf.append((ltf_timestamp, latest_htf_timestamp))

        signals = ltf_ohlcv.copy()
        signals["signal"] = ""
        signals["signal_reason"] = ""
        return signals


def _ltf_ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01 10:15", periods=5, freq="15min", tz="UTC")
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": [100.0, 101.0, 102.0, 103.0, 104.0],
            "high": [101.0, 102.0, 103.0, 104.0, 105.0],
            "low": [99.0, 100.0, 101.0, 102.0, 103.0],
            "close": [101.0, 102.0, 103.0, 104.0, 105.0],
            "volume": [100.0] * 5,
        }
    )


def _htf_ohlcv() -> pd.DataFrame:
    timestamps = pd.to_datetime(
        ["2024-01-01 09:00", "2024-01-01 10:00", "2024-01-01 11:00"],
        utc=True,
    )
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": [90.0, 100.0, 110.0],
            "high": [101.0, 111.0, 121.0],
            "low": [89.0, 99.0, 109.0],
            "close": [100.0, 110.0, 120.0],
            "volume": [1000.0, 1000.0, 1000.0],
        }
    )


def test_timeframe_to_timedelta() -> None:
    assert timeframe_to_timedelta("15m") == pd.Timedelta(minutes=15)
    assert timeframe_to_timedelta("4h") == pd.Timedelta(hours=4)
    assert timeframe_to_timedelta("1d") == pd.Timedelta(days=1)
    assert timeframe_to_timedelta("1w") == pd.Timedelta(weeks=1)
    with pytest.raises(ValueError):
        timeframe_to_timedelta("1mo")


def test_attach_confirmed_higher_timeframe_uses_only_closed_candles() -> None:
    lower = pd.DataFrame(
        {
            "timestamp": pd.date_range("2024-01-01 10:00", periods=8, freq="15min", tz="UTC"),
            "close": [100, 101, 102, 103, 104, 105, 106, 107],
        }
    )
    higher = pd.DataFrame(
        {
            "timestamp": pd.to_datetime(
                ["2024-01-01 09:00", "2024-01-01 10:00", "2024-01-01 11:00"],
                utc=True,
            ),
            "trend": ["prior_closed", "current_hour", "future_hour"],
        }
    )

    result = attach_confirmed_higher_timeframe(lower, higher, "1h", columns=["trend"])

    assert result.loc[0, "htf_1h_trend"] == "prior_closed"
    assert result.loc[3, "htf_1h_trend"] == "prior_closed"
    assert result.loc[4, "htf_1h_trend"] == "current_hour"
    assert result.loc[7, "htf_1h_trend"] == "current_hour"
    assert "future_hour" not in result["htf_1h_trend"].dropna().tolist()
    assert result.loc[4, "htf_1h_timestamp"] == pd.Timestamp("2024-01-01 10:00", tz="UTC")
    assert result.loc[4, "htf_1h_available_at"] == pd.Timestamp("2024-01-01 11:00", tz="UTC")


def test_closed_higher_timeframe_slice_never_includes_unfinished_htf_candle() -> None:
    htf = _htf_ohlcv()

    for current_time in ["2024-01-01 10:15", "2024-01-01 10:30", "2024-01-01 10:45"]:
        htf_slice = closed_higher_timeframe_slice(htf, current_time, higher_timeframe_name="1h")
        assert htf_slice["timestamp"].max() == pd.Timestamp("2024-01-01 09:00", tz="UTC")
        assert pd.Timestamp("2024-01-01 10:00", tz="UTC") not in set(htf_slice["timestamp"])

    htf_slice = closed_higher_timeframe_slice(htf, "2024-01-01 11:00", higher_timeframe_name="1h")
    assert htf_slice["timestamp"].max() == pd.Timestamp("2024-01-01 10:00", tz="UTC")


def test_engine_multitimeframe_strategy_receives_only_closed_htf_candles(tmp_path: Path) -> None:
    strategy = RecordingMultiTimeframeStrategy()
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01 10:15",
        end="2024-01-01 11:30",
        initial_equity=1_000,
        output_dir=tmp_path / "logs",
    )

    BacktestEngine(config).run(_ltf_ohlcv(), strategy, htf_ohlcv=_htf_ohlcv(), htf_timeframe="1h")

    visible = dict(strategy.latest_htf_by_ltf)
    assert visible[pd.Timestamp("2024-01-01 10:15", tz="UTC")] == pd.Timestamp("2024-01-01 09:00", tz="UTC")
    assert visible[pd.Timestamp("2024-01-01 10:30", tz="UTC")] == pd.Timestamp("2024-01-01 09:00", tz="UTC")
    assert visible[pd.Timestamp("2024-01-01 10:45", tz="UTC")] == pd.Timestamp("2024-01-01 09:00", tz="UTC")
    assert visible[pd.Timestamp("2024-01-01 11:00", tz="UTC")] == pd.Timestamp("2024-01-01 10:00", tz="UTC")
    assert visible[pd.Timestamp("2024-01-01 11:15", tz="UTC")] == pd.Timestamp("2024-01-01 10:00", tz="UTC")


def test_single_timeframe_ema_backtest_still_runs_without_htf_ohlcv(tmp_path: Path) -> None:
    timestamps = pd.date_range("2024-01-01", periods=40, freq="15min", tz="UTC")
    ohlcv = pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": [100.0 + index * 0.1 for index in range(40)],
            "high": [101.0 + index * 0.1 for index in range(40)],
            "low": [99.0 + index * 0.1 for index in range(40)],
            "close": [100.5 + index * 0.1 for index in range(40)],
            "volume": [100.0] * 40,
        }
    )
    output_dir = tmp_path / "logs"
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 10:00",
        initial_equity=1_000,
        output_dir=output_dir,
    )

    result = BacktestEngine(config).run(ohlcv, EMACrossoverStrategy(fast_ema=3, slow_ema=8))

    assert result.summary_path.exists()
    assert result.trades_path.exists()
    assert result.equity_curve_path.exists()
    assert "final_equity" in result.summary
