from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from bots.run_trade_diagnostics import grouped_performance, profit_factor, save_diagnostics, top_level_summary


def _synthetic_trades() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "trade_id": 1,
                "side": "long",
                "entry_time": "2024-01-01T07:15:00+00:00",
                "exit_reason": "take_profit",
                "entry_reason": "smc_v2_bullish_bias_ltf_fvg_mitigation",
                "killzone_name": "london",
                "strategy_version": "smc_v2",
                "net_pnl": 25.0,
                "bars_held": 4,
                "rr": 2.0,
                "risk_pct": 0.002,
                "target_pct": 0.004,
            },
            {
                "trade_id": 2,
                "side": "long",
                "entry_time": "2024-01-01T08:00:00+00:00",
                "exit_reason": "stop_loss",
                "entry_reason": "smc_v2_bullish_bias_ltf_fvg_mitigation",
                "killzone_name": "london",
                "strategy_version": "smc_v2",
                "net_pnl": -10.0,
                "bars_held": 2,
                "rr": 2.0,
                "risk_pct": 0.002,
                "target_pct": 0.004,
            },
            {
                "trade_id": 3,
                "side": "short",
                "entry_time": "2024-01-02T14:00:00+00:00",
                "exit_reason": "take_profit",
                "entry_reason": "smc_v2_bearish_bias_ltf_fvg_mitigation",
                "killzone_name": "new_york",
                "strategy_version": "smc_v2",
                "net_pnl": 5.0,
                "bars_held": 3,
                "rr": 1.8,
                "risk_pct": 0.003,
                "target_pct": 0.0054,
            },
        ]
    )


def test_profit_factor_handles_zero_losses() -> None:
    assert profit_factor(pd.Series([1.0, 2.0, 3.0])) is None


def test_grouped_trade_diagnostics_by_side_and_killzone(tmp_path: Path) -> None:
    trades = _synthetic_trades()
    trades["entry_time"] = pd.to_datetime(trades["entry_time"], utc=True)
    trades["entry_hour_utc"] = trades["entry_time"].dt.hour
    trades["entry_weekday_utc"] = trades["entry_time"].dt.day_name()

    grouped = grouped_performance(trades)

    side_groups = grouped[grouped["group_type"] == "side"].set_index("group_value")
    killzone_groups = grouped[grouped["group_type"] == "killzone_name"].set_index("group_value")

    assert side_groups.loc["long", "trades"] == 2
    assert side_groups.loc["long", "total_net_pnl"] == 15.0
    assert side_groups.loc["short", "trades"] == 1
    assert killzone_groups.loc["london", "trades"] == 2
    assert killzone_groups.loc["new_york", "trades"] == 1

    top_level = top_level_summary(trades, {"net_pnl": 20.0, "total_trades": 3, "win_rate": 2 / 3})
    output = tmp_path / "trade_diagnostics_summary.csv"
    json_output = tmp_path / "trade_diagnostics_summary.json"
    save_diagnostics(grouped, top_level, output, json_output)

    assert output.exists()
    assert json_output.exists()
    payload = json.loads(json_output.read_text(encoding="utf-8"))
    assert payload["top_level"]["total_trades"] == 3
    assert len(payload["groups"]) >= 2
