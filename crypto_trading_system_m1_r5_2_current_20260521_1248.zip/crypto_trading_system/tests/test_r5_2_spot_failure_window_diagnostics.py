from __future__ import annotations

from argparse import Namespace
from pathlib import Path

import pandas as pd
import pytest

from bots.run_r5_2_spot_failure_window_diagnostics import (
    build_failed_window_summary,
    load_trade_files,
    parse_windows,
    run,
    trade_breakdown,
    validate_spot_symbol,
)
from core.data.ohlcv_cache import save_ohlcv_cache


def _detail_rows() -> list[dict]:
    return [
        {
            "experiment": "reference_long_only_block_15",
            "symbol": "BTC/USDT",
            "timeframe": "15m",
            "htf_timeframe": "1h",
            "start": "2023-07-01",
            "end": "2023-09-01",
            "final_equity": 904.7,
            "net_pnl": -95.3,
            "net_pnl_pct": -9.53,
            "max_drawdown_pct": 12.0,
            "total_trades": 18,
            "win_rate": 0.30,
            "profit_factor": 0.30,
            "long_trades": 18,
            "short_trades": 0,
        },
        {
            "experiment": "block_hours_7_8_13_15",
            "symbol": "BTC/USDT",
            "timeframe": "15m",
            "htf_timeframe": "1h",
            "start": "2023-07-01",
            "end": "2023-09-01",
            "final_equity": 922.0,
            "net_pnl": -78.0,
            "net_pnl_pct": -7.80,
            "max_drawdown_pct": 9.5,
            "total_trades": 10,
            "win_rate": 0.20,
            "profit_factor": 0.061575,
            "long_trades": 10,
            "short_trades": 0,
        },
    ]


def _results_rows() -> list[dict]:
    return [
        {
            "experiment": "reference_long_only_block_15",
            "windows": 10,
            "positive_windows": 6,
            "positive_window_rate": 0.6,
            "avg_net_pnl_pct": -1.01,
            "median_net_pnl_pct": 0.3,
            "worst_net_pnl_pct": -14.21,
            "best_net_pnl_pct": 8.8,
            "avg_max_drawdown_pct": 8.50,
            "worst_max_drawdown_pct": 14.5,
            "total_trades": 165,
            "avg_win_rate": 0.41,
            "avg_profit_factor": 1.02,
            "total_long_trades": 165,
            "total_short_trades": 0,
            "score": -22.1,
        },
        {
            "experiment": "block_hours_7_8_13_15",
            "windows": 10,
            "positive_windows": 6,
            "positive_window_rate": 0.6,
            "avg_net_pnl_pct": 0.68,
            "median_net_pnl_pct": 0.9,
            "worst_net_pnl_pct": -7.80,
            "best_net_pnl_pct": 10.3,
            "avg_max_drawdown_pct": 5.78,
            "worst_max_drawdown_pct": 9.5,
            "total_trades": 95,
            "avg_win_rate": 0.47,
            "avg_profit_factor": 1.38,
            "total_long_trades": 95,
            "total_short_trades": 0,
            "score": -12.1,
        },
    ]


def test_validate_spot_symbol_rejects_swap() -> None:
    validate_spot_symbol("BTC/USDT")
    with pytest.raises(SystemExit, match="spot-only"):
        validate_spot_symbol("BTC/USDT:USDT")


def test_parse_windows() -> None:
    assert parse_windows("2023-07-01:2023-09-01,2023-11-01:2024-01-01") == [
        ("2023-07-01", "2023-09-01"),
        ("2023-11-01", "2024-01-01"),
    ]


def test_failed_window_summary_uses_cache_regime(tmp_path: Path) -> None:
    cache_dir = tmp_path / "ohlcv"
    ohlcv = pd.DataFrame(
        {
            "timestamp": pd.date_range("2023-07-01", periods=4, freq="15min", tz="UTC"),
            "open": [100.0, 101.0, 100.0, 98.0],
            "high": [102.0, 102.0, 101.0, 99.0],
            "low": [99.0, 99.0, 97.0, 95.0],
            "close": [101.0, 100.0, 98.0, 96.0],
            "volume": [1.0, 1.0, 1.0, 1.0],
        }
    )
    save_ohlcv_cache(ohlcv, cache_dir / "okx_BTC-USDT_15m_2023-07-01_2023-09-01.csv")

    summary = build_failed_window_summary(
        details=pd.DataFrame(_detail_rows()),
        failed_windows=[("2023-07-01", "2023-09-01")],
        experiment="block_hours_7_8_13_15",
        reference_experiment="reference_long_only_block_15",
        symbol="BTC/USDT",
        timeframe="15m",
        cache_dir=cache_dir,
    )

    row = summary.iloc[0]
    assert row["damage_reduction_pct"] == pytest.approx(1.73)
    assert row["window_return_pct"] < 0
    assert row["btc_max_drawdown_pct"] > 0


def test_trade_breakdown_groups_by_hour_killzone_and_buckets(tmp_path: Path) -> None:
    trade_file = tmp_path / "trades.csv"
    pd.DataFrame(
        {
            "entry_time": ["2023-07-01T08:00:00Z", "2023-07-01T09:00:00Z"],
            "net_pnl": [-10.0, 5.0],
            "killzone_name": ["london", "london"],
            "exit_reason": ["stop_loss", "take_profit"],
            "risk_pct": [0.002, 0.006],
            "reward_to_fee_ratio": [4.0, 8.0],
        }
    ).to_csv(trade_file, index=False)

    trades = load_trade_files([trade_file])
    trades["window"] = "2023-07-01->2023-09-01"
    breakdown = trade_breakdown(trades)

    assert "entry_hour_utc" in set(breakdown["group_type"])
    assert "killzone" in set(breakdown["group_type"])
    assert "risk_bucket" in set(breakdown["group_type"])
    assert "reward_to_fee_bucket" in set(breakdown["group_type"])


def test_run_creates_summary_and_missing_trade_report(tmp_path: Path) -> None:
    details_path = tmp_path / "details.csv"
    results_path = tmp_path / "results.csv"
    output_summary = tmp_path / "summary.csv"
    output_report = tmp_path / "report.txt"
    pd.DataFrame(_detail_rows()).to_csv(details_path, index=False)
    pd.DataFrame(_results_rows()).to_csv(results_path, index=False)

    args = Namespace(
        details=str(details_path),
        results=str(results_path),
        symbol="BTC/USDT",
        timeframe="15m",
        htf_timeframe="1h",
        experiment="block_hours_7_8_13_15",
        reference_experiment="reference_long_only_block_15",
        failed_windows="2023-07-01:2023-09-01",
        trade_files=None,
        ohlcv_cache_dir=str(tmp_path / "missing_cache"),
        output_summary=str(output_summary),
        output_report=str(output_report),
        output_trade_breakdown=str(tmp_path / "breakdown.csv"),
        output_top_losers=str(tmp_path / "top_losers.csv"),
    )

    outputs = run(args)

    assert output_summary.exists()
    assert output_report.exists()
    report = output_report.read_text(encoding="utf-8")
    assert "Trade-level diagnostics require" in report
    assert "BTC/USDT" in report
    assert "BTC/USDT:USDT" not in report
    assert outputs["summary_path"] == output_summary
