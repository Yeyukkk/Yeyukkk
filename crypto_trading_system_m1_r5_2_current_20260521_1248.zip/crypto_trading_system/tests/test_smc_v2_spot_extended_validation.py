from __future__ import annotations

import pandas as pd
import pytest

from bots.run_smc_v2_spot_extended_validation import (
    EXTENDED_EXPERIMENTS,
    aggregate_experiment_rows,
    build_report,
    build_spot_filter_strategy,
    passes_robustness,
    robustness_failures,
    validate_spot_symbol,
)


def _detail_row(
    *,
    experiment: str = "block_hours_7_8_13_15",
    start: str = "2023-01-01",
    end: str = "2023-03-01",
    net_pnl_pct: float = 1.0,
    max_drawdown_pct: float = 4.0,
    total_trades: int = 10,
    win_rate: float = 0.5,
    profit_factor: float | None = 1.5,
) -> dict:
    return {
        "experiment": experiment,
        "symbol": "BTC/USDT",
        "timeframe": "15m",
        "htf_timeframe": "1h",
        "start": start,
        "end": end,
        "final_equity": 1010.0,
        "net_pnl": 10.0,
        "net_pnl_pct": net_pnl_pct,
        "max_drawdown_pct": max_drawdown_pct,
        "total_trades": total_trades,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "long_trades": total_trades,
        "short_trades": 0,
    }


def test_extended_validation_is_spot_only() -> None:
    validate_spot_symbol("BTC/USDT")
    with pytest.raises(SystemExit, match="spot-only"):
        validate_spot_symbol("BTC/USDT:USDT")


def test_extended_experiments_only_reference_and_block_hours() -> None:
    assert [experiment.name for experiment in EXTENDED_EXPERIMENTS] == [
        "reference_long_only_block_15",
        "block_hours_7_8_13_15",
    ]


def test_build_block_hours_strategy() -> None:
    experiment = next(exp for exp in EXTENDED_EXPERIMENTS if exp.name == "block_hours_7_8_13_15")
    strategy = build_spot_filter_strategy(
        experiment=experiment,
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )

    assert strategy.long_only is True
    assert strategy.blocked_entry_hours_utc == [7, 8, 13, 15]


def test_aggregate_positive_window_rate() -> None:
    rows = [
        _detail_row(net_pnl_pct=2.0, total_trades=10),
        _detail_row(net_pnl_pct=1.0, total_trades=10),
        _detail_row(net_pnl_pct=-1.0, total_trades=10),
        _detail_row(net_pnl_pct=3.0, total_trades=10),
    ]

    aggregate = aggregate_experiment_rows("block_hours_7_8_13_15", rows)

    assert aggregate["windows"] == 4
    assert aggregate["positive_windows"] == 3
    assert aggregate["positive_window_rate"] == pytest.approx(0.75)
    assert aggregate["total_trades"] == 40


def test_robustness_failures_report_specific_criteria() -> None:
    row = {
        "windows": 10,
        "positive_window_rate": 0.6,
        "avg_net_pnl_pct": 1.0,
        "avg_profit_factor": 1.1,
        "worst_net_pnl_pct": -7.0,
        "total_trades": 79,
        "avg_max_drawdown_pct": 11.0,
    }

    failures = robustness_failures(row)

    assert "positive_window_rate < 70%" in failures
    assert "avg_profit_factor <= 1.2" in failures
    assert "worst_net_pnl_pct <= -6.0" in failures
    assert "total_trades < 80" in failures
    assert "avg_max_drawdown_pct >= 10.0" in failures
    assert passes_robustness(row) is False


def test_build_report_includes_pass_fail_and_worst_window() -> None:
    reference_rows = [
        _detail_row(experiment="reference_long_only_block_15", net_pnl_pct=-1.0, start="2023-01-01", end="2023-03-01"),
        _detail_row(experiment="reference_long_only_block_15", net_pnl_pct=1.0, start="2023-03-01", end="2023-05-01"),
    ]
    block_rows = [
        _detail_row(experiment="block_hours_7_8_13_15", net_pnl_pct=-2.0, start="2023-01-01", end="2023-03-01"),
        _detail_row(experiment="block_hours_7_8_13_15", net_pnl_pct=2.0, start="2023-03-01", end="2023-05-01"),
    ]
    details = pd.DataFrame(reference_rows + block_rows)
    results = pd.DataFrame(
        [
            aggregate_experiment_rows("reference_long_only_block_15", reference_rows),
            aggregate_experiment_rows("block_hours_7_8_13_15", block_rows),
        ]
    )

    report = build_report(results, details)

    assert "R5.1 Spot Extended Validation Report" in report
    assert "Reference vs block_hours_7_8_13_15" in report
    assert "Worst block-hours window" in report
    assert "R5.1 robustness result: FAILED." in report
    assert "research only" in report.lower()
