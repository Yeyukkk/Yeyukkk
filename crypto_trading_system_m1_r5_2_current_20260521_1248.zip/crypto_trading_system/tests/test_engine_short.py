from __future__ import annotations

from pathlib import Path

import pandas as pd

from bots.run_backtest import _build_backtest_config, _build_parser
from core.backtest import BacktestConfig, BacktestEngine


class ScriptedSignalStrategy:
    def generate_signals(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        df = ohlcv.copy()
        df["signal"] = ["long_entry", "", "long_exit", ""]
        df["signal_reason"] = ["scripted_long_entry", "", "scripted_long_exit", ""]
        return df


class ScriptedShortSignalStrategy:
    def generate_signals(self, ohlcv: pd.DataFrame) -> pd.DataFrame:
        df = ohlcv.copy()
        df["signal"] = ["short_entry", "", "short_exit", ""]
        df["signal_reason"] = ["scripted_short_entry", "", "scripted_short_exit", ""]
        return df


def _ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=4, freq="15min", tz="UTC")
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": [100.0, 100.0, 105.0, 110.0],
            "high": [101.0, 106.0, 111.0, 112.0],
            "low": [99.0, 99.0, 104.0, 109.0],
            "close": [100.0, 105.0, 110.0, 111.0],
            "volume": [100.0, 100.0, 100.0, 100.0],
        }
    )


def _falling_ohlcv() -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=4, freq="15min", tz="UTC")
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": [100.0, 100.0, 95.0, 90.0],
            "high": [101.0, 101.0, 96.0, 91.0],
            "low": [99.0, 94.0, 89.0, 88.0],
            "close": [100.0, 95.0, 90.0, 89.0],
            "volume": [100.0, 100.0, 100.0, 100.0],
        }
    )


def test_run_backtest_cli_constructs_allow_short_config(tmp_path: Path) -> None:
    args = _build_parser().parse_args(
        [
            "--symbol",
            "BTC/USDT",
            "--timeframe",
            "15m",
            "--start",
            "2024-01-01",
            "--end",
            "2024-01-02",
            "--allow-short",
            "--output-dir",
            str(tmp_path / "logs"),
        ]
    )

    config = _build_backtest_config(args, raw_config={})

    assert config.allow_short is True
    assert config.symbol == "BTC/USDT"
    assert config.output_dir == str(tmp_path / "logs")


def test_allow_short_summary_fields_do_not_change_long_only_signals(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 01:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        allow_short=True,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_ohlcv(), ScriptedSignalStrategy())

    assert result.summary["allow_short"] is True
    assert result.summary["total_trades"] == 1
    assert result.summary["long_trades"] == 1
    assert result.summary["short_trades"] == 0
    assert result.trades[0].side == "long"


def test_dataframe_short_entry_and_exit_work_when_enabled(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 01:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        allow_short=True,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(_falling_ohlcv(), ScriptedShortSignalStrategy())

    assert result.summary["allow_short"] is True
    assert result.summary["total_trades"] == 1
    assert result.summary["long_trades"] == 0
    assert result.summary["short_trades"] == 1
    assert result.trades[0].side == "short"
    assert result.trades[0].exit_reason == "ema_cross_exit"
    assert result.trades[0].net_pnl > 0
