from __future__ import annotations

from pathlib import Path

import pandas as pd
import pytest

from core.backtest import BacktestConfig, BacktestEngine, EMACrossoverStrategy
from core.strategy import Signal


class StructuredSignalStrategy:
    def __init__(self, signals: list[Signal]) -> None:
        self.signals = signals

    def generate_signals(self, ohlcv: pd.DataFrame) -> list[Signal]:
        return self.signals


def _ohlcv(rows: list[tuple[float, float, float, float]]) -> pd.DataFrame:
    timestamps = pd.date_range("2024-01-01", periods=len(rows), freq="15min", tz="UTC")
    return pd.DataFrame(
        [
            {
                "timestamp": timestamp,
                "open": open_price,
                "high": high,
                "low": low,
                "close": close,
                "volume": 100.0,
            }
            for timestamp, (open_price, high, low, close) in zip(timestamps, rows, strict=True)
        ]
    )


def _config(tmp_path: Path, allow_short: bool = False) -> BacktestConfig:
    return BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        liquidation_check_enabled=False,
        allow_short=allow_short,
        output_dir=tmp_path / "logs",
    )


def _entry_signal(timestamp: pd.Timestamp, side: str, stop: float, target: float) -> Signal:
    return Signal(
        timestamp=timestamp,
        symbol="BTC/USDT",
        timeframe="15m",
        side=side,  # type: ignore[arg-type]
        action="entry",
        entry_price=100.0,
        stop_loss_price=stop,
        take_profit_price=target,
        reason=f"structured_{side}_entry",
        score=77.5,
        metadata={
            "source": "test",
            "strategy_version": "smc_v2",
            "killzone_name": "london",
            "passed_killzone": True,
            "passed_liquidity_sweep": True,
            "passed_choch": True,
            "sweep_level": 99.0,
            "choch_level": 101.0,
            "risk_pct": 0.01,
            "target_pct": 0.02,
            "rr": 2.0,
            "reward_to_fee_ratio": 3.0,
        },
    )


def test_structured_long_signal_take_profit(tmp_path: Path) -> None:
    data = _ohlcv(
        [
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 111.0, 99.0, 110.0),
            (110.0, 112.0, 109.0, 111.0),
        ]
    )
    signal = _entry_signal(data.iloc[0]["timestamp"], "long", stop=95.0, target=110.0)

    result = BacktestEngine(_config(tmp_path)).run(data, StructuredSignalStrategy([signal]))
    trade = pd.read_csv(result.trades_path).iloc[0]

    assert trade["side"] == "long"
    assert trade["exit_reason"] == "take_profit"
    assert trade["exit_price"] == pytest.approx(110.0)
    assert trade["stop_loss_price"] == pytest.approx(95.0)
    assert trade["take_profit_price"] == pytest.approx(110.0)
    assert trade["signal_score"] == pytest.approx(77.5)
    assert trade["strategy_version"] == "smc_v2"
    assert trade["killzone_name"] == "london"
    assert str(trade["passed_killzone"]).lower() in {"true", "1"}
    assert str(trade["passed_liquidity_sweep"]).lower() in {"true", "1"}
    assert str(trade["passed_choch"]).lower() in {"true", "1"}
    assert trade["sweep_level"] == pytest.approx(99.0)
    assert trade["choch_level"] == pytest.approx(101.0)
    assert trade["risk_pct"] == pytest.approx(0.01)
    assert trade["target_pct"] == pytest.approx(0.02)
    assert trade["rr"] == pytest.approx(2.0)
    assert trade["reward_to_fee_ratio"] == pytest.approx(3.0)
    assert trade["entry_reason"] == "structured_long_entry"


def test_structured_short_signal_take_profit(tmp_path: Path) -> None:
    data = _ohlcv(
        [
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 89.0, 90.0),
            (90.0, 91.0, 88.0, 89.0),
        ]
    )
    signal = _entry_signal(data.iloc[0]["timestamp"], "short", stop=105.0, target=90.0)

    result = BacktestEngine(_config(tmp_path, allow_short=True)).run(data, StructuredSignalStrategy([signal]))
    trade = pd.read_csv(result.trades_path).iloc[0]

    assert trade["side"] == "short"
    assert trade["exit_reason"] == "take_profit"
    assert trade["exit_price"] == pytest.approx(90.0)
    assert trade["take_profit_price"] == pytest.approx(90.0)
    assert result.summary["short_trades"] == 1


def test_structured_long_signal_stop_loss(tmp_path: Path) -> None:
    data = _ohlcv(
        [
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 94.0, 95.0),
            (95.0, 96.0, 94.0, 95.0),
        ]
    )
    signal = _entry_signal(data.iloc[0]["timestamp"], "long", stop=95.0, target=110.0)

    result = BacktestEngine(_config(tmp_path)).run(data, StructuredSignalStrategy([signal]))
    trade = pd.read_csv(result.trades_path).iloc[0]

    assert trade["side"] == "long"
    assert trade["exit_reason"] == "stop_loss"
    assert trade["exit_price"] == pytest.approx(95.0)
    assert trade["stop_loss_price"] == pytest.approx(95.0)


def test_structured_short_signal_stop_loss(tmp_path: Path) -> None:
    data = _ohlcv(
        [
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 101.0, 99.0, 100.0),
            (100.0, 106.0, 99.0, 105.0),
            (105.0, 106.0, 104.0, 105.0),
        ]
    )
    signal = _entry_signal(data.iloc[0]["timestamp"], "short", stop=105.0, target=90.0)

    result = BacktestEngine(_config(tmp_path, allow_short=True)).run(data, StructuredSignalStrategy([signal]))
    trade = pd.read_csv(result.trades_path).iloc[0]

    assert trade["side"] == "short"
    assert trade["exit_reason"] == "stop_loss"
    assert trade["exit_price"] == pytest.approx(105.0)
    assert trade["stop_loss_price"] == pytest.approx(105.0)


def test_ema_dataframe_strategy_still_runs_without_structured_signals(tmp_path: Path) -> None:
    timestamps = pd.date_range("2024-01-01", periods=80, freq="15min", tz="UTC")
    prices = [100 + index * 0.25 for index in range(40)] + [110 - index * 0.25 for index in range(40)]
    data = pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": prices,
            "high": [price + 1.0 for price in prices],
            "low": [price - 1.0 for price in prices],
            "close": prices,
            "volume": [100.0] * len(prices),
        }
    )

    result = BacktestEngine(_config(tmp_path)).run(data, EMACrossoverStrategy(fast_ema=3, slow_ema=8))

    assert result.summary_path.exists()
    assert result.trades_path.exists()
    assert "final_equity" in result.summary
