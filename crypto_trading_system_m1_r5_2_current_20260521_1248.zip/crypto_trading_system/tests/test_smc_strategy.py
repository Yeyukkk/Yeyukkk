from __future__ import annotations

from pathlib import Path

import pandas as pd

from core.backtest import BacktestConfig, BacktestEngine
from core.strategy import SMCStrategyV1


def _frame(rows: list[tuple[float, float, float, float]], start: str = "2024-01-01", freq: str = "15min") -> pd.DataFrame:
    timestamps = pd.date_range(start, periods=len(rows), freq=freq, tz="UTC")
    return pd.DataFrame(
        [
            {
                "timestamp": timestamp,
                "open": open_price,
                "high": high,
                "low": low,
                "close": close,
                "volume": 100.0,
            }
            for timestamp, (open_price, high, low, close) in zip(timestamps, rows, strict=True)
        ]
    )


def _bullish_htf() -> pd.DataFrame:
    return _frame(
        [
            (95.0, 100.0, 90.0, 95.0),
            (96.0, 101.0, 92.0, 96.0),
            (100.0, 111.0, 95.0, 108.0),
        ],
        freq="1h",
    )


def _bearish_htf() -> pd.DataFrame:
    return _frame(
        [
            (95.0, 100.0, 90.0, 95.0),
            (94.0, 99.0, 89.0, 94.0),
            (90.0, 95.0, 80.0, 84.0),
        ],
        freq="1h",
    )


def _neutral_htf() -> pd.DataFrame:
    return _frame(
        [
            (95.0, 100.0, 90.0, 95.0),
            (96.0, 101.0, 91.0, 96.0),
            (97.0, 100.0, 92.0, 97.0),
        ],
        freq="1h",
    )


def _bullish_ltf() -> pd.DataFrame:
    return _frame(
        [
            (98.0, 100.0, 95.0, 99.0),
            (101.0, 104.0, 100.0, 103.0),
            (107.0, 110.0, 105.0, 108.0),
            (106.0, 107.0, 102.0, 103.0),
            (103.0, 106.0, 102.0, 105.0),
        ]
    )


def _bearish_ltf() -> pd.DataFrame:
    return _frame(
        [
            (104.0, 105.0, 100.0, 103.0),
            (99.0, 100.0, 97.0, 98.0),
            (93.0, 95.0, 90.0, 92.0),
            (94.0, 98.0, 92.0, 96.0),
            (96.0, 97.0, 93.0, 94.0),
        ]
    )


def _strategy(**overrides: object) -> SMCStrategyV1:
    params = {
        "symbol": "BTC/USDT",
        "atr_period": 3,
        "atr_buffer_multiplier": 0.25,
        "risk_reward": 2.0,
    }
    params.update(overrides)
    return SMCStrategyV1(**params)


def test_smc_strategy_imports() -> None:
    assert SMCStrategyV1().name == "smc_v1"


def test_smc_strategy_no_signal_when_htf_bias_neutral() -> None:
    signals = _strategy().generate_signals(_bullish_ltf().iloc[:4], _neutral_htf())

    assert signals == []


def test_smc_strategy_long_signal_geometry() -> None:
    signals = _strategy().generate_signals(_bullish_ltf().iloc[:4], _bullish_htf())

    assert len(signals) == 1
    signal = signals[0]
    assert signal.side == "long"
    assert signal.action == "entry"
    assert signal.stop_loss_price < signal.entry_price < signal.take_profit_price
    assert "bullish" in signal.reason
    for key in ["risk_pct", "target_pct", "rr", "reward_to_fee_ratio"]:
        assert key in signal.metadata
        assert signal.metadata[key] > 0
    signal.validate_geometry()


def test_smc_strategy_short_signal_geometry() -> None:
    signals = _strategy().generate_signals(_bearish_ltf().iloc[:4], _bearish_htf())

    assert len(signals) == 1
    signal = signals[0]
    assert signal.side == "short"
    assert signal.action == "entry"
    assert signal.take_profit_price < signal.entry_price < signal.stop_loss_price
    assert "bearish" in signal.reason
    signal.validate_geometry()


def test_smc_strategy_filters_too_small_target() -> None:
    signals = _strategy(risk_reward=0.01, min_rr=0.0, min_reward_to_fee_ratio=0.0).generate_signals(
        _bullish_ltf().iloc[:4],
        _bullish_htf(),
    )

    assert signals == []


def test_smc_strategy_filters_too_small_risk() -> None:
    signals = _strategy(min_risk_pct=0.50).generate_signals(_bullish_ltf().iloc[:4], _bullish_htf())

    assert signals == []


def test_smc_strategy_filters_rr_below_minimum() -> None:
    signals = _strategy(risk_reward=1.0, min_rr=1.5, min_target_pct=0.0, min_reward_to_fee_ratio=0.0).generate_signals(
        _bullish_ltf().iloc[:4],
        _bullish_htf(),
    )

    assert signals == []


def test_smc_strategy_lookback_handles_extra_history_before_setup() -> None:
    prefix_ltf = _frame(
        [
            (80.0, 81.0, 79.0, 80.0),
            (81.0, 82.0, 80.0, 81.0),
            (82.0, 83.0, 81.0, 82.0),
            (83.0, 84.0, 82.0, 83.0),
            (84.0, 85.0, 83.0, 84.0),
        ],
        start="2023-12-31",
    )
    prefix_htf = _frame(
        [
            (80.0, 82.0, 78.0, 81.0),
            (81.0, 83.0, 79.0, 82.0),
            (82.0, 84.0, 80.0, 83.0),
            (83.0, 85.0, 81.0, 84.0),
        ],
        start="2023-12-31",
        freq="1h",
    )
    ltf = pd.concat([prefix_ltf, _bullish_ltf()], ignore_index=True)
    htf = pd.concat([prefix_htf, _bullish_htf()], ignore_index=True)

    signals = _strategy(ltf_lookback_bars=5, htf_lookback_bars=3).generate_signals(ltf.iloc[:9], htf)

    assert len(signals) == 1
    signals[0].validate_geometry()


def test_backtest_engine_runs_with_smc_strategy_and_htf_data(tmp_path: Path) -> None:
    config = BacktestConfig(
        symbol="BTC/USDT",
        timeframe="15m",
        start="2024-01-01",
        end="2024-01-01 02:00",
        initial_equity=1_000,
        fee_rate=0,
        slippage_bps=0,
        leverage=10,
        max_margin_pct=0.20,
        stop_loss_pct_on_margin=None,
        liquidation_check_enabled=False,
        allow_short=True,
        output_dir=tmp_path / "logs",
    )

    result = BacktestEngine(config).run(
        _bullish_ltf(),
        _strategy(),
        htf_ohlcv=_bullish_htf(),
        htf_timeframe="1h",
    )

    assert result.summary_path.exists()
    assert result.trades_path.exists()
    assert result.equity_curve_path.exists()
    assert "final_equity" in result.summary
