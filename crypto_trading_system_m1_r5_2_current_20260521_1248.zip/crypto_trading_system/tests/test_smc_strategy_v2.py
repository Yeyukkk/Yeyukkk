from __future__ import annotations

import pandas as pd
import pytest

from core.strategy import SMCStrategyV1, SMCStrategyV2


def _frame(rows: list[tuple[float, float, float, float]], start: str, freq: str = "15min") -> pd.DataFrame:
    timestamps = pd.date_range(start, periods=len(rows), freq=freq, tz="UTC")
    return pd.DataFrame(
        [
            {
                "timestamp": timestamp,
                "open": open_price,
                "high": high,
                "low": low,
                "close": close,
                "volume": 100.0,
            }
            for timestamp, (open_price, high, low, close) in zip(timestamps, rows, strict=True)
        ]
    )


def _bullish_htf() -> pd.DataFrame:
    return _frame(
        [
            (95.0, 100.0, 90.0, 95.0),
            (96.0, 101.0, 92.0, 96.0),
            (100.0, 111.0, 95.0, 108.0),
        ],
        start="2024-01-01 05:00",
        freq="1h",
    )


def _bearish_htf() -> pd.DataFrame:
    return _frame(
        [
            (95.0, 100.0, 90.0, 95.0),
            (94.0, 99.0, 89.0, 94.0),
            (90.0, 95.0, 80.0, 84.0),
        ],
        start="2024-01-01 05:00",
        freq="1h",
    )


def _valid_long_ltf(start: str = "2024-01-01 07:00") -> pd.DataFrame:
    return _frame(
        [
            (100.0, 101.0, 99.0, 100.0),
            (103.0, 104.0, 102.0, 103.0),
            (107.0, 110.0, 106.0, 108.0),
            (106.0, 107.0, 98.0, 105.0),
        ],
        start=start,
    )


def _valid_short_ltf(start: str = "2024-01-01 07:00") -> pd.DataFrame:
    return _frame(
        [
            (100.0, 101.0, 99.0, 100.0),
            (97.0, 98.0, 96.0, 97.0),
            (93.0, 94.0, 90.0, 92.0),
            (94.0, 102.0, 92.0, 95.0),
        ],
        start=start,
    )


def _long_without_sweep() -> pd.DataFrame:
    return _frame(
        [
            (100.0, 101.0, 99.0, 100.0),
            (103.0, 104.0, 102.0, 103.0),
            (107.0, 110.0, 106.0, 108.0),
            (106.0, 107.0, 102.0, 105.0),
        ],
        start="2024-01-01 07:00",
    )


def _long_without_choch() -> pd.DataFrame:
    return _frame(
        [
            (100.0, 101.0, 99.0, 100.0),
            (103.0, 120.0, 102.0, 103.0),
            (107.0, 110.0, 106.0, 108.0),
            (106.0, 107.0, 98.0, 105.0),
        ],
        start="2024-01-01 07:00",
    )


def _strategy(**overrides: object) -> SMCStrategyV2:
    params = {
        "symbol": "BTC/USDT",
        "atr_period": 3,
        "atr_buffer_multiplier": 0.25,
        "risk_reward": 2.0,
    }
    params.update(overrides)
    return SMCStrategyV2(**params)


def test_smc_v2_name_and_v1_unchanged() -> None:
    assert SMCStrategyV2().name == "smc_v2"
    assert SMCStrategyV1().name == "smc_v1"


def test_smc_v2_no_signal_outside_killzone() -> None:
    signals = _strategy().generate_signals(_valid_long_ltf(start="2024-01-01 03:00"), _bullish_htf())

    assert signals == []


def test_smc_v2_valid_long_signal_inside_killzone() -> None:
    signals = _strategy().generate_signals(_valid_long_ltf(), _bullish_htf())

    assert len(signals) == 1
    signal = signals[0]
    assert signal.side == "long"
    assert signal.stop_loss_price < signal.entry_price < signal.take_profit_price
    assert "bullish" in signal.reason
    signal.validate_geometry()


def test_smc_v2_valid_short_signal_inside_killzone() -> None:
    signals = _strategy().generate_signals(_valid_short_ltf(), _bearish_htf())

    assert len(signals) == 1
    signal = signals[0]
    assert signal.side == "short"
    assert signal.take_profit_price < signal.entry_price < signal.stop_loss_price
    assert "bearish" in signal.reason
    signal.validate_geometry()


def test_smc_v2_rejects_when_required_liquidity_sweep_missing() -> None:
    signals = _strategy(require_liquidity_sweep=True).generate_signals(_long_without_sweep(), _bullish_htf())

    assert signals == []


def test_smc_v2_rejects_when_required_choch_missing() -> None:
    signals = _strategy(require_ltf_choch=True).generate_signals(_long_without_choch(), _bullish_htf())

    assert signals == []


def test_smc_v2_signal_metadata_contains_filter_results() -> None:
    signals = _strategy().generate_signals(_valid_long_ltf(), _bullish_htf())

    assert len(signals) == 1
    metadata = signals[0].metadata
    for key in [
        "strategy_version",
        "killzone_name",
        "passed_killzone",
        "passed_liquidity_sweep",
        "passed_choch",
        "sweep_level",
        "choch_level",
    ]:
        assert key in metadata
    assert metadata["strategy_version"] == "smc_v2"
    assert metadata["killzone_name"] == "london"
    assert metadata["passed_killzone"] is True
    assert metadata["passed_liquidity_sweep"] is True
    assert metadata["passed_choch"] is True


def test_smc_v2_long_only_suppresses_short_but_allows_long() -> None:
    strategy = _strategy(long_only=True)

    assert len(strategy.generate_signals(_valid_long_ltf(), _bullish_htf())) == 1
    assert strategy.generate_signals(_valid_short_ltf(), _bearish_htf()) == []


def test_smc_v2_short_only_suppresses_long_but_allows_short() -> None:
    strategy = _strategy(short_only=True)

    assert strategy.generate_signals(_valid_long_ltf(), _bullish_htf()) == []
    assert len(strategy.generate_signals(_valid_short_ltf(), _bearish_htf())) == 1


def test_smc_v2_long_only_and_short_only_raises() -> None:
    with pytest.raises(ValueError, match="long_only and short_only"):
        _strategy(long_only=True, short_only=True)


def test_smc_v2_blocked_entry_hour_suppresses_signal() -> None:
    signals = _strategy(blocked_entry_hours_utc=[7]).generate_signals(_valid_long_ltf(), _bullish_htf())

    assert signals == []


def test_smc_v2_blocked_entry_hour_suppresses_next_open_entry_hour() -> None:
    signals = _strategy(blocked_entry_hours_utc=[15]).generate_signals(
        _valid_long_ltf(start="2024-01-01 14:00"),
        _bullish_htf(),
    )

    assert signals == []


def test_smc_v2_block_new_york_shorts_only_suppresses_new_york_short() -> None:
    strategy = _strategy(block_new_york_shorts=True)

    assert strategy.generate_signals(_valid_short_ltf(start="2024-01-01 14:00"), _bearish_htf()) == []
    long_signals = strategy.generate_signals(_valid_long_ltf(start="2024-01-01 14:00"), _bullish_htf())

    assert len(long_signals) == 1
    assert long_signals[0].metadata["killzone_name"] == "new_york"


def test_smc_v2_default_experiment_switches_are_inactive() -> None:
    signal = _strategy().generate_signals(_valid_long_ltf(), _bullish_htf())[0]
    metadata = signal.metadata

    assert metadata["experiment_long_only"] is False
    assert metadata["experiment_short_only"] is False
    assert metadata["experiment_blocked_hours"] == []
    assert metadata["experiment_block_new_york_shorts"] is False


def test_smc_v2_allowed_killzones_suppresses_other_sessions() -> None:
    strategy = _strategy(allowed_killzones=["new_york"])

    assert strategy.generate_signals(_valid_long_ltf(), _bullish_htf()) == []
    assert len(strategy.generate_signals(_valid_long_ltf(start="2024-01-01 14:00"), _bullish_htf())) == 1


def test_smc_v2_blocked_killzones_suppresses_named_session() -> None:
    strategy = _strategy(blocked_killzones=["london"])

    assert strategy.generate_signals(_valid_long_ltf(), _bullish_htf()) == []
    assert len(strategy.generate_signals(_valid_long_ltf(start="2024-01-01 14:00"), _bullish_htf())) == 1


def test_smc_v2_max_risk_pct_suppresses_high_risk_signal() -> None:
    signals = _strategy(max_risk_pct=0.0001).generate_signals(_valid_long_ltf(), _bullish_htf())

    assert signals == []
