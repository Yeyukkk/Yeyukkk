from __future__ import annotations

import pandas as pd
import pytest

from bots.run_smc_v2_spot_controlled_filters import (
    ROBUSTNESS_CRITERIA,
    SPOT_FILTER_EXPERIMENTS,
    SpotFilterExperiment,
    aggregate_experiment_rows,
    build_report,
    build_spot_filter_strategy,
    passes_robustness,
    validate_spot_symbol,
)


def _experiment(name: str) -> SpotFilterExperiment:
    return next(experiment for experiment in SPOT_FILTER_EXPERIMENTS if experiment.name == name)


def _detail_row(
    *,
    experiment: str = "ex",
    net_pnl_pct: float = 1.0,
    max_drawdown_pct: float = 2.0,
    total_trades: int = 10,
    win_rate: float = 0.5,
    profit_factor: float | None = 1.5,
    long_trades: int = 10,
    short_trades: int = 0,
) -> dict:
    return {
        "experiment": experiment,
        "symbol": "BTC/USDT",
        "timeframe": "15m",
        "htf_timeframe": "1h",
        "start": "2024-01-01",
        "end": "2024-03-01",
        "final_equity": 1010.0,
        "net_pnl": 10.0,
        "net_pnl_pct": net_pnl_pct,
        "max_drawdown_pct": max_drawdown_pct,
        "total_trades": total_trades,
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "long_trades": long_trades,
        "short_trades": short_trades,
    }


def test_spot_runner_refuses_contract_symbol() -> None:
    validate_spot_symbol("BTC/USDT")
    with pytest.raises(SystemExit, match="spot-only"):
        validate_spot_symbol("BTC/USDT:USDT")


def test_spot_filter_experiments_are_expected_names() -> None:
    assert [experiment.name for experiment in SPOT_FILTER_EXPERIMENTS] == [
        "reference_long_only_block_15",
        "new_york_only",
        "block_london",
        "block_hours_7_8_13_15",
        "min_reward_to_fee_5",
        "risk_between_025_075",
        "new_york_only_reward_to_fee_5",
        "new_york_only_risk_025_075",
        "new_york_only_reward5_risk_025_075",
    ]


def test_build_spot_filter_strategy_new_york_only() -> None:
    strategy = build_spot_filter_strategy(
        experiment=_experiment("new_york_only"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )

    assert strategy.long_only is True
    assert strategy.allowed_killzones == ["new_york"]
    assert strategy.blocked_killzones is None


def test_build_spot_filter_strategy_reward_and_risk_filters() -> None:
    strategy = build_spot_filter_strategy(
        experiment=_experiment("new_york_only_reward5_risk_025_075"),
        symbol="BTC/USDT",
        ltf_timeframe="15m",
        htf_timeframe="1h",
    )

    assert strategy.allowed_killzones == ["new_york"]
    assert strategy.min_reward_to_fee_ratio == 5.0
    assert strategy.min_risk_pct == pytest.approx(0.0025)
    assert strategy.max_risk_pct == pytest.approx(0.0075)


def test_aggregate_and_robustness() -> None:
    rows = [
        _detail_row(net_pnl_pct=2.0, max_drawdown_pct=4.0, total_trades=12, profit_factor=1.8),
        _detail_row(net_pnl_pct=1.0, max_drawdown_pct=5.0, total_trades=12, profit_factor=1.4),
        _detail_row(net_pnl_pct=0.5, max_drawdown_pct=6.0, total_trades=12, profit_factor=1.3),
        _detail_row(net_pnl_pct=-2.0, max_drawdown_pct=7.0, total_trades=12, profit_factor=0.9),
    ]

    aggregate = aggregate_experiment_rows("ex", rows)

    assert aggregate["windows"] == 4
    assert aggregate["positive_windows"] == 3
    assert aggregate["total_trades"] == 48
    assert aggregate["worst_net_pnl_pct"] == -2.0
    assert passes_robustness(aggregate) is True


def test_robustness_rejects_low_trade_count() -> None:
    row = {
        "positive_windows": ROBUSTNESS_CRITERIA["positive_windows"],
        "avg_net_pnl_pct": 1.0,
        "avg_profit_factor": 1.3,
        "worst_net_pnl_pct": -4.0,
        "total_trades": ROBUSTNESS_CRITERIA["total_trades"] - 1,
    }

    assert passes_robustness(row) is False


def test_report_states_no_robust_candidate() -> None:
    details = pd.DataFrame(
        [
            _detail_row(experiment="reference_long_only_block_15", net_pnl_pct=-1.0),
            _detail_row(experiment="new_york_only", net_pnl_pct=-2.0),
        ]
    )
    results = pd.DataFrame(
        [
            aggregate_experiment_rows("reference_long_only_block_15", [details.iloc[0].to_dict()]),
            aggregate_experiment_rows("new_york_only", [details.iloc[1].to_dict()]),
        ]
    )

    report = build_report(results, details)

    assert "Ranked experiment table" in report
    assert "No R5.0 filter passed robustness criteria." in report
    assert "research only" in report.lower()
